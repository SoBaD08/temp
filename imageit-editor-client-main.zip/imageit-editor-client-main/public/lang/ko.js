export default {
  //header
  File: "파일",
  //file
  New: "신규",
  OpenFile: "파일 열기",
  Save: "저장",
  SaveAs: "다른 이름으로 저장",
  SaveAsAsset: "Asset으로 저장",
  Download: "다운로드",
  //edit
  Edit: "편집",
  Undo: "실행 취소",
  Redo: "되돌리기",
  Copy: "복사",
  Paste: "붙여넣기",
  Delete: "삭제",
  SelectAll: "모두 선택",

  Saved: "저장됨",
  Comment: "댓글",

  Download: "다운로드",
  //AI BUTTON
  ExtractText: "텍스트 추출",
  TextDetect: "텍스트 인식",
  Execute: "실행",
  TextExtract: " 텍스트 추출",
  All: "모두",
  SelectedOnly: "선택 항목 만",
  Inpainting: "텍스트 삭제 및 배경 복구",
  TextLine: "텍스트 인식선",

  Translation: "번역",
  TranslateAll: "모두 번역",
  TranslateSelected: "선택 항목 번역",

  RemoveObject: "AI 지우개",
  MaskBrushType: "마스크 브러시 유형",
  MaskBrushSize: "마스크 브러시 크기",
  Remove: "지우기",

  RemoveBG: "배경 제거",
  CreateNewLayer: "새 레이어 생성",

  RemoveObject: "AI 지우개",

  Size: "크기",
  //Menu
  Select: "선택",
  Text: "텍스트",
  Layer: "레이어",
  Asset: "Asset",
  //Stage
  Source: "원본",
  Edit: "편집",

  EditText: "텍스트 편집",

  //Modal
  CancelButton: "취소",
  AcceptButton: "수락",
  Oke: "확인",

  //Credit
  CreditLine1: "크레딧이 부족합니다.",
  CreditLine2: "지금 크레딧을 구매하시겠습니까?",

  //translationWarning
  CheckTheLanguage: `원본 언어를 확인하고 "대상" 언어 옵션에서 해당 언어를 선택하세요!`,
  SelectTextTranslate: "번역 대상 텍스트를 선택하세요",

  //removeBgWarning
  RemoveBGTitle: `<배경 제거>는 주요 오브젝트를 제외하고 모든 배경을 제거합니다.`,
  CheckTheImage: "이미지 레이어를 확인하십시오",
  SelectImage: "배경을 삭제할 이미지 레이어를 선택하세요.",
  DescriptionRemoveBg:
    "이미 계층화된 영역을 삭제하려면 계층 삭제 기능을 사용하십시오.",

  //notification
  DoNotShowAgain: "이 메시지를 다시 표시하지 않습니다.",

  //ExtractTextWarning
  CanNotExtract: "텍스트를 추출할 수 없습니다",
  SelectText: "텍스트를 선택하세요",

  //TransfromWarning

  ChooseLayer: "레이어를 선택하세요!",
  NoLayer: "저장된 레이어가 없습니다",

  //UploadWarning
  UploadFail: "파일 업로드 실패",
  UploadImage: "이미지를 업로드하세요",
  NewImages: "새 이미지",

  //RemoveObj
  RemoveObjDescription:
    "제거하려는 개체를 가리고 '제거'를 클릭하십시오. 제거하려는 개체를 꼼꼼하게 가리면 더 나은 결과를 얻을 수 있습니다.",
  SelectLayer:
    "다른 레이어를 시도하려면 레이어 패널에서 원하는 레이어를 선택하십시오.",

  //Save
  AddImage: "저장할 이미지를 추가하세요!",
  SaveAssetSuccess: "Asset으로 저장하기 성공",
  SaveAssetError: "Asset으로 저장 실패",
  SaveImageSuccess: "이미지가 저장되었습니다!",
  SaveImageFail: "이미지가 저장되지 않았습니다!",
  SaveOption: "현재 파일을 저장하시겠습니까?",
  DeleteAssetFailed: "Asset 삭제 실패!",

  //Comments
  Invite: "멤버 초대",
  AnyOneWithTheLink: "링크가 있는 모든 사용자",
  CopyLink: "링크 복사",
  SendInvite: "초대하기",
  Recent: "최근",
  Resolved: "해결됨",
  Search: "검색",
  DelComentSuccess: "댓글 삭제 성공",
  DelCommentFail: "댓글 삭제 실패",
  ResolveCommentFail: "댓글 해결 실패",
  ChooseMulLayer: "여러 레이어를 선택하세요!",

  //Tooltip
  Dashboard: "대시보드",
  SelectTitle: "선택(V)",
  SelectDescription: "편집 창에서 개체를 선택하는 데 사용할 수 있습니다.",
  TextTitle: "텍스트(T)",
  TextDescriptions: "텍스트 삽입 및 편집",
  LayerDescription: `"레이어" 열기`,
  AssetDescription: `"Asset" 열기`,
  ExtractTextTitle: "텍스트 추출(Shift + E)",
  ExtractTextDescription:
    "이미지에서 텍스트를 추출하고 추출된 각 텍스트에 대한 레이어를 생성합니다.",

  RemoveBgTitle: "배경 제거(Shift + R)",
  RemoveBgDescription:
    "이미지의 배경을 제거합니다. 예를 들어 이미지에 사람이 있는 경우 이 기능은 이미지의 다른 측면을 제거하지만 사람만 제거합니다.",

  RemoveObjectTitle: "개체 제거(Shift + O)",
  RemoveObjectDescription:
    "지우개 도구를 사용하여 이미지에서 선택한 개체를 지웁니다.",
  TranslationTitle: "번역(Shift + T)",
  TranslationDescription: "목표 언어를 설정하여 선택한 텍스트를 번역합니다",

  //ConfirmRemoveObj
  OperationFaile: "개체 제거 작업이 완료되지 않았습니다.",
  ConfirmDownload: `다운로드하려면 개체 제거 작업이 됩니다.`,
  Aborted: "중단!",
  ContinueEditing: "계속 편집",

  Layers: "레이어",

  ScrollSync: "스크롤 동기화",
  ScrollSyncDescription:
    "활성화하면 원본 및 편집 캔버스가 함께 스크롤되고 확대됩니다.",

  ZoomOut: "축소",
  ZoomIn: "확대",
  Minimize: "최소화",
  MinimizeDes: "캔버스 창 최소화",

  EditProcessAutoSaved: "편집 과정이 자동으로 저장됩니다!",
  SaveAsking: " 현재 파일을 저장하시겠습니까?",
  OpenFromLocal: "로컬에서 파일 열기",
  SaveFailed: "저장 실패!",
  Saving: "Saving...",
  Close: "닫다",
  Maximize: "최대화",
  MaximizeDes: "캔버스 창 최대화",
};
