import React from "react";
import { publicRuntimeConfig } from "@/next.config";
import { Button, Modal, Spin } from "antd";
import styles from "./alertModal.module.scss";
import useTrans from "../useTrans";

export default function AlertModal({
  visible,
  loading,
  text,
  handleAccept,
  handleCancel,
}) {
  return (
    <Modal
      visible={visible}
      footer={null}
      closable={false}
      title=""
      wrapClassName={styles.wrapNotification}
      width={260}
    >
      <Spin spinning={loading}>
        <div className={styles.notification}>
          <div>
            <img
              src={`${publicRuntimeConfig.basePath}/image/veluga_logo.png`}
              alt="veluga_logo"
              width="44"
              height="44"
            />
          </div>
          <div className={styles.text}>{text}</div>
          <div className={styles.btnWrapper}>
            <Button
              type="primary"
              className={styles.btnConfirm}
              onClick={handleAccept}
            >
              {useTrans("AcceptButton")}
            </Button>
            <Button
              type="primary"
              className={styles.btnCancel}
              onClick={handleCancel}
            >
              {useTrans(`CancelButton`)}
            </Button>
          </div>
        </div>
      </Spin>
    </Modal>
  );
}
