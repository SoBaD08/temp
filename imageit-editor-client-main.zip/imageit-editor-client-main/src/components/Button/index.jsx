import React from "react";
import styles from "./button.module.scss";
function Button({ title, onClick, style }) {
  return (
    <div className={styles.button} onClick={onClick} style={style}>
      {title}
    </div>
  );
}

export default Button;
