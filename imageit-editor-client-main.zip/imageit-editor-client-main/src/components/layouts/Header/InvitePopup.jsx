import React, { forwardRef, useState, useImperativeHandle } from "react";
import { Modal, Image, Select, Checkbox, Button, Input } from "antd";
import styles from "@src/components/layouts/Header/InvitePopup.module.scss";
import CloseIcon from "public/icons/header/Close_icon_modal.svg";
import SelectIcon from "public/icons/header/Select_Option_icon.svg";
import CopyLinkIcon from "@src/common/svg/CopyLink";
import useTrans from "@/src/common/useTrans";

// fake data API
const ListData = [
  {
    name: "Snoopy Junior Choi",
    permission: 1,
  },
  {
    name: "National Geographic",
    permission: 2,
  },
  {
    name: "Jico ",
    permission: 0,
  },
  {
    name: "Snoopy Junior Choi",
    permission: 1,
  },
  {
    name: "National Geographic",
    permission: 2,
  },
  {
    name: "Jico ",
    permission: 1,
  },
];
const PermissionId = {
  owner: 0,
  canView: 1,
  canEdit: 2,
};
const ListPermission = [
  {
    id: PermissionId.owner,
    title: "owner",
  },
  {
    id: PermissionId.canView,
    title: "can view",
  },
  {
    id: PermissionId.canEdit,
    title: "can edit",
  },
];
export const CustomSelect = ({ children, ...props }) => {
  return (
    <Select
      {...props}
      bordered={false}
      allowClear={false}
      className="custom-select"
      placeholder="Permission"
      showSearch={false}
      suffixIcon={
        <Image
          width={13}
          height={11}
          src={SelectIcon.src}
          alt="select option"
          preview={false}
        />
      }
    >
      {children}
    </Select>
  );
};
export const UserItem = ({ name, permission, SelectPermission }) => {
  return (
    <div className={styles.userItem}>
      <div className="name">
        <div className="icon">Y</div>
        <div>{name}</div>
      </div>

      <div>{SelectPermission}</div>
    </div>
  );
};
const InvitePopup = (props, ref) => {
  const [visible, setVisible] = useState(false);
  const onOpen = () => {
    setVisible(true);
  };
  const onCancel = () => {
    setVisible(false);
  };
  useImperativeHandle(ref, () => ({
    onOpen: onOpen,
  }));
  const SelectPermission = ({ defaultValue = ListPermission[0].id }) => (
    <CustomSelect defaultValue={defaultValue}>
      {ListPermission.map(({ id, title }) => (
        <Select.Option key={id} value={id} valueOption={{ id, title }}>
          {title}
        </Select.Option>
      ))}
    </CustomSelect>
  );
  return (
    <Modal
      visible={visible}
      onCancel={onCancel}
      width={700}
      title={<div className="title">{useTrans(`Invite`)}</div>}
      footer={
        <div className="footer">
          <div>
            <Checkbox>{useTrans(`AnyOneWithTheLink`)}</Checkbox>
          </div>
          <div>
            <SelectPermission />
          </div>
          <div>
            <Button className="btn-copy-link">
              <CopyLinkIcon />
              <div className="text">{useTrans(`CopyLink`)}</div>
            </Button>
          </div>
        </div>
      }
      closeIcon={
        <Image
          src={CloseIcon.src}
          alt="close icon"
          width={24}
          height={24}
          preview={false}
        />
      }
      className={styles.modalContainer}
    >
      <div className="body">
        <div className="search">
          <div className="search-input">
            <Input
              size="large"
              bordered={false}
              placeholder="Email, comma seperated"
            />
            <SelectPermission />
          </div>

          <div>
            <Button className="btn-send">{useTrans(`SendInvite`)}</Button>
          </div>
        </div>

        <div className="content">
          {ListData.map((item, index) => {
            return (
              <UserItem
                key={index}
                name={item.name}
                permission={item.permission}
                SelectPermission={
                  <SelectPermission defaultValue={item.permission} />
                }
              />
            );
          })}
        </div>
      </div>
    </Modal>
  );
};

export default forwardRef(InvitePopup);
