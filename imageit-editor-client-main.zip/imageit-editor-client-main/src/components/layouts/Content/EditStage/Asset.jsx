import { useImageData } from "@/src/common/ImageData";
import React, { useRef, useEffect, useLayoutEffect } from "react";
import { render } from "react-dom";
import { Stage, Layer, Rect, Image, Transformer } from "react-konva";
import useImage from "use-image";

function Asset({
  ratio,
  stageEditScale,
  isSelected,
  image,
  onSelect,
  onChange,
  draggable,
  isEditLayer,
}) {
  const [img] = useImage(image.src);
  const assetRef = useRef(null);
  const trRef = useRef(null);

  useLayoutEffect(() => {
    if (img) {
      assetRef.current.cache();
    }
  }, [image, img, isSelected]);

  useEffect(() => {
    if (isSelected) {
      // we need to attach transformer manually
      //trRef.current.nodes([shapeRef.current]);
      trRef.current.setNode(assetRef.current);
      trRef.current.getLayer().batchDraw();
    }
  }, [isSelected]);

  return (
    <>
      <Image
        ref={assetRef}
        width={(image.width * ratio) / stageEditScale}
        height={(image.height * ratio) / stageEditScale}
        image={img}
        x={image.x * ratio}
        y={image.y * ratio}
        // I will use offset to set origin to the center of the image
        offsetX={(image.width * ratio) / 2}
        offsetY={(image.height * ratio) / 2}
        draggable={draggable}
        onDragEnd={(e) => {
          onChange({
            ...image,
            x: e.target.x() / ratio,
            y: e.target.y() / ratio,
          });
        }}
        onClick={(e) => {
          e.cancelBubble = true;
          e.target.preventDefault();
          onSelect();
        }}
        onTransformEnd={(e) => {
          // transformer is changing scale of the node
          // and NOT its width or height
          // but in the store we have only width and height
          // to match the data better we will reset scale on transform end
          const node = assetRef.current;
          const scaleX = node.scaleX();
          const scaleY = node.scaleY();

          // we will reset it back
          onChange({
            ...image,
            x: node.x() / ratio,
            y: node.y() / ratio,
            // set minimal value
            width: Math.max(5, node.width() * scaleX) / ratio,
            height: Math.max(5, node.height() * scaleY) / ratio,
          });
          // bi giat do phan node.scale()
          node.scaleX(1);
          node.scaleY(1);
        }}
      />
      {(isSelected || isEditLayer) && (
        <Transformer
          ref={trRef}
          boundBoxFunc={(oldBox, newBox) => {
            // limit resize
            if (newBox.width < 5 || newBox.height < 5) {
              return oldBox;
            }
            return newBox;
          }}
        />
      )}
    </>
  );
}

export default Asset;
