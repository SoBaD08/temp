import React, { useState, useEffect, useRef } from "react";
import styles from "./extractText.module.scss";
import { Radio, Space, Checkbox, Switch } from "antd";
import { useTextData } from "@/src/common/TextData";
import ImageITProvider from "@/pages/api/ImageITProvider";
import { useImageData } from "@/src/common/ImageData";
import { useHistory } from "@/src/common/History";
import { urltoFile } from "@/src/common/helper";
import { useEditorMode } from "@common/EditorMode/index";
import { v4 as uuidv4 } from "uuid";
import { message } from "antd";
import AlertModal from "@/src/common/AlertModal";
import { checkEnv } from "@/pages/authen/RouteGuard";
import { useButtonMode } from "src/common/Buttons/index";
import { BUTTONS } from "src/common/Buttons/constant";
import useTrans from "@/src/common/useTrans";

const MODE_SELECT_ALL = 1;
const MODE_SELECT_ONLY = 2;
function ExtractText() {
  const {
    textData,
    setTextData,
    TopZindex,
    setDisplayLine,
    isDisplayLine,
    inpaint,
    setInpaint,
    multipleSelect,
    setMultipleSelect,
    filesetId,
  } = useTextData();
  const {
    defaultImage,
    setNewEditImage,
    setLoading,
    defaultImageUid,
    setDefaultImageUid,
    newEditImage,
    nameDefaultImage,
  } = useImageData();

  const { setMode } = useEditorMode();
  const { buttonMode, setButtonMode } = useButtonMode();
  const [isDisplayOption, setDisplayOption] = useState(false);

  const [modeSelect, setModeSelect] = useState(1);
  const onChangeModeSelect = (e) => {
    let value = e?.target?.value || 1;
    setModeSelect(value);
  };
  const onChangeCheckbox = (e) => {
    setInpaint(e.target.checked);
  };
  const onChangeSwitch = (e) => {
    setDisplayLine(e);
  };
  const { setHistory, folder } = useHistory();
  const isDisable = !textData.length;
  const CanNotExtractText = useTrans(`CanNotExtract`);
  const extractText = async () => {
    setLoading(true);
    try {
      let mediaId = defaultImageUid;
      if (!mediaId) {
        const origin = await urltoFile(
          newEditImage.url,
          `${nameDefaultImage}.png`,
          "image/png"
        );
        mediaId = await ImageITProvider.postFileImage({
          file: origin,
          application: "ocr",
          model: folder._id,
        });
      }
      const res = await ImageITProvider.ocrInpain({
        mediaId: mediaId._id,
        fileset: filesetId,
      });
      // setNewEditImage({ ...newEditImage, url: res.media.signedUrl });
      const tempArr = [];
      res.forEach((item, index) => {
        const width =
          item.rectangle_coordinates[1].x - item.rectangle_coordinates[0].x;
        const height =
          item.rectangle_coordinates[2].y - item.rectangle_coordinates[0].y;
        tempArr.push({
          ...item,
          id: uuidv4(),
          isLock: false,
          isView: true,
          zIndex: index + TopZindex.current,
          width: width,
          height: height,
          aspectRatio: width / height,
          degree: 0,
        });
      });
      TopZindex.current += tempArr.length;
      setTextData(tempArr);
      setHistory({
        // newEditImage: { ...newEditImage, url: res.media.signedUrl },
        textData: tempArr,
      });

      setDefaultImageUid(mediaId);
      setLoading(false);
      setMode(1);
      setDisplayLine(true);
    } catch (error) {
      console.log(error);
      if (error.response.status === 402) {
        setDisplayOption(true);
      } else {
        message.error(CanNotExtractText, [5]);
      }
      setLoading(false);
    }
  };
  const UploadFail = useTrans(`UploadFail`);
  const handleRemoveBG = async (blocks, textDataSelect) => {
    setLoading(true);
    try {
      let mediaId = defaultImageUid;
      if (!mediaId) {
        const origin = await urltoFile(
          newEditImage.url,
          `${nameDefaultImage}.png`,
          "image/png"
        );
        mediaId = await ImageITProvider.postFileImage({
          file: origin,
          application: "remove-object/mask",
          model: folder._id,
        });
      }

      const res2 = await ImageITProvider.remove({
        mediaId: mediaId._id,
        blocks: blocks,
        fileset: filesetId,
      });
      const resultImage = res2.signedUrl;
      setNewEditImage({ ...newEditImage, url: resultImage });
      setHistory({
        newEditImage: { ...newEditImage, url: resultImage },
        textData: textDataSelect,
      });
      setDefaultImageUid(res2);
      setLoading(false);
      setButtonMode(null);
      setMode(1);
    } catch (error) {
      console.log(error);
      message.error(UploadFail);
      setLoading(false);
    }
  };
  const SelectText = useTrans(`SelectText`);
  const onClickExecute = (e) => {
    if (isDisable) {
      e.preventDefault();
    } else {
      if (modeSelect == MODE_SELECT_ALL) {
        let textDataSelect = [...textData].map((item) => ({
          ...item,
          selected: true,
        }));
        setTextData(textDataSelect);
        const blocks = [];
        if (inpaint) {
          [...textData].forEach((item) => {
            blocks.push([
              {
                x: item.rectangle_coordinates[0].x,
                y: item.rectangle_coordinates[0].y,
              },
              {
                x: item.rectangle_coordinates[1].x,
                y: item.rectangle_coordinates[1].y,
              },
              {
                x: item.rectangle_coordinates[2].x,
                y: item.rectangle_coordinates[2].y,
              },
              {
                x: item.rectangle_coordinates[3].x,
                y: item.rectangle_coordinates[3].y,
              },
            ]);
          });
          handleRemoveBG(blocks, textDataSelect);
          setDisplayLine(false);
        }
      } else if (modeSelect == MODE_SELECT_ONLY) {
        if (!multipleSelect || !multipleSelect.length) {
          message.error(SelectText);
          return;
        }
        let textDataSelect = [...textData].map((item) => {
          let isSelected =
            !!item.selected ||
            Boolean(
              multipleSelect.findIndex((text) => text.id == item.id) >= 0
            );
          return {
            ...item,
            selected: isSelected,
          };
        });
        const blocks = [];
        setTextData(textDataSelect);
        if (inpaint) {
          textDataSelect.forEach((item) => {
            if (item.selected) {
              blocks.push([
                {
                  x: item.rectangle_coordinates[0].x,
                  y: item.rectangle_coordinates[0].y,
                },
                {
                  x: item.rectangle_coordinates[1].x,
                  y: item.rectangle_coordinates[1].y,
                },
                {
                  x: item.rectangle_coordinates[2].x,
                  y: item.rectangle_coordinates[2].y,
                },
                {
                  x: item.rectangle_coordinates[3].x,
                  y: item.rectangle_coordinates[3].y,
                },
              ]);
            }
          });
          handleRemoveBG(blocks, textDataSelect);
          setDisplayLine(false);
        }
        setMultipleSelect([]);
      } else return;
    }
  };
  useEffect(() => {
    if (buttonMode && buttonMode == BUTTONS.EXTRACT_TEXT) {
      setDisplayLine(true);
    }
    return () => {
      setDisplayLine(false);
    };
  }, [buttonMode]);
  return (
    <div className={styles.mainContainer}>
      <div className={styles.textDetectionContainer}>
        <span className={styles.title}>{useTrans(`TextDetect`)}</span>
        <div className={styles.buttonContainer} onClick={extractText}>
          {useTrans("Execute")}
        </div>
      </div>
      <div
        className={`${styles.textExtractorContainer} ${
          !textData.length ? styles.textExtractorContainerDisable : ""
        }`}
      >
        <span
          className={styles.title}
          style={{ color: isDisable ? "#C8C8CE" : "#2E2E32" }}
        >
          {useTrans(`TextExtract`)}
        </span>
        <div className={styles.radioButtonContainer}>
          <Radio.Group
            onChange={onChangeModeSelect}
            value={modeSelect}
            disabled={isDisable}
          >
            <Space direction="vertical">
              <Radio value={1}>{useTrans(`All`)}</Radio>
              <Radio value={2}>{useTrans(`SelectedOnly`)}</Radio>
            </Space>
          </Radio.Group>
        </div>
        <div className={styles.checkboxContainer}>
          <Checkbox
            onChange={onChangeCheckbox}
            checked={inpaint}
            disabled={isDisable}
          >
            {useTrans("Inpainting")}
          </Checkbox>
        </div>
        <div
          id="execute"
          className={styles.buttonContainer}
          style={{
            marginLeft: "137px",
            backgroundColor: !isDisable ? "#6F64FA" : "#C8C8CE",
            border: !isDisable ? "#6F64FA" : "#C8C8CE",
          }}
          onClick={(e) => onClickExecute(e)}
        >
          {useTrans(`Execute`)}
        </div>
      </div>
      <div className={styles.textDetectLineContainer}>
        <span className={styles.switchContainer}>
          <Switch
            size="small"
            checked={isDisplayLine}
            onChange={onChangeSwitch}
            disabled={isDisable}
          />
        </span>

        <span>{useTrans(`TextLine`)}</span>
      </div>
      <AlertModal
        visible={isDisplayOption}
        loading={null}
        handleAccept={() =>
          window.location.replace(
            `https://${checkEnv(window.location.href)}imageit.io/pricing`
          )
        }
        handleCancel={() => setDisplayOption(false)}
        text={
          <>
            <div>{useTrans("CreditLine1")}</div>
            <div>{useTrans("CreditLine2")}</div>
          </>
        }
      />
    </div>
  );
}

export default ExtractText;
