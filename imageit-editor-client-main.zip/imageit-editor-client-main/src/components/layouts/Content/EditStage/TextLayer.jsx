import Moveable from "@src/common/WrapMove";
import { ContentState, Editor, EditorState, RichUtils } from "draft-js";
import DraftPasteProcessor from "draft-js/lib/DraftPasteProcessor";
import html2canvas from "html2canvas";
import { useEffect, useRef } from "react";
import { Group, Image, Layer, Rect, Text } from "react-konva";
import { Html } from "react-konva-utils";
import stylesEdit from "./editStage.module.scss";
import { convertNumber, getCurrentRotation } from "@common/helper";
import { v4 as uuidv4 } from "uuid";
import { BUTTONS } from "src/common/Buttons/constant";
const KEY_CODE_ESC = 27;
const TextLayer = (props) => {
  const {
    layerTextDataRef,
    textData,
    indexEditText,
    selectedText,
    selectedBlock,
    multipleSelect,
    isDisplayLine,
    buttonMode,
    ratio,
    setMultipleSelect,
    currentMode,
    setBlock,
    setSelectText,
    editText,
    setEditText,
    setTextEditing,
    setPosition,
    setIndexEditText,
    textEditing,
    callBackOnChangeMode,
    image,
    position,
    styleMap,
    TopZindex,
    setMode,
    setTextData,
    setCallBackOnChangeMode,
    setHistory,
    setButtonMode,
  } = props;
  const textImageCanvasRef = useRef();
  const delayClick = useRef(0);
  const editorRef = useRef();
  const textBoxRef = useRef();

  useEffect(() => {
    if (textImageCanvasRef.current) {
      const nativeCtx = textImageCanvasRef.current?.getContext()?._context;
      if (nativeCtx) {
        nativeCtx.webkitImageSmoothingEnabled = false;
        nativeCtx.mozImageSmoothingEnabled = false;
        nativeCtx.imageSmoothingEnabled = false;
      }
    }
  });
  useEffect(() => {
    if (textEditing) {
      setTimeout(() => {
        if (textBoxRef.current) {
          textBoxRef.current.focus();
        }
        if (editorRef.current) {
          editorRef.current.focus();
        }
      }, 200);
    }
  }, [textEditing, JSON.stringify(position)]);
  useEffect(() => {
    if (callBackOnChangeMode || callBackOnChangeMode === 0) {
      submitText();
    }
  }, [callBackOnChangeMode]);
  const handleUserKeyPress = (e) => {
    if (e.keyCode == KEY_CODE_ESC) {
      e.preventDefault();
      e.cancelBubble = true;
      submitText();
    }
  };
  useEffect(() => {
    window.addEventListener("keydown", handleUserKeyPress);
    if (!textEditing) {
      setEditText(null);
    }
    return () => {
      window.removeEventListener("keydown", handleUserKeyPress);
    };
  }, [editText, textEditing]);

  const handleMultipleSelect = (item) => {
    const tempArr = multipleSelect ? [...multipleSelect, item] : [item];
    setMultipleSelect([...tempArr]);
  };

  const handleClickText = (e, item) => {
    e.target.preventDefault();
    e.evt.preventDefault();
    e.cancelBubble = true;
    if (!item?.selected) {
      if (
        buttonMode == BUTTONS.EXTRACT_TEXT ||
        buttonMode == BUTTONS.TRANSLATION
      ) {
        handleSelectText(e, item);
      } else {
        return;
      }
    } else if (editText && textEditing) {
      // debounce prevent multiple click
      if (delayClick.current) {
        clearTimeout(delayClick.current);
        delayClick.current = 0;
      }
      delayClick.current = setTimeout(function () {
        setBlock(item.id);
        setSelectText(null);
        setCallBackOnChangeMode({
          type: "changeText",
          index: item.index,
          e: e,
        });
      }, 400);
    } else if (
      buttonMode == BUTTONS.EXTRACT_TEXT ||
      buttonMode == BUTTONS.TRANSLATION
    ) {
      handleSelectText(e, item);
    } else {
      if (delayClick.current) {
        clearTimeout(delayClick.current);
        delayClick.current = 0;
      }

      switch (e.evt.detail) {
        case 1:
          delayClick.current = setTimeout(function () {
            handleSelectText(e, item);
          }, 500); // should match OS multi-click speed
          break;
        default:
          handleDbClickText(e, item);
          break;
      }
    }
  };
  const handleSelectText = (e, item) => {
    e.cancelBubble = true;
    e.target.preventDefault();
    if (editText && textEditing) {
      setCallBackOnChangeMode({ type: "changeText", index: item.index, e: e });
    }
    if (
      buttonMode == 1 ||
      buttonMode == 4 ||
      currentMode == 1 ||
      currentMode == 4
    ) {
      if (e.evt.ctrlKey || e.evt.metaKey) {
        handleMultipleSelect(item);
      } else {
        setBlock(item.id);
        setSelectText(null);
        setMultipleSelect([item]);
      }
    } else {
      return;
    }
  };

  const handleDbClickText = async (e, item) => {
    e.target.preventDefault();
    e.cancelBubble = true;

    // check editing -> submit before eidt new text
    if (editText) {
      setCallBackOnChangeMode({ type: "changeText", index: item.index, e: e });
      return;
    }
    setBlock(item.id);
    setSelectText(null);
    changeEditText(item.index, e);
  };

  const changeEditText = (index, e) => {
    let newList = [...textData];
    let text = newList.slice(index, index + 1).pop();
    newList[index].isView = false;
    // rich text
    let textEditor = text.editorText;
    if (!textEditor) {
      const processedHTML = DraftPasteProcessor.processHTML(
        text.translatedText ? text.translatedText : text.original_text
      );
      const contentState = ContentState.createFromBlockArray(processedHTML);
      //move focus to the end.
      textEditor = EditorState.createWithContent(contentState);
      textEditor = EditorState.moveFocusToEnd(textEditor);
    }

    // position text
    let ratioText = ratio;
    let positionText = {
      left: text.rectangle_coordinates[0].x / ratioText,
      top: text.rectangle_coordinates[0].y / ratioText,
      width:
        (text.rectangle_coordinates[1].x - text.rectangle_coordinates[0].x) /
          ratioText +
        5,
      height:
        (text.rectangle_coordinates[2].y - text.rectangle_coordinates[0].y) /
          ratioText +
        5,
    };
    setBlock(text.id);
    setSelectText(null);
    setEditText(textEditor);
    setTextEditing(true);
    setPosition(positionText);
    setIndexEditText(index);
  };
  const handleDragEnd = (e, layer, border = 0) => {
    let moveX = e.target.x() - layer.rectangle_coordinates[0].x;
    let moveY = e.target.y() - layer.rectangle_coordinates[0].y;
    let new_rectangle_coordinates = layer.rectangle_coordinates.map((item) => ({
      x: item.x + moveX - border,
      y: item.y + moveY - border,
    }));
    let indexSelect = -1; // find Index of select text to update textData array
    for (let i = 0; i < textData.length; i++) {
      if (textData[i].id == layer.id) {
        indexSelect = i;
        break;
      }
    }
    let newLayer = {
      ...layer,
      rectangle_coordinates: new_rectangle_coordinates,
    };
    setTextData((prev) => {
      let newTextData = [...prev];
      newTextData[indexSelect] = newLayer;
      return newTextData;
    });
    setSelectText(newLayer);
  };
  const handleClick = (e) => {
    e.target.preventDefault();
    e.evt.preventDefault();
    e.cancelBubble = true;
    // debounce prevent multiple click
    if (delayClick.current) {
      clearTimeout(delayClick.current);
      delayClick.current = 0;
    }
    delayClick.current = setTimeout(function () {
      if (textEditing) {
        submitText();
      } else {
        createText(e);
      }
    }, 200);
  };
  const onChangeText = (newText) => {
    setEditText(newText);
  };

  const handleKeyCommand = (command, editorState) => {
    const newState = RichUtils.handleKeyCommand(editorState, command);
    if (newState) {
      onChangeText(newState);
      return "handled";
    }
    return "not-handled";
  };

  const getBlockStyle = (block) => {
    switch (block.getType()) {
      case "left":
        return "align-left";
      case "center":
        return "align-center";
      case "right":
        return "align-right";
      default:
        return null;
    }
  };
  const createText = (e) => {
    // position mouse click
    let left = e.evt.layerX;
    let top = e.evt.layerY;
    setTextEditing(true);
    setPosition({ left: left, top: top });
    setEditText(EditorState.createEmpty());
    setMode(1);
  };

  const submitText = () => {
    let retrieveText =
      editText && editText.getCurrentContent().getPlainText("\u0001");
    // delete when text = ""
    if (!retrieveText) {
      setTextEditing(false);
      setPosition(null);
      setEditText(null);
      if (indexEditText !== null) {
        let newList = [...textData];
        newList.splice(indexEditText, 1);
        setTextData(newList);
        setHistory({ textData: newList });
      }
      setIndexEditText(null);
      return;
    }
    if (!(textBoxRef.current && document.getElementById("ID_TextBox"))) {
      return;
    }
    // return canvas text
    html2canvas(document.querySelector("#ID_TextBox"), {
      backgroundColor: "transparent",
      // backgroundColor: Konva.Util.getRandomColor(),
      // scale: ratio > 1 ? ratio : 1,
    }).then((canvas) => {
      // show it inside Konva.Image
      const target = textBoxRef.current?.style;
      const transform = target?.transform;
      var matrix = new WebKitCSSMatrix(transform);
      const moveX = matrix.m41 || 0;
      const moveY = matrix.m42 || 0;
      let rotate = getCurrentRotation(document.getElementById("ID_TextBox"));
      let top = target?.top && (convertNumber(target?.top) + moveY) * ratio;
      let left = target?.left && (convertNumber(target?.left) + moveX) * ratio;
      let width = target?.width && convertNumber(target?.width) * ratio;
      let height = target?.height && convertNumber(target?.height) * ratio;
      let newTextData = [...textData];
      let newImageText = {
        ...newTextData[indexEditText],
        image: canvas,
        editorText: editText,
        original_text: retrieveText,
        translatedText: retrieveText,
        isLock: false,
        isView: true,
        width: width,
        height: height,
        rectangle_coordinates: [
          { x: left, y: top },
          { x: left + width, y: top },
          { x: left + width, y: top + height },
          { x: left, y: top + height },
        ],
        zIndex: ++TopZindex.current,
        selected: true,
      };
      if (indexEditText === null) {
        newImageText.id = uuidv4();
        newTextData.push(newImageText);
      } else {
        newTextData[indexEditText] = {
          ...newImageText,
        };
      }
      setTextEditing(false);
      if (callBackOnChangeMode?.type != "changeText") {
        setSelectText(newImageText);
      }
      setTextData(newTextData);
      setEditText(null);
      setIndexEditText(null);
      setHistory({ textData: newTextData });
      if (callBackOnChangeMode) {
        if (callBackOnChangeMode.type == "mode") {
          setMode(callBackOnChangeMode.mode);
        } else if (callBackOnChangeMode.type == "buttonMode") {
          setButtonMode(callBackOnChangeMode.mode);
        } else if (callBackOnChangeMode.type == "changeText") {
          setTimeout(() => {
            changeEditText(callBackOnChangeMode.index, callBackOnChangeMode.e);
          }, 100);
        }
        setCallBackOnChangeMode(null);
      } else {
        setMode(1);
      }
    });
  };
  return (
    <Layer ref={layerTextDataRef} onClick={handleClick}>
      {(currentMode == 4 || editText) && (
        <Group scaleX={ratio} scaleY={ratio}>
          <>
            <Rect ref={textImageCanvasRef} />
            <Rect x={0} y={0} width={5000} height={5000} visible={true}></Rect>
            {editText && textEditing ? (
              <Html
                divProps={{
                  style: {
                    position: "absolute",
                    background: "#00000045",
                    width: image.width / ratio,
                    height: image.height / ratio,
                  },
                }}
              >
                <>
                  <Moveable
                    id="#ID_TextBox"
                    idTarget="#ID_DragTarget"
                    position={position}
                  />
                  <div
                    className={`${stylesEdit.editText} customsscroll`}
                    style={{
                      width: position?.width || "200px",
                      height: position?.height || "80px",
                      top: !isNaN(position?.top) ? position?.top : 50,
                      left: !isNaN(position?.left) ? position?.left : 50,
                      transform: `rotate(${position?.rotate}deg)`,
                      padding: "5px",
                    }}
                    id="ID_TextBox"
                    tabindex={-1}
                    ref={textBoxRef}
                    onClick={(e) => {
                      e.stopPropagation();
                    }}
                  >
                    <div
                      className={stylesEdit.dragTarget}
                      id="ID_DragTarget"
                      tabIndex={-1}
                    ></div>
                    <Editor
                      editorState={editText}
                      onChange={onChangeText}
                      handleKeyCommand={handleKeyCommand}
                      blockStyleFn={getBlockStyle}
                      customStyleMap={styleMap}
                      ref={editorRef}
                      tabIndex={-1}
                    />
                  </div>
                </>
              </Html>
            ) : null}
          </>
        </Group>
      )}
      {!!(textData && textData.length) &&
        ([...textData] || [])
          .map((item, index) => ({ ...item, index: index }))
          .sort((a, b) => a?.zIndex - b?.zIndex)
          ?.map((item, index) => {
            let attributeCommon = {
              id: item.id,
              key: index,
              item: item,
              x:
                item.rectangle_coordinates[0].x +
                (item?.flipX ? item.width : 0),
              y:
                item.rectangle_coordinates[0].y +
                (item?.flipY ? item?.height : 0),
              visible:
                item.isView && item.index != indexEditText && !!item.selected,
              draggable:
                (item.id === selectedText?.id || item.id === selectedBlock) &&
                item.isLock === false,
              onClick: (e) => handleClickText(e, item),
              onDragEnd: (e) => handleDragEnd(e, item, 0),
              onMouseEnter: (e) => {
                if (editText && textEditing) {
                  const container = e.target.getStage().container();
                  container.style.cursor = "text";
                }
              },
              onMouseLeave: (e) => {
                const container = e.target.getStage().container();
                container.style.cursor = "default";
              },
            };
            return (
              <>
                <Rect
                  {...attributeCommon}
                  visible={true}
                  width={item.width + 10}
                  height={item.height + 10}
                  strokeWidth={
                    (selectedBlock === item.id ||
                      multipleSelect?.some(
                        (select) => select?.id == item?.id
                      )) &&
                    (buttonMode == 1 || buttonMode == 4)
                      ? 2
                      : !isDisplayLine
                      ? 0
                      : 0.5
                  }
                  stroke={
                    (selectedBlock === item.id ||
                      multipleSelect?.includes(item)) &&
                    (buttonMode == 1 || buttonMode == 4)
                      ? "#EDF45F"
                      : "#FF1F47"
                  }
                />
                {item?.selected ? (
                  item?.image ? (
                    <Image
                      {...attributeCommon}
                      image={item.image}
                      width={item.width}
                      height={item.height}
                    />
                  ) : (
                    <Text
                      {...attributeCommon}
                      rotation={item.degree}
                      verticalAlign="top"
                      align="top"
                      text={
                        item.isShowTranslate
                          ? item.translatedText
                          : item.original_text
                      }
                      width={item.width}
                      height={item.height}
                      fontSize={14 * ratio}
                      fill="black"
                    />
                  )
                ) : null}
              </>
            );
          })}
    </Layer>
  );
};

export default TextLayer;
