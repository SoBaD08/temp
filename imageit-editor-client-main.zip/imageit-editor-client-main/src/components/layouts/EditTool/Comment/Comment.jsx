import React, { useCallback, useEffect, useRef, useState } from "react";
import { Input, Select, message, Spin } from "antd";
import SearchIcon from "@common/svg/SearchIcon";
import styles from "./Comment.module.scss";
import CardComment from "./CardComment";
import { useEditorMode } from "@/src/common/EditorMode";
import CommentProvider from "@/pages/api/CommentProvider";
import ImageITProvider from "@pages/api/ImageITProvider";
import { urltoFile } from "@common/helper";
import { useImageData } from "@common/ImageData";
import { useHistory } from "@/src/common/History";
import useTrans from "@/src/common/useTrans";

const KeyOptions = {
  recent: 0,
  resolved: 1,
  all: 2,
};
const FilterOptions = [
  {
    id: KeyOptions.recent,
    name: "Recent",
  },
  {
    id: KeyOptions.resolved,
    name: "Resolved",
  },
  {
    id: KeyOptions.all,
    name: "All",
  },
];
const Comment = (props) => {
  const { listComment, setListComment, newComment, currentMode } =
    useEditorMode();
  const {
    defaultImage,
    defaultImageUid,
    setDefaultImageUid,
    nameDefaultImage,
  } = useImageData();
  const { folder, setHistory } = useHistory();

  const [listCommentView, setListCommentView] = useState(listComment);
  const [loading, setLoading] = useState(false);
  const searchCommetRef = useRef();

  const UploadImage = useTrans(`UploadImage`);
  const getAllComment = async () => {
    try {
      setLoading(true);
      if (!defaultImage?.url) {
        message.error(UploadImage);
        return;
      }
      let mediaId = defaultImage;
      if (!mediaId) {
        let orginUrl = defaultImage?.url;
        const origin = await urltoFile(
          orginUrl,
          `${nameDefaultImage}.png`,
          "image/png"
        );
        mediaId = await ImageITProvider.postFileImage({
          file: origin,
          application: "image",
          model: folder._id,
        });
        setDefaultImageUid(mediaId);
        setDefaultImage({
          ...defaultImage,
          id: mediaId._id,
        });
      }
      let res = await CommentProvider.getComment({
        media: mediaId._id,
      });
      let { users, docs } = res;
      let comments = docs.map((item, i) => {
        return Object.assign({}, item, { user: users[i] });
      });
      setListComment(comments);
      setHistory({ comments: comments });
      setLoading(false);
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };

  const handleSearchComment = () => {
    if (!listComment || !listComment.length) {
      setListCommentView([]);
      return;
    }
    let value = (searchCommetRef.current?.input?.value || "")
      ?.trim()
      ?.toLowerCase();
    if (!value) {
      setListCommentView([...listComment]);
      return;
    }
    let commentView = ([...listComment] || []).filter((item, index) => {
      let content = (item?.content || "")?.trim()?.toLowerCase();
      if (!content) return false;
      return content?.includes(value);
    });
    setListCommentView(commentView);
  };

  const handleSortComment = (value) => {
    let newListCommentView = [];
    switch (value) {
      case 0:
        newListCommentView = [...listComment].filter((item) => !item.resolved);
        break;
      case 1:
        newListCommentView = [...listComment].filter((item) => item.resolved);
        break;
      case 2:
        newListCommentView = [...listComment];
        break;

      default:
        newListCommentView = [...listComment];
        break;
    }
    setListCommentView(newListCommentView);
  };

  useEffect(() => {
    getAllComment();
  }, [defaultImage, currentMode]);

  useEffect(() => {
    handleSearchComment();
  }, [listComment]);
  return (
    <div className={styles.comment}>
      <Spin size="default" spinning={loading}>
        <div className="filter">
          <Input
            placeholder={useTrans("Search")}
            prefix={<SearchIcon />}
            bordered={false}
            className="input-search"
            ref={searchCommetRef}
            onKeyDown={(e) => {
              if (e?.keyCode == 13) {
                handleSearchComment();
              }
            }}
          />
          <Select
            style={{ width: "86px" }}
            className="select"
            bordered={false}
            defaultValue={0}
            onSelect={handleSortComment}
          >
            {FilterOptions.map(({ id, name }) => {
              return (
                <Select.Option key={id} value={id} option={{ id, name }}>
                  {useTrans(name)}
                </Select.Option>
              );
            })}
          </Select>
        </div>
        <div className="wrap-card-comment">
          {newComment && (
            <CardComment
              type="create"
              index={newComment.index}
              getAllComment={getAllComment}
            />
          )}
          {listCommentView.map((comment, index) => {
            return (
              <CardComment
                key={comment?._id}
                index={listCommentView.length - index}
                userComment={comment?.user}
                updatedAt={comment?.updatedAt}
                content={comment?.content}
                comment={comment}
                type="submit"
                getAllComment={getAllComment}
              />
            );
          })}
        </div>
      </Spin>
    </div>
  );
};
export default Comment;
