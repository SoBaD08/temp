import React, {
  useState,
  useContext,
  useRef,
  Component,
  useEffect,
} from "react";
import UserProvider from "@/pages/api/UserProvider";
import ForderProvider from "@/pages/api/ForderProvider";
export const HistoryContext = React.createContext();

function HistoryProvider({ children }) {
  let folderId;
  if (typeof window !== "undefined") {
    folderId = localStorage.getItem("folderId");
  }
  const [history, _setHistory] = useState([]);
  const [user, setUser] = useState();
  const [project, setProject] = useState();
  const [folder, setFolder] = useState({});
  const [listMember, setListMember] = useState([]);

  const getForderInfo = async (folderId) => {
    try {
      let res = await ForderProvider.getFolderInfo(folderId);
      setFolder(res.data);
    } catch (err) {
      console.log(err);
    }
  };
  const getUserInfo = async () => {
    try {
      let res = await UserProvider.userInfo();
      let name = res?.name || res?.email;
      setUser({
        ...res,
        name: name,
      });
    } catch (error) {
      console.log(error);
    }
  };

  const getProjectInfo = async () => {
    try {
      let res = await UserProvider.projectInfo();
      let projectId = res[0]._id;
      let resMember = await UserProvider.getAllMember(projectId);
      setProject(res[0]);
      setListMember(resMember);
    } catch (error) {
      console.log(error);
    }
  };

  const historySteps = useRef(0);

  const setHistory = (data = {}) => {
    _setHistory((prev) => {
      let item = { ...data };
      if (historySteps.current) {
        item = {
          ...prev[historySteps.current - 1],
          ...data,
        };
      }
      let result = prev.slice(0, historySteps.current);
      historySteps.current = historySteps.current
        ? historySteps.current + 1
        : 1;
      result.push(item);
      return result;
    });
  };

  const setupHistory = (data) => {
    _setHistory([{ ...data }]);
    historySteps.current = 1;
  };

  const [layerCopy, setLayerCopy] = useState(null);

  useEffect(() => {
    getUserInfo();
    getProjectInfo();
    getForderInfo(folderId);
  }, []);

  return (
    <HistoryContext.Provider
      value={{
        user,
        project,
        listMember,
        folder,
        folderId,
        history,
        historySteps,
        layerCopy,
        setLayerCopy,
        setHistory,
        setupHistory,
        setFolder,
      }}
    >
      {children}
    </HistoryContext.Provider>
  );
}

const withHistory = (Component) => (props) => {
  return (
    <HistoryProvider>
      <Component {...props} />
    </HistoryProvider>
  );
};

export const useHistory = () => {
  const data = useContext(HistoryContext);
  return data;
};

export default withHistory;
