import React, { useState, useEffect } from "react";
import stylesRemoveBG from "./removeBG.module.scss";
import { Divider, Checkbox, Modal, Button, message } from "antd";
import { useImageData } from "../../../../common/ImageData";
import { useTextData } from "@/src/common/TextData";
import ImageITProvider from "@/pages/api/ImageITProvider";
import { urltoFile } from "@/src/common/helper";
import { publicRuntimeConfig } from "@/next.config";
import { useHistory } from "@/src/common/History";
import { checkEnv } from "@/pages/authen/RouteGuard";
import AlertModal from "@/src/common/AlertModal";
import useTrans from "@/src/common/useTrans";
function RemoveBG(props) {
  const [isDisplayNoti, setDisplayNoti] = useState(false);

  const [hideNotiBG, setHideNotiBG] = useState(false);

  const [isDisplayPopUp, setDisplayPopup] = useState(false);

  const [isDisplayOption, setDisplayOption] = useState(false);

  const { isCreateNewImageLayer, setCreateNewImageLayer, filesetId } =
    useTextData();
  const {
    selectImage,
    setLoading,
    newEditImage,
    setRemoveBGImage,
    removeBGImage,
    setNewEditImage,
    defaultImageUid,
    nameDefaultImage,
  } = useImageData();
  const onChange = (e) => {
    setHideNotiBG(e.target.checked);
  };

  const { folder, setHistory } = useHistory();

  const onChangeCreateLayer = (e) => {
    setCreateNewImageLayer(e.target.checked);
  };
  const CheckTheImage = useTrans(`CheckTheImage`);
  const removeBG = async () => {
    setLoading(true);
    try {
      let mediaId = defaultImageUid;
      if (!mediaId) {
        const origin = await urltoFile(
          newEditImage.url,
          `${nameDefaultImage}.png`,
          "image/png"
        );
        mediaId = await ImageITProvider.postFileImage({
          file: origin,
          application: "remove-bg/original",
          model: folder._id,
        });
      }
      const res = await ImageITProvider.removeBG({
        media: mediaId._id,
        fileset: filesetId,
      });
      if (isCreateNewImageLayer) {
        setRemoveBGImage({ ...removeBGImage, url: res.signedUrl });
        setNewEditImage({ ...newEditImage, isView: false });
        setHistory({
          removeBGImage: { ...removeBGImage, url: res.signedUrl },
          newEditImage: { ...newEditImage, isView: false },
        });
      } else {
        setNewEditImage({ ...newEditImage, url: res.signedUrl });
        setHistory({
          newEditImage: { ...newEditImage, url: res.signedUrl },
          newEditImage: { ...newEditImage, url: res.signedUrl },
        });
      }
      setLoading(false);
    } catch (error) {
      if (error.response.status === 402) {
        setDisplayOption(true);
      } else {
        message.error(CheckTheImage);
      }
      setLoading(false);
    }
  };
  useEffect(() => {
    if (localStorage.getItem("hideNotiBG") != null) {
      if (JSON.parse(localStorage.getItem("hideNotiBG")) === true) {
        setDisplayNoti(false);
      } else {
        setDisplayNoti(true);
      }
    } else {
      setDisplayNoti(true);
    }
  }, []);

  return (
    <div className={stylesRemoveBG.container}>
      <div className={stylesRemoveBG.title}>{useTrans(`RemoveObject`)}</div>
      {isDisplayNoti ? (
        <div className={stylesRemoveBG.notificationContainer}>
          <div className={stylesRemoveBG.infoIcon}>
            <img
              src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/info.svg`}
              alt=""
            />
          </div>

          <div className={stylesRemoveBG.mainContainer}>
            <p className={stylesRemoveBG.paragraph}>
              {useTrans(`RemoveBGTitle`)}
            </p>
            <div className={stylesRemoveBG.imageNoti}>
              <img
                src={`${publicRuntimeConfig.basePath}/image/RemoveBGNotification.png`}
                alt=""
              />
            </div>

            <p className={stylesRemoveBG.paragraph}>
              {useTrans(`DescriptionRemoveBg`)}
            </p>
            <div>
              <Divider />
            </div>
            <div>
              <Checkbox onChange={onChange} style={{ fontSize: "10px" }}>
                {useTrans(`DoNotShowAgain`)}
              </Checkbox>
            </div>
            <div className={stylesRemoveBG.closeButtonContainer}>
              <div
                className={stylesRemoveBG.closeButton}
                onClick={() => {
                  localStorage.setItem("hideNotiBG", hideNotiBG);
                  setDisplayNoti(false);
                }}
              >
                {useTrans(`Close`)}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className={stylesRemoveBG.removeBGContent}>
          <Checkbox
            checked={isCreateNewImageLayer}
            onChange={onChangeCreateLayer}
            disabled={!selectImage}
          >
            {useTrans(`CreateNewLayer`)}{" "}
          </Checkbox>

          <div
            id="execute"
            className={stylesRemoveBG.buttonContainer}
            style={{
              marginLeft: "137px",
              backgroundColor: selectImage ? "#6F64FA" : "#C8C8CE",
              border: selectImage ? "#6F64FA" : "#C8C8CE",
            }}
            onClick={() => {
              if (!selectImage) {
                setDisplayPopup(true);
              } else {
                removeBG();
              }
            }}
          >
            {useTrans(`Execute`)}
          </div>
          <AlertModal
            visible={isDisplayOption}
            loading={null}
            handleAccept={() =>
              window.location.replace(
                `https://${checkEnv(window.location.href)}imageit.io/pricing`
              )
            }
            handleCancel={() => setDisplayOption(false)}
            text={
              <>
                <div>{useTrans(`CreditLine1`)}</div>
                <div>{useTrans(`CreditLine2`)}</div>
              </>
            }
          />
          <Modal
            visible={isDisplayPopUp}
            footer={null}
            closable={false}
            title=""
            wrapClassName={stylesRemoveBG.wrapNotification}
            width={540}
          >
            <div className={stylesRemoveBG.notification}>
              <div>
                <img
                  src={`${publicRuntimeConfig.basePath}/image/veluga_logo.png`}
                  alt="veluga_logo"
                  width="72"
                  height="72"
                />
              </div>
              <div className={stylesRemoveBG.text}>
                {useTrans(`SelectImage`)}
              </div>
              <Button
                type="primary"
                style={{ marginBottom: "16px" }}
                className={stylesRemoveBG.btnConfirm}
                onClick={() => {
                  setDisplayPopup(false);
                }}
              >
                {useTrans(`Oke`)}
              </Button>
            </div>
          </Modal>
          <Divider />
        </div>
      )}
    </div>
  );
}

export default RemoveBG;
