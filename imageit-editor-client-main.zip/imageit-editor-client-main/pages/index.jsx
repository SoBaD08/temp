import React from "react";
import styles from "../styles/dashboard.module.scss";
import withEditorMode from "../src/common/EditorMode/index";
import Menu from "../src/components/layouts/Menu/index";
import Header from "../src/components/layouts/Header/index";
import Navbar from "../src/components/layouts/Navbar/index";
import Option from "../src/components/layouts/Option/index";
import compose from "../src/common/utils/compose";
import EditTool from "../src/components/layouts/EditTool/index";
import Content from "../src/components/layouts/Content/index";
import withButtonMode from "../src/common/Buttons";
import withZoomMode from "../src/common/ZoomMode/index";
import withImageData from "../src/common/ImageData";
import withTextData from "../src/common/TextData";
import withHistory from "../src/common/History";
function Layout() {
  return (
    <div>
      <div>
        <Header />
        <Navbar />
      </div>
      <div className={styles.body}>
        <Menu />
        <Option />
        <Content />
        <EditTool />
      </div>
    </div>
  );
}

const Dashboard = (props) => {
  return (
    <div className={styles.container}>
      <Layout />
    </div>
  );
};

export default compose([
  withHistory,
  withEditorMode,
  withButtonMode,
  withZoomMode,
  withImageData,
  withTextData,
])(Dashboard);
