import React, { useState, useEffect } from "react";
import styles from "./translation.module.scss";
import modalStyles from "../../Header/header.module.scss";
import { Select, Modal, Button, Checkbox, message } from "antd";
import { ArrowDownOutlined } from "@ant-design/icons";
import { useTextData } from "../../../../common/TextData";
import ImageITProvider from "../../../../../pages/api/ImageITProvider";
import { useImageData } from "../../../../common/ImageData";
import { useHistory } from "@src/common/History";
import { publicRuntimeConfig } from "@/next.config";
import AlertModal from "@/src/common/AlertModal";
import { checkEnv } from "@/pages/authen/RouteGuard";
import useTrans from "@/src/common/useTrans";
function Translation(props) {
  const { setHistory } = useHistory();
  const [translateMode, setTranslateMode] = useState("selected");
  const [sourceLanguage, setSourceLanguage] = useState("ko");
  const [targetLanguage, setTargetLanguage] = useState("en");
  const [translateTool, setTranslateTool] = useState("google");
  const [isDisplayPopUp, setDisplayPopup] = useState(false);
  const [isDisplayOption, setDisplayOption] = useState(false);
  const [isCallAPI, setIsCallAPI] = useState(false);
  const { selectedText, setTextData, textData, multipleSelect } = useTextData();
  const { folder } = useHistory();
  const { setLoading, loading } = useImageData();
  const { Option } = Select;
  const optionsMethod = [
    { label: "TranslateAll", value: "all" },
    { label: "TranslateSelected", value: "selected" },
  ];
  const onChangeMethod = (e) => {
    setTranslateMode(e.target.value);
  };
  const languageOption = [
    { label: "Korean", value: "ko" },
    { label: "English", value: "en" },
    { label: "Chinese", value: "zh" },
    { label: "Japanese", value: "ja" },
    { label: "Vietnamese", value: "vi" },
  ];
  const renderLanguage = () => {
    return languageOption.map((item) => (
      <Option value={item.value} key={item.label}>
        {item.label}
      </Option>
    ));
  };

  const translateToolOption = [
    { label: "Google", value: "google" },
    // { label: "Papago", value: "papago" },
  ];
  const renderTool = () => {
    return translateToolOption.map((item) => (
      <Option value={item.value} key={item.label}>
        {item.label}
      </Option>
    ));
  };
  useEffect(() => {
    setIsCallAPI(true);
  }, [targetLanguage]);
  const CheckTheLanguage = useTrans("CheckTheLanguage");
  const translateAll = async () => {
    if (translateMode === "selected") {
      if (!selectedText && !multipleSelect.length) {
        setDisplayPopup(true);
        return;
      }
    }
    setLoading(true);
    try {
      let temp = [];
      textData.forEach((item) => temp.push(item.original_text));
      let tempArray = [...textData];
      if (!isCallAPI) {
        for (let i = 0; i < tempArray.length; i++) {
          const current = tempArray[i];
          if (translateMode === "all") {
            tempArray[i] = {
              ...current,
              isShowTranslate: true,
            };
          } else {
            if (multipleSelect?.length) {
              for (let j = 0; j < multipleSelect.length; j++) {
                if (tempArray[i].id === multipleSelect[j].id) {
                  tempArray[i] = {
                    ...current,
                    isShowTranslate: true,
                  };
                } 
              }
            }
            if (selectedText) {
              if (tempArray[i].id === selectedText.id) {
                tempArray[i] = {
                  ...current,
                  isShowTranslate: true,
                };
              }
            }
          }
        }
      } else {
        const res = await ImageITProvider.translateSelected({
          type: translateTool,
          source: sourceLanguage,
          target: targetLanguage,
          texts: temp,
          modelType: "Folder",
          model: folder._id,
        });
        const arrayString = res.result;
        for (let i = 0; i < tempArray.length; i++) {
          const current = tempArray[i];
          if (translateMode === "all") {
            tempArray[i] = {
              ...current,
              isShowTranslate: true,
              translatedText: arrayString[i].result,
            };
          } else {
            if (multipleSelect?.length) {
              for (let j = 0; j < multipleSelect.length; j++) {
                if (tempArray[i].id === multipleSelect[j].id) {
                  tempArray[i] = {
                    ...current,
                    isShowTranslate: true,
                    translatedText: arrayString[i].result,
                  };
                } else {
                  tempArray[i] = {
                    ...current,
                    isShowTranslate: false,
                    translatedText: arrayString[i].result,
                  };
                }
              }
            }
            if (selectedText) {
              if (tempArray[i].id === selectedText.id) {
                tempArray[i] = {
                  ...current,
                  isShowTranslate: true,
                  translatedText: arrayString[i].result,
                };
              } else {
                tempArray[i] = {
                  ...current,
                  isShowTranslate: false,
                  translatedText: arrayString[i].result,
                };
              }
            }
          }
        }
        setIsCallAPI(false);
      }

      setTextData([...tempArray]);
      setLoading(false);
    } catch (error) {
      if (error.response?.status === 402) {
        setDisplayOption(true);
      } else {
        message.error(CheckTheLanguage);
      }
      setLoading(false);
    }
  };
  return (
    <div className={styles.container}>
      <div className={styles.title}>{useTrans(`Translation`)}</div>
      <div className={styles.checkBox}>
        {optionsMethod.map((item) => {
          return (
            <div className={styles.checkBoxItem}>
              <Checkbox
                key={item.label}
                onChange={onChangeMethod}
                checked={item.value === translateMode}
                value={item.value}
              >
                {useTrans(item.label)}
              </Checkbox>
            </div>
          );
        })}
      </div>
      <div className={styles.languageOption}>
        <Select
          defaultValue="google"
          style={{
            width: 232,
            height: 36,
            marginBottom: "20px",
          }}
          onChange={(e) => {
            setTranslateTool(e);
          }}
        >
          {renderTool()}
        </Select>
      </div>
      <div className={styles.languageOption}>
        <Select
          defaultValue="Korean"
          style={{
            width: 232,
            height: 36,
          }}
          onChange={(e) => setSourceLanguage(e)}
        >
          {renderLanguage()}
        </Select>
      </div>
      <div className={styles.iconContainer}>
        <ArrowDownOutlined />
      </div>

      <div className={styles.languageOption}>
        <Select
          defaultValue="English"
          style={{
            width: 232,
            height: 36,
          }}
          onChange={(e) => setTargetLanguage(e)}
        >
          {renderLanguage()}
        </Select>
      </div>
      <div className={styles.translationButton}>
        <Button
          onClick={() => {
            if (translateMode === "all") {
              translateAll();
            } else {
              if (!selectedText && !multipleSelect.length) {
                setDisplayPopup(true);
              } else {
                translateAll();
              }
            }
          }}
        >
          {useTrans(`Translation`)}
        </Button>
      </div>
      <Modal
        visible={isDisplayPopUp}
        footer={null}
        closable={false}
        title=""
        wrapClassName={modalStyles.wrapNotification}
        width={540}
        height={288}
      >
        <div className={modalStyles.notification}>
          <div>
            <img
              src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/Warning.svg`}
              alt="veluga_logo"
              width="76"
              height="76"
            />
          </div>
          <div className={modalStyles.text}>
            {useTrans(`SelectTextTranslate`)}
          </div>
          <Button
            type="primary"
            style={{ marginBottom: "16px" }}
            className={modalStyles.btnConfirm}
            onClick={() => {
              setDisplayPopup(false);
            }}
          >
            {useTrans(`Oke`)}
          </Button>
        </div>
      </Modal>
      <AlertModal
        visible={isDisplayOption}
        loading={null}
        handleAccept={() =>
          window.location.replace(
            `https://${checkEnv(window.location.href)}imageit.io/pricing`
          )
        }
        handleCancel={() => setDisplayOption(false)}
        text={
          <>
            <div>{useTrans(`CreditLine1`)}</div>
            <div>{useTrans(`CreditLine2`)}</div>
          </>
        }
      />
    </div>
  );
}

export default Translation;
