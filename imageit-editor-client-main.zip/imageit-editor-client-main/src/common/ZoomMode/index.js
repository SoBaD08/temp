import React, { useContext, useState } from "react";

const ZoomContext = React.createContext();

export const ZOOM_MODE = {
  EDIT: "edit",
  SOURCE: "source",
};

function ZoomProvider({ children }) {
  const [stageEditScale, setStageEditScale] = useState(1);
  const [stageSourceScale, setStageSourceScale] = useState(1);
  const [isSync, setSync] = useState(true);
  const [zoomMode, setZoomMode] = useState(null);

  return (
    <ZoomContext.Provider
      value={{
        stageEditScale,
        stageSourceScale,
        isSync,
        zoomMode,
        setSync,
        setStageEditScale,
        setStageSourceScale,
        setZoomMode,
      }}
    >
      {children}
    </ZoomContext.Provider>
  );
}
const withZoomMode = (Component) => (props) => {
  return (
    <ZoomProvider>
      <Component {...props} />
    </ZoomProvider>
  );
};

export const useZoom = () => {
  const data = useContext(ZoomContext);
  return data;
};

export default withZoomMode;
