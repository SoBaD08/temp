import React, { useState, useRef, useCallback, useEffect } from "react";
import styles from "./content.module.scss";
import EditStage from "./EditStage";
import SourceStage from "./SourceStage";
import { useZoom, ZOOM_MODE } from "../../../common/ZoomMode/index";
import { Tooltip } from "antd";
import { useTextData } from "../../../common/TextData";
import { useImageData } from "../../../common/ImageData";
import { publicRuntimeConfig } from "@/next.config";
import useTrans from "@/src/common/useTrans";

function Content(props) {
  const [isDisplaySourceStage, setDisplaySourceStage] = useState(true);

  const [defaultValueScale, setDefaultValueScale] = useState({
    value: "100",
    label: "100%",
  });

  const {
    isSync,
    zoomMode,
    setZoomMode,
    setStageSourceScale,
    setStageEditScale,
    stageSourceScale,
    stageEditScale,
  } = useZoom();
  const { ratio, defaultImage, newEditImage } = useImageData();

  const { selectedText } = useTextData();
  const handleSelectSource = () => {
    setZoomMode(ZOOM_MODE.SOURCE);
  };
  const handleSelectEdit = () => {
    setZoomMode(ZOOM_MODE.EDIT);
  };

  let sourceLimitZoomIn = stageSourceScale < 2.5;
  let sourceLimitZoomOut = stageSourceScale > 0.4;
  let editLimitZoomIn = stageEditScale < 2.5;
  let editLimitZoomOut = stageEditScale > 0.4;

  const firstDivRef = useRef();
  const secondDivRef = useRef();
  const ignoreScroll = useRef(false);

  const handleScrollEdit = useCallback(
    (scroll) => {
      if (firstDivRef.current) {
        const tempIgnore = ignoreScroll.current;
        ignoreScroll.current = false;
        if (isSync && !tempIgnore) {
          ignoreScroll.current = true;
          firstDivRef.current.scrollTop = scroll.target.scrollTop;
          firstDivRef.current.scrollLeft = scroll.target.scrollLeft;
        }
      }
    },
    [isSync]
  );
  const handleScrollSource = useCallback(
    (scroll) => {
      const tempIgnore = ignoreScroll.current;
      ignoreScroll.current = false;
      if (isSync && !tempIgnore) {
        ignoreScroll.current = true;
        secondDivRef.current.scrollTop = scroll.target.scrollTop;
        secondDivRef.current.scrollLeft = scroll.target.scrollLeft;
      }
    },
    [isSync]
  );
  const zoomIn = useCallback(() => {
    if (defaultImage.url || newEditImage.url) {
      if (isSync && editLimitZoomIn) {
        setStageEditScale((prevScale) => prevScale + 0.05);
        setStageSourceScale((prevScale) => prevScale + 0.05);
      } else {
        if (zoomMode === ZOOM_MODE.EDIT && editLimitZoomIn) {
          setStageEditScale((prevScale) => prevScale + 0.05);
        }
        if (zoomMode === ZOOM_MODE.SOURCE && sourceLimitZoomIn) {
          setStageSourceScale((prevScale) => prevScale + 0.05);
        }
      }
    }
  }, [
    isSync,
    zoomMode,
    defaultImage,
    newEditImage,
    stageSourceScale,
    stageEditScale,
  ]);
  const zoomOut = useCallback(() => {
    if (defaultImage.url || newEditImage.url) {
      if (isSync && editLimitZoomOut) {
        setStageEditScale((prevScale) => prevScale - 0.05);
        setStageSourceScale((prevScale) => prevScale - 0.05);
      } else {
        if (zoomMode === ZOOM_MODE.EDIT && editLimitZoomOut) {
          setStageEditScale((prevScale) => prevScale - 0.05);
        }
        if (zoomMode === ZOOM_MODE.SOURCE && sourceLimitZoomOut) {
          setStageSourceScale((prevScale) => prevScale - 0.05);
        }
      }
    }
  }, [
    isSync,
    zoomMode,
    defaultImage,
    newEditImage,
    stageSourceScale,
    stageEditScale,
  ]);

  const zoomByPercent = (value) => {
    if (defaultImage.url || newEditImage.url) {
      if (isSync) {
        setStageEditScale(value);
        setStageSourceScale(value);
      } else {
        if (zoomMode === ZOOM_MODE.EDIT) {
          setStageEditScale(value);
        }
        if (zoomMode === ZOOM_MODE.SOURCE) {
          setStageSourceScale(value);
        }
      }
    }
  };

  const zoomByShorcut = useCallback(
    (e) => {
      if (e.key === "+" && e.shiftKey) {
        e.preventDefault();
        zoomIn();
      }
      if (e.key === "-" && e.shiftKey) {
        e.preventDefault();
        zoomOut();
      }
    },
    [zoomMode, isSync, stageEditScale, stageSourceScale]
  );

  useEffect(() => {
    if (isSync) {
      setDefaultValueScale({
        value: Math.round(stageSourceScale * 100),
        label: `${Math.round(stageSourceScale * 100)}%`,
      });
      setStageEditScale(stageSourceScale);
    }
  }, [stageSourceScale, stageEditScale, isSync]);

  useEffect(() => {
    document.addEventListener("keydown", zoomByShorcut);
    return () => document.removeEventListener("keydown", zoomByShorcut);
  }, [zoomMode, isSync, stageEditScale, stageSourceScale]);

  useEffect(() => {
    if (selectedText) {
      const imgSource = document.getElementById("sourceStage");
      const imgEdit = document.getElementById("editStage");
      const height = imgEdit?.offsetHeight / 3;
      const width = imgEdit?.offsetWidth / 3;
      let scaleRatio = ratio;
      if (zoomMode === ZOOM_MODE.EDIT) {
        imgEdit.scrollTop =
          (selectedText.rectangle_coordinates[0].y / scaleRatio) *
            stageEditScale -
          height / 2;
        imgEdit.scrollLeft =
          (selectedText.rectangle_coordinates[0].x / scaleRatio) *
            stageEditScale -
          width / 2;
      }
      if (zoomMode === ZOOM_MODE.SOURCE) {
        imgSource.scrollTop =
          (selectedText.rectangle_coordinates[0].y / scaleRatio) *
            stageSourceScale -
          height;
        imgSource.scrollLeft =
          (selectedText.rectangle_coordinates[0].x / scaleRatio) *
            stageSourceScale -
          width;
      }
      if (isSync && isDisplaySourceStage) {
        imgEdit.scrollTop =
          (selectedText.rectangle_coordinates[0].y / scaleRatio) *
            stageEditScale -
          height;
        imgEdit.scrollLeft =
          (selectedText.rectangle_coordinates[0].x / scaleRatio) *
            stageEditScale -
          width;
        imgSource.scrollTop =
          (selectedText.rectangle_coordinates[0].y / scaleRatio) *
            stageSourceScale -
          height;
        imgSource.scrollLeft =
          (selectedText.rectangle_coordinates[0].x / scaleRatio) *
            stageSourceScale -
          width;
      }
    }
  }, [selectedText]);

  return (
    <div className={styles.container}>
      <div className={styles.imageContainer}>
        {isDisplaySourceStage && (
          <div
            className={styles.stage}
            style={{ marginRight: "12px" }}
            onClick={handleSelectSource}
          >
            <SourceStage
              setDisplaySourceStage={setDisplaySourceStage}
              firstDivRef={firstDivRef}
              handleScrollSource={handleScrollSource}
              zoomIn={zoomIn}
              zoomOut={zoomOut}
              zoomByPercent={zoomByPercent}
              defaultValueScale={defaultValueScale}
            />
          </div>
        )}

        <div
          className={isDisplaySourceStage ? styles.stage : styles.editStage}
          onClick={handleSelectEdit}
        >
          <EditStage
            isDisplaySourceStage={isDisplaySourceStage}
            secondDivRef={secondDivRef}
            handleScrollEdit={handleScrollEdit}
            zoomIn={zoomIn}
            zoomOut={zoomOut}
            zoomByPercent={zoomByPercent}
            defaultValueScale={defaultValueScale}
          />
        </div>
      </div>
      {!isDisplaySourceStage && (
        <div
          className={styles.maximizeIcon}
          onClick={() => setDisplaySourceStage(true)}
        >
          <Tooltip
            placement="top"
            title={
              <div className="tooltipText">
                <div>{useTrans(`Maximize`)}</div>
                <div>{useTrans(`MaximizeDes`)}</div>
              </div>
            }
          >
            <img
              src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/Maximize.svg`}
              alt=""
              style={{ margin: "0 18px 0 10px" }}
            />
          </Tooltip>

          <span style={{ color: "#ffffff", fontSize: "10px" }}>
            {useTrans("Source")}
          </span>
        </div>
      )}
    </div>
  );
}

export default Content;
