import React from "react";
import ReactShortcut from "react-shortcut";
import { useEditorMode } from "../../../common/EditorMode/index";
import { useButtonMode } from "@/src/common/Buttons";
export default function MenuShortcutRegister({ shortcuts }) {
  const { setMode } = useEditorMode();
  const { setButtonMode } = useButtonMode();

  return shortcuts.map((s) => (
    <ReactShortcut
      key={s.modeId}
      keys={s.shortcut}
      onKeysPressed={() => {
        setMode(s.modeId);
        setButtonMode(null);
      }}
    />
  ));
}
