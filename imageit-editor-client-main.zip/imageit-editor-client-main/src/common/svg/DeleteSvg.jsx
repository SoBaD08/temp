import React from "react";
const Index = (props) => (
  <svg
    {...props}
    width="16"
    height="18"
    viewBox="0 0 16 18"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M1 4.2002L2.55556 4.2002L15 4.20019"
      stroke="white"
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M4.80039 4.2V2.6C4.80039 2.17565 4.96896 1.76869 5.26902 1.46863C5.56908 1.16857 5.97604 1 6.40039 1H9.60039C10.0247 1 10.4317 1.16857 10.7318 1.46863C11.0318 1.76869 11.2004 2.17565 11.2004 2.6V4.2M13.6004 4.2V15.4C13.6004 15.8243 13.4318 16.2313 13.1318 16.5314C12.8317 16.8314 12.4247 17 12.0004 17H4.00039C3.57604 17 3.16908 16.8314 2.86902 16.5314C2.56896 16.2313 2.40039 15.8243 2.40039 15.4V4.2H13.6004Z"
      stroke={props?.active ? "#6F64FA" : "#45454B"}
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M6.1333 7.6665V12.9998"
      stroke={props?.active ? "#6F64FA" : "#45454B"}
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M9.86621 7.6665V12.9998"
      stroke={props?.active ? "#6F64FA" : "#45454B"}
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);
export default Index;
