import { useRouter } from "next/router";
import en from "@/public/lang/en";
import ko from "@/public/lang/ko";
import { getCookies } from "cookies-next";

const useTrans = (props) => {
  const { locale: localeInRouter } = useRouter();
  const { locale: localeInCookie } = getCookies();
  const locale = localeInCookie || localeInRouter;

  switch (locale) {
    case "en":
      return en[props];
    case "ko":
      return ko[props];
    default:
      return ko[props];
  }
};
export default useTrans;
