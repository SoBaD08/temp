import { createContext, useContext, useEffect, useRef, useState } from "react";
import { useHistory } from "../History/index";
import ForderProvider from "pages/api/ForderProvider";
import ImageITProvider from "@/pages/api/ImageITProvider";
import { urltoFile } from "@common/helper";

export const ImageDataContext = createContext();

function ImageDataProvider({ children }) {
  const { folder, folderId, setupHistory, setFolder } = useHistory();
  const DEFAULT_IMAGE = {
    url: null,
    isLock: false,
    isView: true,
    isSelect: false,
  };
  const DEFAULT_SELECT = {
    type: "elipse",
    size: "50",
    lines: [],
    rectanges: [
      {
        visible: false,
        x: 0,
        y: 0,
        width: 0,
        height: 0,
      },
    ],
    imageSelect: "",
  };
  const [newEditImage, setNewEditImage] = useState(DEFAULT_IMAGE);
  const [defaultImage, setDefaultImage] = useState(DEFAULT_IMAGE);

  const [nameDefaultImage, setNameDefaultImage] = useState(null);
  const [defaultImageUid, setDefaultImageUid] = useState();

  const [width, setWidth] = useState(0);
  const [height, setHeight] = useState(0);
  const [ratio, setRatio] = useState(1);
  const [loading, setLoading] = useState();
  const [selectImage, setSelectImage] = useState(false);
  const [select, setSelect] = useState(DEFAULT_SELECT);
  const [removeBGImage, setRemoveBGImage] = useState(DEFAULT_IMAGE);
  const [assetStageImages, setAssetStageImages] = useState([]);
  const [callBackDownload, setCallBackDownload] = useState(null);
  const [saveState, setSaveState] = useState("");

  const selectRef = useRef();
  const stageRef = useRef();
  const dragUrl = useRef();

  const handleSaveNewImage = async (url, name) => {
    setSaveState("Saving");
    try {
      const origin = await urltoFile(url, name, "image/png");
      const mediaId = await ImageITProvider.postFileImage({
        file: origin,
        application: "image",
        model: folderId,
      });
      setDefaultImage({
        ...defaultImage,
        _id: mediaId._id,
      });
      const body = {
        image: {
          media: mediaId._id,
          index: folder.filesets?.length,
        },
      };

      ForderProvider.saveImage(folderId, body).then((res) => {
        let data = res?.data;
        if (data) {
          setFolder(res?.data);
        }
      });
      setSaveState("Saved");
    } catch {
      (err) => console.log(err);
      setSaveState("SaveFailed");
    }
  };

  return (
    <ImageDataContext.Provider
      value={{
        DEFAULT_IMAGE,
        defaultImage,
        nameDefaultImage,
        select,
        width,
        height,
        ratio,
        selectRef,
        stageRef,
        newEditImage,
        defaultImageUid,
        loading,
        DEFAULT_SELECT,
        selectImage,
        removeBGImage,
        assetStageImages,
        dragUrl,
        saveState,
        setDefaultImage,
        setNameDefaultImage,
        setSelect,
        setWidth,
        setHeight,
        setRatio,
        setNewEditImage,
        setDefaultImageUid,
        setLoading,
        setSelectImage,
        setRemoveBGImage,
        setAssetStageImages,
        handleSaveNewImage,
        callBackDownload,
        setCallBackDownload,
        setSaveState,
      }}
    >
      {children}
    </ImageDataContext.Provider>
  );
}

const withImageData = (Component) => (props) => {
  return (
    <ImageDataProvider>
      <Component {...props} />
    </ImageDataProvider>
  );
};
export const useImageData = () => {
  const data = useContext(ImageDataContext);
  return data;
};

export default withImageData;
