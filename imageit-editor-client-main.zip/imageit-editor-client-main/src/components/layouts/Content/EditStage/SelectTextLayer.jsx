import React, { useRef, useState, useEffect } from "react";
import { Layer, Line, Rect, Transformer } from "react-konva";
import { BUTTONS } from "src/common/Buttons/constant";
import { useButtonMode } from "src/common/Buttons/index";

const KEY_CODE_ESC = 27;
const SelectTextLayer = (props) => {
  const {
    ratio,
    textData,
    selectedBlock,
    multipleSelect,
    setMultipleSelect,
    isDisplayLine,
    currentMode,
    stageEditScale,
    selectedText,
    setSelectText,
    setBlock,
    layerTextDataRef,
    buttonMode,
    setButtonMode,
  } = props;
  const selectLayerRef = useRef();
  const trRef = useRef();
  const isDrawing = useRef(false);
  const [selectLayer, setSelectLayer] = useState(null);

  const handleMouseDown = (e) => {
    e.target.preventDefault();
    e.evt.preventDefault();
    e.cancelBubble = true;
    setMultipleSelect([]);
    setSelectText(null);
    setBlock(null);
    isDrawing.current = true;
    const stage = e.target.getStage();
    const x = stage.getPointerPosition().x;
    const y = stage.getPointerPosition().y;
    setSelectLayer({
      visible: true,
      x: x,
      y: y,
      width: 0,
      height: 0,
    });
  };

  const handleMouseMove = (e) => {
    if (!selectLayer?.visible) {
      return;
    }
    if (!isDrawing.current) {
      return;
    }
    e.target.preventDefault();
    e.evt.preventDefault();
    e.cancelBubble = true;
    const stage = e.target.getStage();
    let x1 = selectLayer.x;
    let y1 = selectLayer.y;
    let x2 = stage.getPointerPosition().x;
    let y2 = stage.getPointerPosition().y;
    setSelectLayer({
      visible: true,
      x: x1,
      y: y1,
      width: x2 - x1,
      height: y2 - y1,
    });
  };

  const handleMouseUp = (e) => {
    const selBox = selectLayerRef.current?.getClientRect();

    if (!selectLayer?.width || !selectLayer?.height) {
      trRef.current.nodes([]);
      setSelectLayer({
        visible: false,
      });
      isDrawing.current = false;
      return;
    }

    const elements = [];
    const allElements = getAllLayer();
    [...allElements].forEach((elementNode) => {
      const elBox = elementNode.getClientRect();
      if (Konva.Util.haveIntersection(selBox, elBox)) {
        elements.push(elementNode);
      }
    });
    trRef.current.nodes(elements);
    let listLayer = elements.map((item) => item?.attrs?.item);
    setMultipleSelect(listLayer);
    setSelectLayer({
      visible: false,
    });
    isDrawing.current = false;
  };

  useEffect(() => {
    if (layerTextDataRef.current && trRef.current) {
      if (!selectedText && !selectedBlock && !multipleSelect?.length) {
        trRef.current.nodes([]);
      } else {
        const element = getAllLayer();
        let elementSelect = [];
        if (selectedText) {
          elementSelect = element.filter(
            (item) => item?.attrs?.item?.id == selectedText?.id
          );
        }
        if (selectedBlock) {
          elementSelect = element.filter(
            (item) => item?.attrs?.item?.id == selectedBlock
          );
        }
        if (multipleSelect?.length) {
          elementSelect = element.filter((item) =>
            multipleSelect.some((select) => select.id == item?.attrs?.item?.id)
          );
        }
        trRef.current.nodes(elementSelect);
      }
    }
  }, [selectedText, selectedBlock, multipleSelect]);

  const getAllLayer = () => {
    if (!layerTextDataRef || !trRef) {
      return [];
    }
    if (
      (buttonMode && buttonMode == BUTTONS.EXTRACT_TEXT) ||
      buttonMode == BUTTONS.TRANSLATION
    ) {
      return [...layerTextDataRef.current.find("Rect")];
    } else {
      return [
        ...layerTextDataRef.current.find("Image"),
        ...layerTextDataRef.current.find("Text"),
      ];
    }
  };

  useEffect(() => {
    const handleUserKeyPress = (e) => {
      if (e.keyCode == KEY_CODE_ESC) {
        setMultipleSelect(null);
        setSelectText(null);
        setBlock(null);
        trRef.current.nodes([]);
      }
    };
    window.addEventListener("keydown", handleUserKeyPress);
    return () => {
      window.removeEventListener("keydown", handleUserKeyPress);
    };
  }, [trRef.current]);
  return (
    <>
      <Layer
        scaleX={ratio / stageEditScale}
        scaleY={ratio / stageEditScale}
        ref={selectLayerRef}
        onMouseDown={handleMouseDown}
        onMousemove={handleMouseMove}
        onMouseup={handleMouseUp}
      >
        {selectLayer?.visible ? (
          <Rect
            ref={selectLayerRef}
            x={selectLayer.x}
            y={selectLayer.y}
            visible={selectLayer.visible}
            width={selectLayer.width}
            height={selectLayer.height}
            fill="white"
            opacity={0.8}
            stroke="#E8E2E2"
          />
        ) : null}
        <Transformer
          ref={trRef}
          keepRatio={true}
          boundBoxFunc={(oldBox, newBox) => {
            return oldBox;
          }}
          draggable={false}
          rotateEnabled={false}
          resizeEnabled={true}
          enabledAnchors={[
            "top-left",
            "top-right",
            "bottom-left",
            "bottom-right",
          ]}
          onMouseEnter={(e) => {
            const container = e.target.getStage().container();
            container.style.cursor = "move";
          }}
          onMouseLeave={(e) => {
            const container = e.target.getStage().container();
            container.style.cursor = "default";
          }}
        />
        <Rect x={0} y={0} width={5000} height={5000} visible={true}></Rect>
      </Layer>
    </>
  );
};
export default SelectTextLayer;
