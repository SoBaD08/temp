export default {
  //header
  File: "File",
  //file
  New: "New",
  OpenFile: "Open File",
  Save: "Save",
  SaveAs: "Save as",
  SaveAsAsset: "Save as Asset",
  Download: "Download",
  //edit
  Edit: "Edit",
  Undo: "Undo",
  Redo: "Redo",
  Copy: "Copy",
  Paste: "Paste",
  Delete: "Delete",
  SelectAll: "Select All",

  Saved: "Saved!",
  Comment: "Comment",

  Download: "Download",
  //AI BUTTON
  ExtractText: "Extract Text",
  TextDetect: "Text Detect",
  Execute: "Execute",
  TextExtract: " Text Extract",
  All: "All",
  SelectedOnly: "Selected Only",
  Inpainting: "Inpainting(remove original text)",
  TextLine: "Text Detect Line",

  Translation: "Translation",
  TranslateAll: "Translate All",
  TranslateSelected: "Translate Selected",

  RemoveObject: "Remove Object",
  MaskBrushType: "Mask Brush Type",
  MaskBrushSize: "Mask Brush Size",
  Remove: "Remove",

  RemoveBG: "Remove BG",
  CreateNewLayer: " Create a new layer for the result",

  RemoveObject: "Remove Object",

  Size: "Size",
  //Menu
  Select: "Select",
  Text: "Text",
  Layer: "Layer",
  Asset: "Asset",
  //Stage
  Source: "Source",
  Edit: "Edit",

  EditText: "Edit Text",

  //Modal
  CancelButton: "Cancel",
  AcceptButton: "Accept",
  Oke: "Ok",

  //Credit
  CreditLine1: "You need more credits",
  CreditLine2: "Will you buy credits now?",

  //translationWarning
  CheckTheLanguage: `Please check the source language and select the language on the original image for the "Source" language option!`,
  SelectTextTranslate: "Please select text for using translation",

  //removeBgWarning
  RemoveBGTitle: `<Remove BG> removes everything except main objects`,
  CheckTheImage: "Please check the image layer",
  SelectImage:
    "Please select an image layer you want to delete the background.",
  DescriptionRemoveBg:
    " You can use a layer delete function if you want delete already layered areas.,",

  //notification
  DoNotShowAgain: "Do not show this message again.",

  //ExtractTextWarning
  CanNotExtract: "Cannot extract text",
  SelectText: "Please select the text",

  //TransfromWarning

  ChooseLayer: "Please choose layer!",
  NoLayer: "No layers are saved",

  //UploadWarning
  UploadFail: "Upload file fail",
  UploadImage: "Please Upload Image",
  NewImages: "New Images",

  //RemoveObj
  RemoveObjDescription:
    "Mask the object you want to remove and click ‘Remove’. You can get better results if you meticulously mask the object you want to remove.",
  SelectLayer:
    "To try on a different layer, select the one you want from the layers panel.",

  //Save
  AddImage: "Please add an Image to save!",
  SaveAssetSuccess: "Save as asset success",
  SaveAssetError: "Save as asset failed",
  SaveImageSuccess: "The Image has been saved!",
  SaveImageFail: "The image has not been saved!",
  SaveOption: "Would you like to Save current file?",
  DeleteAssetFailed: "Delete asset failed!",

  //Comments
  Invite: "Invite members",
  AnyOneWithTheLink: "Anyone with the link",
  CopyLink: "Copy Link",
  SendInvite: "Send invite",
  Recent: "Recent",
  Resolved: "Resolved",
  Search: "Search",
  DelComentSuccess: "Delete comment success",
  DelCommentFail: "Delete comment fail",
  ResolveCommentFail: "Resolve comment fail",
  ChooseMulLayer: "Please chose multiple layer!",

  //Tooltips
  Dashboard: "Dashboard",
  SelectTitle: "Select (V)",
  SelectDescription: "Can use to select the objects on the Edit Canvas",
  TextTitle: "Text (T)",
  TextDescriptions: "Insert and edit text",
  LayerDescription: `Open "Layer" window`,
  AssetDescription: `Open "Asset" window`,
  ExtractTextTitle: "Extract Text(Shift + E)",
  ExtractTextDescription:
    "Extract text from the Image and creates layers for the each extracted text.",

  RemoveBgTitle: "Remove Background (Shift + R)",
  RemoveBgDescription:
    "Removes Background of the images. For example, if there are a person in the image this feature removes other aspects of images but the person",

  RemoveObjectTitle: "Remove Object (Shift + O)",
  RemoveObjectDescription: `Erase the selected object from the image by using Eraser tool`,
  TranslationTitle: "Translation (Shift + T)",
  TranslationDescription:
    "Will translate the selected text by setting target language.",

  //ConfirmRemoveObj
  OperationFaile: "The remove object operation is not finished.",
  ConfirmDownload: `If you want to download, remove object operation will be`,
  Aborted: "aborted!",
  ContinueEditing: "Continue editing",

  Layers: "Layers",

  ScrollSync: "Scroll Sync",
  ScrollSyncDescription:
    "By enabling, both Source and Edit Canvas will scroll and zoom together",

  ZoomOut: "Zoom out",
  ZoomIn: "Zoom in",
  Minimize: "Minimize",
  MinimizeDes: "Minimize the Canvas Window",

  EditProcessAutoSaved: "The editing process will be automatically saved!",
  SaveAsking: "Would like to save current file?",
  OpenFromLocal: "Open File From Local",
  SaveFailed: "Save Failed!",
  Saving: "Saving...",
  Close: "Close",
  Maximize: "Maximize",
  MaximizeDes: "Maximize the Canvas Window",
};
