import React, { useMemo } from "react";
import styles from "./navbar.module.scss";
import { message, Tooltip } from "antd";
import { BUTTONS_CONFIG, BUTTONS_LIST } from "../../../common/Buttons/constant";
import { useButtonMode } from "../../../common/Buttons";
import ButtonShortcutRegister from "./ButtonShortcutRegister";
import { useImageData } from "../../../common/ImageData";
import useImage from "use-image";
import { useEditorMode } from "../../../common/EditorMode";
import { publicRuntimeConfig } from "@/next.config";
import { useTextData } from "@/src/common/TextData";
import useTrans from "@/src/common/useTrans";

function Navbar() {
  const { setButtonMode, buttonMode } = useButtonMode();
  const { setMode, setCallBackOnChangeMode } = useEditorMode();
  const { editText } = useTextData();
  const configs = Object.values(BUTTONS_CONFIG);
  const { newEditImage } = useImageData();

  const [image] = useImage(newEditImage.url);

  const shortcuts = useMemo(
    () =>
      configs
        .filter((each) => each.shortcut)
        .map((each) => ({
          shortcut: each.shortcut,
          modeId: each.id,
        })),
    [configs]
  );
  const EditProcessAutoSaved = useTrans("EditProcessAutoSaved");
  const handleChangeMode = (mode) => {
    if (editText) {
      message.success(EditProcessAutoSaved);
      setCallBackOnChangeMode({ type: "buttonMode", mode: mode });
      return;
    }
    setMode(null);
    setButtonMode(mode);
  };
  return (
    <div>
      <ButtonShortcutRegister shortcuts={shortcuts} />

      <div className={styles.headerMenu}>
        <div className={styles.groupButton}>
          {BUTTONS_LIST.map((button) => {
            const config = BUTTONS_CONFIG[button];
            const { icon, label, tooltip, extraIcon, id } = config;
            return (
              <div key={id}>
                <Tooltip
                  placement="bottomRight"
                  title={
                    <div className="tooltipText">
                      <div>
                        <div>{useTrans(tooltip.title)}</div>
                        <div>{useTrans(tooltip.text)}</div>
                      </div>
                    </div>
                  }
                >
                  <div
                    className={`${styles.ButtonItem} ${
                      buttonMode === button ? styles.ButtonItemActive : ""
                    }`}
                    onClick={() => handleChangeMode(button)}
                  >
                    <img
                      style={{
                        marginLeft: "24px",
                        marginRight: "8px",
                        width: "28px",
                        height: "28px",
                      }}
                      alt="icon"
                      src={`${publicRuntimeConfig.basePath}/icons/buttons/${
                        buttonMode === button ? `${icon}-Active` : icon
                      }.svg`}
                    />
                    <span className={styles.ButtonItemText}>
                      {useTrans(label)}
                    </span>
                    <span style={{ marginLeft: "4px" }}>{extraIcon}</span>
                  </div>
                </Tooltip>
              </div>
            );
          })}
        </div>
        <div className={styles.picSize}>
          <span
            style={{ color: "#8c8d9a", fontSize: "12px", fontWeight: "400" }}
          >
            {useTrans(`Size`)} (W x H){":"}
          </span>
          <span
            style={{ fontSize: "14px", color: "#2e2e32", fontWeight: "500" }}
          >
            {image ? `${image.width} x ${image.height} pixel` : "pixel"}
          </span>
        </div>
      </div>
    </div>
  );
}
export default Navbar;
