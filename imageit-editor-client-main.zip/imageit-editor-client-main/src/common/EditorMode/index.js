import React, { useState, useContext, useRef, useEffect } from "react";
import { MODES } from "./constant";

export const EditorModeContext = React.createContext();

function EditorModeProvider({ children }) {
  const [currentMode, setMode] = useState(MODES.SELECT);
  const [callBackOnChangeMode, setCallBackOnChangeMode] = useState(false);
  const [listComment, setListComment] = useState([]);
  const [newComment , setNewComment] = useState(null);
  const commentingRef = useRef(false);

  useEffect(() =>{
    setNewComment(null);
    commentingRef.current=false;
  },[currentMode])
  return (
    <EditorModeContext.Provider
      value={{
        currentMode,
        setMode,
        callBackOnChangeMode,
        setCallBackOnChangeMode,
        listComment,
        setListComment,
        newComment,
        setNewComment,
        commentingRef,
      }}
    >
      {children}
    </EditorModeContext.Provider>
  );
}
const withEditorMode = (Component) => (props) => {
  return (
    <EditorModeProvider>
      <Component {...props} />
    </EditorModeProvider>
  );
};

export const useEditorMode = () => {
  const data = useContext(EditorModeContext);
  return data;
};

export default withEditorMode;
