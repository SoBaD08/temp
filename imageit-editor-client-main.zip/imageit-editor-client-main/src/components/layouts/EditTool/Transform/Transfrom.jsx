import React, { useEffect, useState } from "react";
import { publicRuntimeConfig } from "@/next.config";
import styles from "./transform.module.scss";
import { useTextData } from "../../../../common/TextData";
import { useHistory } from "@/src/common/History";
import { message } from "antd";
import useTrans from "@/src/common/useTrans";

const RETURN_KEY = 13;
const ESCAPE_KEY = 27;
function Transfrom(props) {
  const { selectedText, setTextData, textData, setSelectText, selectedBlock } =
    useTextData();
  const [selectObj, setObj] = useState();
  const [isLockAspectRatio, setLockAspectRatio] = useState(false);
  const { setHistory } = useHistory();
  useEffect(() => {
    if (selectedText) {
      setObj(selectedText);
    }
    if (selectedBlock) {
      for (let i = 0; i < textData.length; i++) {
        if (textData[i]?.id === selectedBlock) {
          setObj(textData[i]);
          return;
        }
      }
    }
    if (!selectedText || selectedBlock) {
      setObj();
    }
  }, [selectedText, selectedBlock]);
  const ChooseLayer = useTrans(`ChooseLayer`);
  const onChangeWidth = (value) => {
    if (selectObj) {
      value = parseInt(value) || 0;
      const current = selectObj;
      let temp = {};
      if (isLockAspectRatio) {
        const ratio = current.aspectRatio;
        temp = { ...current, width: value, height: value / ratio };
      } else {
        temp = { ...current, width: value };
      }
      setObj(temp);
      setSelectText(temp);
      let newTextData = [...textData];
      for (let i = 0; i <= newTextData.length; i++) {
        if (newTextData[i].id === selectObj.id) {
          newTextData[i] = temp;
          setTextData([...newTextData]);
          setHistory({ textData: [...newTextData] });
          break;
        }
      }
    } else {
      message.warning(ChooseLayer);
    }
  };
  const onChangeHeight = (value) => {
    if (selectObj) {
      // value = parseInt(value) || 0;
      const current = selectObj;
      let temp = {};
      if (isLockAspectRatio) {
        const ratio = current.aspectRatio;
        temp = { ...current, width: value * ratio, height: value };
      } else {
        temp = { ...current, height: value };
      }
      setObj(temp);
      setSelectText(temp);
      let newTextData = [...textData];
      for (let i = 0; i <= newTextData.length; i++) {
        if (newTextData[i].id === selectObj.id) {
          newTextData[i] = temp;
          setTextData([...newTextData]);
          setHistory({ textData: [...newTextData] });
          break;
        }
      }
    } else {
      message.warning(ChooseLayer);
    }
  };

  const onChangeDegree = (value) => {
    if (selectObj) {
      value = parseInt(value) || 0;
      const current = selectObj;
      let temp = {};
      temp = { ...current, degree: value };
      setObj(temp);
      setSelectText(temp);
      let newTextData = [...textData];
      for (let i = 0; i <= newTextData.length; i++) {
        if (newTextData[i].id === selectObj.id) {
          newTextData[i] = temp;
          setTextData([...newTextData]);
          setHistory({ textData: [...newTextData] });
          break;
        }
      }
    } else {
      message.warning(ChooseLayer);
    }
  };

  const increaseWidth = () => {
    if (selectObj) {
      const current = selectObj;
      let temp = {};
      if (isLockAspectRatio) {
        const ratio = current.aspectRatio;
        temp = {
          ...current,
          width: current.width + 2,
          height: (current.width + 2) / ratio,
        };
      } else {
        temp = { ...current, width: current.width + 2 };
      }
      setObj(temp);
      setSelectText(temp);
      let newTextData = [...textData];
      for (let i = 0; i <= newTextData.length; i++) {
        if (newTextData[i].id === selectObj.id) {
          newTextData[i] = temp;
          setTextData([...newTextData]);
          setHistory({ textData: [...newTextData] });
          break;
        }
      }
    } else {
      message.warning(ChooseLayer);
    }
  };
  const increaseHeight = () => {
    if (selectObj) {
      const current = selectObj;
      let temp = {};
      if (isLockAspectRatio) {
        const ratio = current.aspectRatio;
        temp = {
          ...current,
          height: current.height + 2,
          width: (current.height + 2) * ratio,
        };
      } else {
        temp = { ...current, height: current.height + 2 };
      }

      setObj(temp);
      setSelectText(temp);
      let newTextData = [...textData];
      for (let i = 0; i <= newTextData.length; i++) {
        if (newTextData[i].id === selectObj.id) {
          newTextData[i] = temp;
          setTextData([...newTextData]);
          break;
        }
      }
    } else {
      message.warning(ChooseLayer);
    }
  };
  const decreaseWidth = () => {
    if (selectObj) {
      const current = selectObj;
      if (selectObj.width > 0) {
        let temp = {};
        if (isLockAspectRatio) {
          const ratio = current.aspectRatio;
          temp = {
            ...current,
            width: current.width - 2,
            height: (current.width - 2) / ratio,
          };
        } else {
          temp = { ...current, width: current.width - 2 };
        }
        setObj(temp);
        setSelectText(temp);
        let newTextData = [...textData];
        for (let i = 0; i <= newTextData.length; i++) {
          if (newTextData[i].id === selectObj.id) {
            newTextData[i] = temp;
            setTextData([...newTextData]);
            setHistory({ textData: [...newTextData] });
            break;
          }
        }
      }
    } else {
      message.warning(ChooseLayer);
    }
  };
  const decreaseHeight = () => {
    if (selectObj) {
      const current = selectObj;
      if (selectObj.height > 0) {
        let temp = {};
        if (isLockAspectRatio) {
          const ratio = current.aspectRatio;
          temp = {
            ...current,
            height: current.height - 2,
            width: (current.height - 2) * ratio,
          };
        } else {
          temp = { ...current, height: current.height - 2 };
        }

        setObj(temp);
        setSelectText(temp);
        let newTextData = [...textData];
        for (let i = 0; i <= newTextData.length; i++) {
          if (newTextData[i].id === selectObj.id) {
            newTextData[i] = temp;
            setTextData([...newTextData]);
            setHistory({ textData: [...newTextData] });
            break;
          }
        }
      }
    } else {
      message.warning(ChooseLayer);
    }
  };
  const increaseDegree = () => {
    if (selectObj) {
      const current = selectObj;
      let temp = {};
      temp = { ...current, degree: current.degree + 2 };
      setObj(temp);
      setSelectText(temp);
      let newTextData = [...textData];
      for (let i = 0; i <= newTextData.length; i++) {
        if (newTextData[i].id === selectObj.id) {
          newTextData[i] = temp;
          setTextData([...newTextData]);
          setHistory({ textData: [...newTextData] });
          break;
        }
      }
    } else {
      message.warning(ChooseLayer);
    }
  };
  const decreaseDegree = () => {
    if (selectObj) {
      const current = selectObj;
      let temp = {};
      temp = { ...current, degree: current.degree - 2 };
      setObj(temp);
      setSelectText(temp);
      let newTextData = [...textData];
      for (let i = 0; i <= newTextData.length; i++) {
        if (newTextData[i].id === selectObj.id) {
          newTextData[i] = temp;
          setTextData([...newTextData]);
          setHistory({ textData: [...newTextData] });
          break;
        }
      }
    } else {
      message.warning(ChooseLayer);
    }
  };
  const handleEscapeKeys = (e) => {
    if ((e.keyCode === RETURN_KEY && !e.shiftKey) || e.keyCode === ESCAPE_KEY) {
      onChangeWidth(selectObj.width);
      onChangeHeight(selectObj.height);
      e.target.blur();
    }
  };

  return (
    <div className={styles.mainContainer}>
      <div className={styles.firstLine}>
        <div className={styles.sizeContainer}>
          <span className={styles.textContainer}>W</span>
          <div className={styles.numberContainer}>
            <input
              onChange={(e) => {
                onChangeWidth(e.target.value);
              }}
              className={styles.number}
              style={{ border: "none" }}
              value={
                selectObj?.width ? Math.round(selectObj.width * 100) / 100 : 0
              }
              // onKeyDown={handleEscapeKeys}
            />
            <div className={styles.buttonContainer}>
              <div className={styles.arrowUpButton} onClick={increaseWidth}>
                <img
                  src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/upArrow.svg`}
                  alt=""
                />
              </div>
              <div className={styles.arrowDownButton} onClick={decreaseWidth}>
                <img
                  src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/downArrow.svg`}
                  alt=""
                />
              </div>
            </div>
          </div>
        </div>
        <div className={styles.sizeContainer}>
          <span className={styles.textContainer}>H</span>
          <div className={styles.numberContainer}>
            <input
              className={styles.number}
              style={{ border: "none" }}
              value={
                selectObj?.height ? Math.round(selectObj.height * 100) / 100 : 0
              }
              onChange={(e) => {
                onChangeHeight(e.target.value);
              }}
              // onKeyDown={handleEscapeKeys}
            />
            <div className={styles.buttonContainer}>
              <div className={styles.arrowUpButton} onClick={increaseHeight}>
                <img
                  src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/upArrow.svg`}
                  alt=""
                />
              </div>
              <div className={styles.arrowDownButton} onClick={decreaseHeight}>
                <img
                  src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/downArrow.svg`}
                  alt=""
                />
              </div>
            </div>
          </div>
          <div
            className={styles.iconWrapper}
            onClick={() => setLockAspectRatio(!isLockAspectRatio)}
          >
            <img
              src={
                isLockAspectRatio
                  ? `${publicRuntimeConfig.basePath}/icons/miscellaneous/UnlockAspectRatio.svg`
                  : `${publicRuntimeConfig.basePath}/icons/miscellaneous/LockAspectRatio.svg`
              }
              alt=""
            />
          </div>
        </div>
      </div>

      <div className={styles.sizeContainer}>
        <span>
          <img
            src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/Rotate.svg`}
          ></img>
        </span>
        <div className={styles.numberContainer}>
          <input
            className={styles.number}
            style={{ border: "none" }}
            value={
              selectObj?.degree ? Math.round(selectObj.degree * 100) / 100 : 0
            }
            onChange={(e) => {
              onChangeDegree(e.target.value);
            }}
            // onKeyDown={handleEscapeKeys}
          />

          <div className={styles.buttonContainer}>
            <div className={styles.arrowUpButton} onClick={increaseDegree}>
              <img
                src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/upArrow.svg`}
                alt=""
              />
            </div>
            <div className={styles.arrowDownButton} onClick={decreaseDegree}>
              <img
                src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/downArrow.svg`}
                alt=""
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Transfrom;
