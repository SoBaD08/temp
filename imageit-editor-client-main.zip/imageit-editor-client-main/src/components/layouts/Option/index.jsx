import React, { useState, useEffect } from "react";
import { publicRuntimeConfig } from "@/next.config";

import { v4 as uuidv4 } from "uuid";

import Layer from "./Layer";
import Asset from "./Asset";
import styles from "./option.module.scss";
import DeleteSvg from "../../../common/svg/DeleteSvg";
import DuplicateSvg from "../../../common/svg/DuplicateSvg";

import { useTextData } from "../../../common/TextData";
import { useHistory } from "@/src/common/History";
import { useEditorMode } from "@/src/common/EditorMode";
import { useImageData } from "@/src/common/ImageData";
const Divider = () => {
  return (
    <span
      style={{
        height: "16px",
        width: "1px",
        border: "0.7px solid #E8E7EE",
        marginRight: "4px",
        marginLeft: "4px",
      }}
    ></span>
  );
};

export default function Option() {
  const [deleteActive, setDelete] = useState(false);
  const [duplicateActive, setDuplicate] = useState(false);
  const { selectedText, setTextData, textData } = useTextData();
  const { currentMode } = useEditorMode();
  const { setHistory } = useHistory();
  const { selectImage, assetStageImages, setAssetStageImages } = useImageData();
  const deleteText = () => {
    if (selectedText) {
      const temp = textData.filter((item) => item !== selectedText);
      setTextData(temp);
      setHistory({ textData: temp });
    }
  };
  const deleteAsset = () => {
    if (selectImage) {
      const temp = assetStageImages.filter((item) => item !== selectImage);
      setAssetStageImages([...temp]);
      setHistory({ assetStageImages: [...temp] });
    }
  };
  const duplicateAsset = () => {
    if (selectImage) {
      for (let i = 0; i < assetStageImages.length; i++) {
        if (assetStageImages[i] === selectImage) {
          assetStageImages.splice(i + 1, 0, { ...selectImage, id: uuidv4() });
          setAssetStageImages([...assetStageImages]);
          setHistory({ assetStageImages: [...assetStageImages] });
          return;
        }
      }
    }
  };
  const duplicateText = () => {
    if (selectedText) {
      for (let i = 0; i < textData.length; i++) {
        if (textData[i] === selectedText) {
          textData.splice(i + 1, 0, { ...selectedText, id: uuidv4() });
          setTextData([...textData]);
          setHistory({ textData: [...textData] });
          return;
        }
      }
    }
  };
  useEffect(() => {
    let timer1 = setTimeout(() => setDelete(false), 1000);
    let timer2 = setTimeout(() => setDuplicate(false), 1000);
    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, [deleteActive, duplicateActive]);
  return (
    <div className={styles.container}>
      {currentMode !== 9 && (
        <div className={styles.layer}>
          <Layer />
        </div>
      )}

      {currentMode === 9 && (
        <div className={styles.layer}>
          <Asset />
        </div>
      )}
      <div className={styles.groupIcon}>
        {/* <div className={styles.iconWrapper}>
          <img
            src={`${publicRuntimeConfig.basePath}/icons/layers/Group.svg`}
            alt=""
          />
        </div>
        <Divider />
        <div className={styles.iconWrapper}>
          <img
            src={`${publicRuntimeConfig.basePath}/icons/layers/Ungroup.svg`}
            alt=""
          />
        </div>
        <Divider /> */}
        <div
          className={`${styles.iconWrapper} ${
            duplicateActive ? styles.iconWrapperActive : ""
          }`}
        >
          <DuplicateSvg
            active={duplicateActive}
            onClick={() => {
              duplicateAsset();
              setDuplicate(true);
              duplicateText();
            }}
          />
        </div>
        <Divider />
        <div
          className={`${styles.iconWrapper} ${
            deleteActive ? styles.iconWrapperActive : ""
          }`}
        >
          <DeleteSvg
            active={deleteActive}
            onClick={() => {
              setDelete(true);
              deleteText();
              deleteAsset();
            }}
          />
        </div>
      </div>
    </div>
  );
}
