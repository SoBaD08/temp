import dynamic from "next/dynamic";

const NoSSRComponent = dynamic(() => import("./EditStage"), {
  ssr: false,
});

export default function EditStage(props) {
  const {
    isDisplaySourceStage,
    secondDivRef,
    handleScrollEdit,
    zoomIn,
    zoomOut,
    zoomByPercent,
    defaultValueScale,
  } = props;

  return (
    <NoSSRComponent
      isDisplaySourceStage={isDisplaySourceStage}
      secondDivRef={secondDivRef}
      handleScrollEdit={handleScrollEdit}
      zoomIn={zoomIn}
      zoomOut={zoomOut}
      zoomByPercent={zoomByPercent}
      defaultValueScale={defaultValueScale}
    />
  );
}
