import React, { useCallback } from "react";
import { useButtonMode } from "../../../common/Buttons";
import { BUTTONS } from "../../../common/Buttons/constant";
import EditText from "./EditText/EditText";
import styles from "./editTool.module.scss";
import RemoveObject from "./RemoveObject/RemoveObject";
import Translation from "./Translation/Translation";
import Transfrom from "./Transform/Transfrom";
import { useTextData } from "../../../common/TextData";
import { useEditorMode } from "../../../common/EditorMode";
import ExtractText from "./ExtractText/ExtractText";
import Comment from "@src/components/layouts/EditTool/Comment/Comment";
import { MODES } from "@common/EditorMode/constant";
import RemoveBG from "./RemoveBG/RemoveBG";

function EditTool(props) {
  const { buttonMode } = useButtonMode();
  const { editText } = useTextData();
  const { currentMode, listComment } = useEditorMode();
  const renderEditMode = useCallback(() => {
    switch (currentMode) {
      case MODES.COMMENT:
        return <Comment />;

      default:
        break;
    }
    switch (buttonMode) {
      case 1:
        return <>{editText ? <EditText /> : <ExtractText />}</>;
      case 2:
        return <RemoveBG />;
      case 3:
        return <RemoveObject />;
      case 4:
        return <Translation />;
      default:
        return <EditText />;
    }
  }, [buttonMode, currentMode, listComment]);
  return <div className={styles.wrapEditTool}>{renderEditMode()}</div>;
}

export default EditTool;
