import React from "react";
const Index = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M13 5V7.79204H14.7877V6.86137H16.6062V17.1386H14.8185V19H20.1815V17.1386H18.3938V12V6.86137H20.2123V7.79204H22V5H13Z" fill="#2E2E32" />
        <path d="M2 5V7.79204H3.78768V6.86137H5.60617V17.1386H3.81849V19H9.18151V17.1386H7.39383V12V6.86137H9.21232V7.79204H11V5H2Z" fill="#2E2E32" />
    </svg>
)
export default Index;