import { Checkbox, Input, message, Tooltip, Mentions, Spin, Form } from "antd";
import React, { useRef, useState } from "react";
import styles from "./Comment.module.scss";
import EditIcon from "@common/svg/Edit";
import DeleteIcon from "@common/svg/Delete";
import MoreComment from "@common/svg/MoreComment";
import { EnterOutlined } from "@ant-design/icons";
import { useEditorMode } from "@common/EditorMode";
import { useImageData } from "@common/ImageData";
import { useHistory } from "@/src/common/History";
import CommentProvider from "@/pages/api/CommentProvider";
import useTrans from "@/src/common/useTrans";

Date.prototype.timeSince = function () {
  let seconds = Math.abs(Math.floor((new Date() - this) / 1000)) + 3;

  let interval = seconds / 31536000;

  if (interval > 1) {
    return Math.floor(interval) + " years ago";
  }
  interval = seconds / 2592000;
  if (interval > 1) {
    return Math.floor(interval) + " months ago";
  }
  interval = seconds / 86400;
  if (interval > 1) {
    return Math.floor(interval) + " days ago";
  }
  interval = seconds / 3600;
  if (interval > 1) {
    return Math.floor(interval) + " hours ago";
  }
  interval = seconds / 60;
  if (interval > 1) {
    return Math.floor(interval) + " minutes ago";
  }
  return Math.floor(seconds) + " seconds ago";
};

const CardComment = ({
  index,
  userComment,
  updatedAt,
  content,
  type = "submit",
  comment,
  getAllComment,
}) => {
  const {
    newComment,
    setNewComment,
    listComment,
    setListComment,
    commentingRef,
  } = useEditorMode();
  const { defaultImage } = useImageData();
  const { user, listMember } = useHistory();
  const [commenting, setCommenting] = useState(type == "create");
  const [loading, setLoading] = useState(false);
  const [showReply, setShowReply] = useState(false);
  const [listReply, setListReply] = useState([]);
  const contentRef = useRef();
  const [commentReply, setCommentReply] = useState("");

  const submitComment = async () => {
    try {
      setLoading(true);
      let content = contentRef.current.textarea.value;

      if (!comment?._id) {
        // create new comment
        let body = {
          media: defaultImage?._id,
          coordinate: newComment.coordinate,
          content: content,
        };
        await CommentProvider.createComment(body);
      } else {
        // update comment
        let body = {
          content: content,
        };
        await CommentProvider.updateComment(comment._id, body);
      }
      setNewComment(null);
      setCommenting(false);
      commentingRef.current = false;
      getAllComment();
      setLoading(false);
    } catch (error) {
      console.log(error);
      getAllComment();
      setLoading(false);
    }
  };

  const handleEdit = () => {
    setCommenting(true);
  };
  const DelComentSuccess = useTrans(`DelComentSuccess`);
  const DelCommentFail = useTrans(`DelCommentFail`);
  const handleDelete = async () => {
    try {
      setLoading(true);
      let res = await CommentProvider.deleteComment(comment?._id);
      if (res.status == 200) {
        message.success(DelComentSuccess);
        getAllComment();
      }
      setLoading(false);
    } catch (error) {
      console.log(error);
      let dataMessage = error?.response?.data?.message || DelCommentFail;
      message.error(dataMessage);
      getAllComment();
      setLoading(false);
    }
  };
  const ResolveCommentFail = useTrans(`ResolveCommentFail`);
  const handleResolve = async () => {
    try {
      setLoading(true);
      let body = {
        resolved: true,
      };
      let { data: resComment } = await CommentProvider.updateComment(
        comment._id,
        body
      );
      getAllComment();
      setLoading(false);
    } catch (error) {
      console.log(error);
      let dataMessage = error?.response?.data?.message || ResolveCommentFail;
      message.error(dataMessage);
      getAllComment();
      setLoading(false);
    }
  };

  const handleReply = async () => {
    try {
      let res = await CommentProvider.getComment({
        media: defaultImage?._id,
        parentComment: comment?._id,
      });
      let { users, docs } = res;
      let comments = docs.map((item, i) => {
        return Object.assign({}, item, { user: users[i] });
      });
      setListReply(comments);
      setShowReply(true);
    } catch (error) {
      console.log(error);
    }
  };

  const submitReply = async () => {
    try {
      setLoading(true);
      let content = commentReply;
      let body = {
        media: defaultImage?._id,
        content: content,
        parentComment: comment?._id,
        coordinate: comment?.coordinate,
      };
      await CommentProvider.createComment(body);
      handleReply();
      setLoading(false);
      setCommentReply("");
    } catch (error) {
      console.log(error);
      getAllComment();
      setLoading(false);
    }
  };
  return (
    <div className={styles.cardComment}>
      <Spin size="default" spinning={loading}>
        <div className="header">
          <div className="left">
            <div>
              <span style={{ marginRight: "3px" }}>#</span>
              <span>{index}</span>
            </div>
            {userComment && (
              <div className="customers">
                <div className="icon-customer">
                  {userComment?.firstCharOfName}
                </div>
              </div>
            )}
          </div>
          <div>
            {!commenting && (
              <div className="right">
                <MoreComment onClick={handleReply} />
                <Checkbox
                  onClick={handleResolve}
                  checked={comment?.resolved}
                  disabled={comment?.resolved}
                  className="checkbox-resolve"
                ></Checkbox>
              </div>
            )}
          </div>
        </div>
        <div className="content">
          <div className="infor">
            <div className="user-name">{user.name}</div>
            {!commenting && (
              <div className="right">
                <div>{new Date(updatedAt).timeSince()}</div>
                <EditIcon onClick={handleEdit} />
                <DeleteIcon onClick={handleDelete} />
              </div>
            )}
          </div>
          {commenting ? (
            <div className="input-comments">
              <Mentions
                style={{ resize: "none" }}
                placeholder="Comments..."
                autoSize={{ minRows: 1, maxRows: 8 }}
                autoFocus={true}
                ref={contentRef}
                defaultValue={content}
              >
                {listMember.map((item) => {
                  return (
                    <Mentions.Option
                      key={item._id}
                      value={item?.user?.name || item?.user?.email}
                      member={item}
                    >
                      {item?.user?.name || item?.user?.email}
                    </Mentions.Option>
                  );
                })}
              </Mentions>
              <div className="icon-input">
                <span className="tag">@</span>
                <Tooltip title="Submit">
                  <EnterOutlined onClick={submitComment} />
                </Tooltip>
              </div>
            </div>
          ) : (
            <div className="body-content">{content}</div>
          )}
          {showReply ? (
            <div className="wrap-reply">
              <div>
                {listReply && listReply.length
                  ? listReply.map((item, index) => {
                      return (
                        <div className="reply">
                          <div className="content">
                            <div className="infor">
                              <div className="user-name">
                                {item?.creator?.name || item?.creator?.email}
                              </div>
                              <div>{new Date(item?.updatedAt).timeSince()}</div>
                            </div>
                            <div className="body-content">{item?.content}</div>
                          </div>
                        </div>
                      );
                    })
                  : null}
              </div>

              <div className="input-comments input-reply">
                <Mentions
                  style={{ resize: "none" }}
                  placeholder="Reply..."
                  autoSize={{ minRows: 1, maxRows: 8 }}
                  autoFocus={true}
                  value={commentReply}
                  onChange={(e) => setCommentReply(e)}
                >
                  {listMember.map((item) => {
                    return (
                      <Mentions.Option
                        key={item._id}
                        value={item?.user?.name || item?.user?.email}
                        member={item}
                      >
                        {item?.user?.name || item?.user?.email}
                      </Mentions.Option>
                    );
                  })}
                </Mentions>
                <div className="icon-input">
                  <span className="tag">@</span>
                  <Tooltip title="Submit">
                    <EnterOutlined onClick={submitReply} />
                  </Tooltip>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </Spin>
    </div>
  );
};

export default CardComment;
