import dynamic from "next/dynamic";

const NoSSRComponent = dynamic(() => import("./SourceStage"), {
  ssr: false,
});

export default function SourceStage(props) {
  const {
    setDisplaySourceStage,
    handleScrollSource,
    firstDivRef,
    zoomIn,
    zoomOut,
    zoomByPercent,
    defaultValueScale,
  } = props;
  return (
    <NoSSRComponent
      setDisplaySourceStage={setDisplaySourceStage}
      handleScrollSource={handleScrollSource}
      firstDivRef={firstDivRef}
      zoomIn={zoomIn}
      zoomOut={zoomOut}
      zoomByPercent={zoomByPercent}
      defaultValueScale={defaultValueScale}
    />
  );
}
