import React from "react";
const Index = (props) => (
    <svg width="20" height="22" viewBox="0 0 20 22" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M13.3283 13.5L18.9253 7.25L13.3283 1" stroke={props?.active ? "#6F64FA" : "#C8C8CE"} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M1.01484 21V12.25C1.01484 10.9239 1.48659 9.65215 2.32631 8.71447C3.16602 7.77678 4.30492 7.25 5.49246 7.25H18.9253" stroke={props?.active ? "#6F64FA" : "#C8C8CE"} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
)
export default Index;