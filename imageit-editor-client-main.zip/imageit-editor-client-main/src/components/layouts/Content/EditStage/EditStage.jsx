import { publicRuntimeConfig } from "@/next.config";
import React, { useEffect, useRef, useState } from "react";
import styles from "../SourceStage/sourceStage.module.scss";

import { Spin } from "antd";

import { useHistory } from "@/src/common/History";
import { useEditorMode } from "@common/EditorMode/index";
import { ContentState, EditorState } from "draft-js";
import DraftPasteProcessor from "draft-js/lib/DraftPasteProcessor";
import { Image, Layer, Rect, Stage } from "react-konva";
import useImage from "use-image";
import { v4 as uuidv4 } from "uuid";
import { useButtonMode } from "../../../../common/Buttons";
import { BUTTONS } from "../../../../common/Buttons/constant";
import { useImageData } from "../../../../common/ImageData";
import { useTextData } from "../../../../common/TextData";
import { useZoom, ZOOM_MODE } from "../../../../common/ZoomMode";
import Asset from "./Asset";
import Comment from "./Comment";
import Navbar from "./Navbar";
import RemoveObject from "./RemoveObject";
import SelectTextLayer from "./SelectTextLayer";
import TextLayer from "./TextLayer";
import useTrans from "@/src/common/useTrans";
export default function Index(props) {
  const { isDisplaySourceStage, secondDivRef, handleScrollEdit } = props;
  const { zoomMode, isSync, stageEditScale } = useZoom();
  const {
    defaultImage,
    setSelect,
    setDefaultImage,
    setDefaultImageUid,
    setNameDefaultImage,
    width,
    height,
    ratio,
    newEditImage,
    loading,
    setLoading,
    stageRef,
    setNewEditImage,
    removeBGImage,
    dragUrl,
    assetStageImages,
    setAssetStageImages,
    selectImage,
    handleSaveNewImage,
  } = useImageData();
  const {
    textData,
    setTextData,
    selectedText,
    setBlock,
    setSelectText,
    setEditText,
    editText,
    setStyleMap,
    multipleSelect,
    setMultipleSelect,
    isDisplayLine,
    selectedBlock,
  } = useTextData();
  const { setupHistory, setHistory } = useHistory();
  const { currentMode, setMode, setCallBackOnChangeMode } = useEditorMode();
  const editStageElm = document.getElementById("editStage");
  const editStageElmWidth = editStageElm?.offsetWidth;
  const editStageElmHeight = editStageElm?.offsetHeight;

  const [image] = useImage(newEditImage.url, "anonymous");
  const [removeBGImages] = useImage(removeBGImage.url, "anonymous");
  useEffect(() => {
    setSelect({
      type: "elipse",
      size: "50",
      lines: [],
      rectanges: [
        {
          visible: false,
          x: 0,
          y: 0,
          width: 0,
          height: 0,
        },
      ],
      imageSelect: "",
    });
  }, [defaultImage]);
  const { buttonMode, setButtonMode } = useButtonMode();
  const [position, setPosition] = useState();
  const [textEditing, setTextEditing] = useState(false);
  const [indexEditText, setIndexEditText] = useState(null);
  const [selectedId, setSelectAsset] = useState(null);

  const layerTextDataRef = useRef();

  const handleChangeImage = (e) => {
    const URL = window.webkitURL || window.URL;
    const url = URL.createObjectURL(e.target.files[0]);
    let nameFile = e?.target?.files[0].name || "";
    let name = nameFile.slice(0, nameFile.lastIndexOf("."));
    setNameDefaultImage(name);
    handleSaveNewImage(url, nameFile);
    setDefaultImage({ ...defaultImage, url: url });
    setDefaultImageUid(null);
    setStyleMap(null);
    setNewEditImage({ ...newEditImage, url: url });
    setupHistory({ newEditImage: { ...newEditImage, url: url } });
  };

  function preventScroll(e) {
    e.preventDefault();
    e.stopPropagation();
    return false;
  }

  const handleClassForStage = React.useCallback(() => {
    if (
      width * stageEditScale < editStageElmWidth &&
      height * stageEditScale > editStageElmHeight
    ) {
      return styles.imageWrapperHorizontal;
    }
    if (height * stageEditScale < editStageElmHeight) {
      return styles.imageWrapperVertical;
    }
    return styles.imageWrapper;
  }, [stageEditScale, width, height]);

  useEffect(() => {
    if (editStageElm) {
      if (zoomMode === ZOOM_MODE.SOURCE) {
        editStageElm.addEventListener("wheel", preventScroll);
      }
      if (zoomMode === ZOOM_MODE.EDIT || !isDisplaySourceStage || isSync) {
        editStageElm.removeEventListener("wheel", preventScroll);
      }
      return () => {
        editStageElm.removeEventListener("wheel", preventScroll);
      };
    }
  }, [zoomMode, isSync, isDisplaySourceStage]);

  useEffect(() => {
    if (!image) {
      setLoading(true);
    } else {
      setLoading(false);
    }
  }, [image]);
  const propsLayer = {
    image,
    textEditing,
    setTextEditing,
    indexEditText,
    setIndexEditText,
    position,
    setPosition,
    layerTextDataRef,
    ...(useZoom() || {}),
    ...(useHistory() || {}),
    ...(useImageData() || {}),
    ...(useTextData() || {}),
    ...(useEditorMode() || {}),
    ...(useButtonMode() || {}),
  };
  const renderLayerMode = () => {
    return (
      <>
        {(currentMode == 1 || buttonMode == 1 || buttonMode == 4) &&
          !editText && <SelectTextLayer {...propsLayer} />}
      </>
    );
  };
  const renderLayerButtonMode = () => {
    return (
      <>
        {buttonMode == BUTTONS.REMOVE_OBJECT && (
          <RemoveObject {...propsLayer} />
        )}
      </>
    );
  };
  const renderLayerText = () => {
    return <TextLayer {...propsLayer} />;
  };
  const renderLayerComment = () => {
    return <Comment {...propsLayer} />;
  };
  return (
    <div className={styles.container}>
      <div
        className={
          zoomMode === ZOOM_MODE.EDIT || !isDisplaySourceStage || isSync
            ? styles.tilteSelect
            : styles.title
        }
      >
        {useTrans(`Edit`)}
      </div>
      <Navbar {...props} />

      <div
        className={handleClassForStage()}
        id="editStage"
        ref={secondDivRef}
        onScroll={handleScrollEdit}
      >
        <div className={styles.imageContainer}>
          {newEditImage.url || image ? (
            <div
              onDrop={(e) => {
                e.preventDefault();
                // register event position
                stageRef.current.setPointersPositions(e);
                const temp = {
                  id: uuidv4(),
                  ...stageRef.current.getPointerPosition(),
                  src: dragUrl.current,
                  width: 136,
                  height: 136,
                  isView: true,
                  isLock: false,
                };
                let tempArr = assetStageImages;
                tempArr.push(temp);
                // add image
                setAssetStageImages([...tempArr]);
                setHistory({ assetStageImages: [...tempArr] });
              }}
              onDragOver={(e) => e.preventDefault()}
            >
              <Spin spinning={loading} style={{ height: "100%" }}>
                <Stage
                  width={width * stageEditScale}
                  height={height * stageEditScale}
                  scaleX={stageEditScale / ratio}
                  scaleY={stageEditScale / ratio}
                  ref={stageRef}
                >
                  {newEditImage.isView && (
                    <Layer id="source">
                      {image && <Image image={image} />}
                    </Layer>
                  )}
                  {removeBGImage && removeBGImage.isView && (
                    <Layer id="removeBGImage">
                      {removeBGImages && <Image image={removeBGImages} />}
                    </Layer>
                  )}
                  {!!(assetStageImages && assetStageImages?.length) && (
                    <Layer
                      onClick={(e) => {
                        setSelectAsset(null);
                      }}
                    >
                      <Rect
                        x={0}
                        y={0}
                        width={5000}
                        height={5000}
                        visible={true}
                      ></Rect>
                      {assetStageImages?.map((image, i) => {
                        return (
                          image.isView && (
                            <Asset
                              key={i}
                              ratio={ratio}
                              stageEditScale={stageEditScale}
                              image={image}
                              isSelected={image.id === selectedId}
                              isEditLayer={image === selectImage}
                              onSelect={() => {
                                setSelectAsset(image.id);
                              }}
                              draggable={!image.isLock}
                              onChange={(newAttrs) => {
                                const imgs = assetStageImages.slice();
                                imgs[i] = newAttrs;
                                setAssetStageImages([...imgs]); //setRectangles(rects);
                                setHistory({ assetStageImages: [...imgs] });
                              }}
                            />
                          )
                        );
                      })}
                    </Layer>
                  )}
                  {renderLayerMode()}
                  {renderLayerText()}
                  {renderLayerButtonMode()}
                  {renderLayerComment()}
                </Stage>
              </Spin>
            </div>
          ) : (
            <div className={styles.imageBackground}>
              <div
                style={{ position: "absolute" }}
                className={styles.inputWrapper}
              >
                <img
                  src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/ImageIt.svg`}
                  alt=""
                  width="204px"
                  height="55px"
                />
                <div className={styles.inputContent}>
                  <span>Drag and drop or Click here to upload</span>
                </div>
              </div>
              <input
                accept="image/*"
                type="file"
                multiple
                onChange={(e) => handleChangeImage(e)}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
