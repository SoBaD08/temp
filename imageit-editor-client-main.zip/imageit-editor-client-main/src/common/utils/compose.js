const compose = (hocs) => (Comp) => {
  return hocs.reduceRight((acc, hoc) => {
    return hoc(acc);
  }, Comp);
};

export default compose;
