import React, {
  createContext,
  useState,
  useContext,
  useRef,
  useEffect,
  useMemo,
} from "react";
import { useHistory } from "src/common/History/index";
import { useImageData } from "src/common/ImageData/index";
import { useEditorMode } from "src/common/EditorMode";
import { isJsonString } from "src/common/helper";
import { EditorState, convertFromRaw } from "draft-js";

export const TextDataContext = createContext();

function TextDataProvider({ children }) {
  const filesetsRef = useRef();
  const { folder, folderId, setupHistory, setFolder } = useHistory();
  const {
    setDefaultImage,
    setNewEditImage,
    setDefaultImageUid,
    setSelect,
    setAssetStageImages,
    defaultImage,
    newEditImage,
    DEFAULT_IMAGE,
    DEFAULT_SELECT,
    setNameDefaultImage,
    setRatio,
  } = useImageData();
  const { setListComment } = useEditorMode();

  const [textData, setTextData] = useState([]);
  const [selectedText, setSelectText] = useState();
  const [multipleSelect, setMultipleSelect] = useState([]);
  const [selectedBlock, setBlock] = useState();
  const [editText, setEditText] = useState();
  const [styleMap, setStyleMap] = useState();
  const [isDisplayLine, setDisplayLine] = useState(false);
  const [inpaint, setInpaint] = useState(true);
  const [isCreateNewImageLayer, setCreateNewImageLayer] = useState(true);
  const [filesetId, setFilesetId] = useState();
  const TopZindex = useRef(0);
  const LastZindex = useRef(0);

  // check change folder.filesets
  const listFileSetsId = useMemo(() => {
    if (!folder?.filesets?.length) {
      return [];
    }
    let listFile = folder?.filesets.map((item) => {
      let fileSet = {};
      fileSet.original = item?.original?._id || item?.original;
      if (item?.edited) {
        fileSet.edited = item?.edited?._id || item?.edited;
      }
      return fileSet;
    });
    return listFile;
  }, [JSON.stringify(folder.filesets)]);

  useEffect(() => {
    if (folder.filesets?.length) {
      let original = folder.filesets[folder.filesets?.length - 1].original;
      let edited = folder.filesets[folder.filesets?.length - 1].edited;
      setDefaultImage({
        ...defaultImage,
        url: original.signedUrl,
        _id: original._id,
      });
      setNewEditImage({
        ...newEditImage,
        url: edited ? edited.signedUrl : original.signedUrl,
      });
      setFilesetId(folder.filesets[folder.filesets?.length - 1]._id);
      setDefaultImageUid(edited ? edited : original);
      let nameFile = edited ? edited?.filename : original?.filename;
      let name = nameFile.slice(0, nameFile.lastIndexOf("."));
      setNameDefaultImage(name);
      setupHistory({
        newEditImage: {
          ...newEditImage,
          url: edited ? edited.signedUrl : original.signedUrl,
        },
      });
      let data =
        edited?.data && isJsonString(edited?.data)
          ? JSON.parse(edited?.data)
          : null;
      if (data) {
        const {
          textData: textData = [],
          select: select = DEFAULT_SELECT,
          assetStageImages: assetStageImages = [],
          comments: comments = [],
          styleMap: styleMap = {},
          ratio: ratio = 1,
        } = data;
        if (textData) {
          let newTextData = [...textData].map((item) => {
            if (item?.image) {
              let image = new Image();
              image.src = item.image;
              let canvas = document.createElement("canvas");
              canvas.width = item.width / ratio;
              canvas.height = item.height / ratio;
              canvas.style.width = `${item.width / ratio}px`;
              canvas.style.height = `${item.height / ratio}px`;
              image.onload = function () {
                let ctx = canvas.getContext("2d");
                ctx.drawImage(image, 0, 0);
              };

              return {
                ...item,
                image: canvas,
                editorText: EditorState.createWithContent(
                  convertFromRaw(item.editorText)
                ),
              };
            } else return item;
          });
          setTextData(newTextData);
        }
        setRatio(ratio);
        setStyleMap(styleMap);
        setSelect(select);
        setAssetStageImages([...assetStageImages]);
        setListComment(comments);
      }
    }
  }, [JSON.stringify(listFileSetsId)]);
  return (
    <TextDataContext.Provider
      value={{
        textData,
        selectedText,
        multipleSelect,
        selectedBlock,
        editText,
        styleMap,
        isDisplayLine,
        inpaint,
        isCreateNewImageLayer,
        filesetId,
        setMultipleSelect,
        setEditText,
        setStyleMap,
        setTextData,
        setSelectText,
        setBlock,
        setDisplayLine,
        setInpaint,
        setCreateNewImageLayer,
        setFilesetId,
        TopZindex,
        LastZindex,
      }}
    >
      {children}
    </TextDataContext.Provider>
  );
}
const withTextData = (Component) => (props) => {
  return (
    <TextDataProvider>
      <Component {...props} />
    </TextDataProvider>
  );
};
export const useTextData = (s) => {
  const data = useContext(TextDataContext);
  return data;
};
export default withTextData;
