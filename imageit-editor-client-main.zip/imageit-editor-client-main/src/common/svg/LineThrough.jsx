import React from "react";
const Index = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M7 5V7.69232H8.73506V6.79489H11.3376V10.3846H13.0727V6.79489H15.6752V7.69232H17.4103V5H7Z" fill="#2E2E32" />
        <path d="M13.1025 13.6152H11.3076V17.205H9.5127V18.9999H14.8973V17.205H13.1024V13.6152H13.1025Z" fill="#2E2E32" />
        <path d="M7 11.1025H17.4103V12.8974H7V11.1025Z" fill="#2E2E32" />
    </svg>
)
export default Index;