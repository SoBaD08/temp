import { DownOutlined } from "@ant-design/icons";
import React from "react";

export const BUTTONS = {
  EXTRACT_TEXT: 1,
  REMOVE_BACKGROUND: 2,
  REMOVE_OBJECT: 3,
  TRANSLATION: 4,
};

export const BUTTONS_CONFIG = {
  [BUTTONS.EXTRACT_TEXT]: {
    id: BUTTONS.EXTRACT_TEXT,
    icon: "ExtractText",
    label: "ExtractText",
    shortcut: ["shift+e"],
    tooltip: {
      title: "ExtractTextTitle",
      text: "ExtractTextDescription",
    },
  },
  [BUTTONS.REMOVE_BACKGROUND]: {
    id: BUTTONS.REMOVE_BACKGROUND,
    icon: "RemoveBackground",
    label: "RemoveBG",
    shortcut: ["shift+r"],
    tooltip: {
      title: "RemoveBgTitle",
      text: "RemoveBgDescription",
    },
  },
  [BUTTONS.REMOVE_OBJECT]: {
    id: BUTTONS.REMOVE_OBJECT,
    icon: "RemoveObject",
    label: "RemoveObject",
    shortcut: ["shift+o"],
    tooltip: {
      title: "RemoveObjectTitle",
      text: "RemoveObjectDescription",
    },
  },
  [BUTTONS.TRANSLATION]: {
    id: BUTTONS.TRANSLATION,
    icon: "Translation",
    label: "Translation",
    shortcut: ["shift+t"],
    tooltip: {
      title: "TranslationTitle",
      text: "TranslationDescription",
    },
  },
};

export const BUTTONS_LIST = [
  BUTTONS.EXTRACT_TEXT,
  BUTTONS.TRANSLATION,
  BUTTONS.REMOVE_OBJECT,
  BUTTONS.REMOVE_BACKGROUND,
];
