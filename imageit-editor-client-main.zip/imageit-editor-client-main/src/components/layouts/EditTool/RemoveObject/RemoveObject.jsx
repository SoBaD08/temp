import { publicRuntimeConfig } from "@/next.config";
import ImageITProvider from "@/pages/api/ImageITProvider";
import { Button, Checkbox, Divider, message, Slider } from "antd";
import html2canvas from "html2canvas";
import { useEffect, useState } from "react";
import { useImageData } from "../../../../common/ImageData";
import SelectElipse from "../../../../common/svg/SelectElipse";
import SelectRetange from "../../../../common/svg/SelectRetange";
import styles from "../../EditTool/editTool.module.scss";
import { urltoFile } from "@common/helper";
import { useZoom } from "@/src/common/ZoomMode";
import { useHistory } from "@/src/common/History";
import stylesRemoveObject from "./removeObject.module.scss";
import AlertModal from "@/src/common/AlertModal";
import { checkEnv } from "@/pages/authen/RouteGuard";
import useTrans from "@/src/common/useTrans";
import { useTextData } from "@/src/common/TextData";

function RemoveObject(props) {
  const [isDisplayNoti, setDisplayNoti] = useState(false);
  const [hideNoti, setHideNoti] = useState(false);
  const [isDisplayOption, setDisplayOption] = useState(false);
  const {
    select,
    setSelect,
    defaultImage,
    selectRef,
    ratio,
    width,
    height,
    newEditImage,
    defaultImageUid,
    setLoading,
    setNewEditImage,
    setDefaultImageUid,
    nameDefaultImage,
    DEFAULT_SELECT,
  } = useImageData();
  const { filesetId } = useTextData();
  const { setHistory, folder } = useHistory();
  const { stageEditScale } = useZoom();
  const onChangeSize = (e) => {
    setSelect({
      ...select,
      size: e,
    });
  };
  const onChange = (e) => {
    setHideNoti(e.target.checked);
  };

  const handleSelect = () => {
    if (defaultImage.url) {
      selectRef.current.getCanvas()._canvas.id = "ID_select";
      html2canvas(document.querySelector("#ID_select"), {
        backgroundColor: "black",
        scale: ratio / stageEditScale,
        width: width * stageEditScale,
        height: height * stageEditScale,
      }).then((canvas) => {
        // show it inside Konva.Image
        let maskUrl = canvas.toDataURL() || "";
        setSelect({
          ...select,
          lines: [],
          rectanges: [],
          imageSelect: maskUrl,
        });
        if (newEditImage) {
          handleRemoveObject(newEditImage.url, maskUrl);
        } else {
          handleRemoveObject(defaultImage.url, maskUrl);
        }
      });
    }
  };
  const UploadFail = useTrans("UploadFail");
  const handleRemoveObject = async (orginUrl, maskUrl) => {
    setLoading(true);
    try {
      const mask = await urltoFile(maskUrl, "mask.png", "image/png");
      const maskMediaId = await ImageITProvider.postFileImage({
        file: mask,
        application: "remove-object/mask",
        model: folder._id,
      });
      let mediaId = defaultImageUid;
      if (!defaultImageUid) {
        const origin = await urltoFile(
          orginUrl,
          `${nameDefaultImage}.png`,
          "image/png"
        );
        mediaId = await ImageITProvider.postFileImage({
          file: origin,
          application: "remove-object/original",
          model: folder._id,
        });
      }
      const res = await ImageITProvider.remove({
        mediaId: mediaId._id,
        maskMediaId: maskMediaId._id,
        fileset: filesetId,
      });
      const resultImage = res.signedUrl;
      setNewEditImage({ ...newEditImage, url: resultImage });
      setHistory({
        newEditImage: { ...newEditImage, url: resultImage },
        select: DEFAULT_SELECT,
      });
      setDefaultImageUid(res);
      setLoading(false);
    } catch (error) {
      if (error.response.status === 402) {
        setDisplayOption(true);
      } else {
        message.error(UploadFail);
      }
      setLoading(false);
    }
  };

  useEffect(() => {
    if (localStorage.getItem("hideNoti") != null) {
      if (JSON.parse(localStorage.getItem("hideNoti")) === true) {
        setDisplayNoti(false);
      } else {
        setDisplayNoti(true);
      }
    } else {
      setDisplayNoti(true);
    }
  }, []);

  return (
    <div className={stylesRemoveObject.container}>
      <div className={stylesRemoveObject.title}>{useTrans(`RemoveObject`)}</div>
      {isDisplayNoti ? (
        <div className={stylesRemoveObject.notificationContainer}>
          <div className={stylesRemoveObject.infoIcon}>
            <img
              src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/info.svg`}
              alt=""
            />
          </div>

          <div className={stylesRemoveObject.mainContainer}>
            <p className={stylesRemoveObject.paragraph}>
              {useTrans(`RemoveObjDescription`)}
            </p>
            <img
              src={`${publicRuntimeConfig.basePath}/image/notificationImage.png`}
              alt=""
            />
            <p className={stylesRemoveObject.paragraph}>
              {useTrans(`SelectLayer`)}
            </p>
            <div>
              <Divider />
            </div>
            <div>
              <Checkbox onChange={onChange} style={{ fontSize: "10px" }}>
                {useTrans(`DoNotShowAgain`)}
              </Checkbox>
            </div>
            <div className={stylesRemoveObject.closeButtonContainer}>
              <div
                className={stylesRemoveObject.closeButton}
                onClick={() => {
                  localStorage.setItem("hideNoti", hideNoti);
                  setDisplayNoti(false);
                }}
              >
                {useTrans(`Close`)}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div>
          <div className={stylesRemoveObject.body}>
            <div className={stylesRemoveObject.select}>
              <p>{useTrans(`MaskBrushType`)}</p>
              <div className={stylesRemoveObject.iconContainer}>
                <div className={stylesRemoveObject.iconWrapper}>
                  <SelectRetange
                    onClick={() => setSelect({ ...select, type: "retange" })}
                    active={select.type == "retange" ? "true" : ""}
                  />
                </div>
                <div className={stylesRemoveObject.iconWrapper}>
                  <SelectElipse
                    onClick={() => setSelect({ ...select, type: "elipse" })}
                    active={select.type == "elipse" ? "true" : ""}
                  />
                </div>
              </div>
            </div>
            <Divider />
            <div className={stylesRemoveObject.sliderCustom}>
              <p> {useTrans(`MaskBrushSize`)}</p>
              <Slider
                tipFormatter={null}
                onChange={onChangeSize}
                min={1}
                max={100}
                defaultValue={50}
              />
            </div>
            <Divider />
            <div className={styles.action}>
              <div className={styles.wrapButton}>
                <Button onClick={handleSelect}> {useTrans(`Remove`)}</Button>
                {/* <div>
                  <img
                    style={{ marginRight: "20px", marginLeft: "16px" }}
                    width={36}
                    height={36}
                    src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/undo.svg`}
                  />
                  <img
                    src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/redo.svg`}
                  />
                </div> */}
              </div>
            </div>
            <AlertModal
              visible={isDisplayOption}
              loading={null}
              handleAccept={() =>
                window.location.replace(
                  `https://${checkEnv(window.location.href)}imageit.io/pricing`
                )
              }
              handleCancel={() => setDisplayOption(false)}
              text={
                <>
                  <div>{useTrans(`CreditLine1`)}</div>
                  <div>{useTrans(`CreditLine2`)}</div>
                </>
              }
            />
          </div>
        </div>
      )}
    </div>
  );
}

export default RemoveObject;
