import React from "react";
const Index = (props) => (
    <svg width="21" height="22" viewBox="0 0 21 22" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M6.6268 13.5L1.02979 7.25L6.6268 1" stroke={props?.active ? "#6F64FA" : "#C8C8CE"} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M19.9402 21V12.25C19.9402 10.9239 19.4685 9.65215 18.6288 8.71447C17.7891 7.77678 16.6502 7.25 15.4626 7.25H2.02979" stroke={props?.active ? "#6F64FA" : "#C8C8CE"} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
)
export default Index;