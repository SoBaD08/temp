import { useState, useEffect } from "react";
import { useRouter } from "next/router";

/**
 * User Authentication Manage
 * @param param0
 * @returns
 */
export const checkEnv = (href) => {
  if (href?.includes("stg")) {
    return "stg.";
  } else if (href?.includes("dev")) {
    return "dev.";
  } else return "";
};
function RouteGuard({ children }) {
  const router = useRouter();
  let folderID = router.query["folderId"] || "";
  const [authorized, setAuthorized] = useState(false);

  useEffect(() => {
    // on initial load - run auth check
    authCheck(router.asPath);

    // on route change start - hide page content by setting authorized to false
    const hideContent = () => setAuthorized(false);
    router.events.on("routeChangeStart", hideContent);

    // on route change complete - run auth check
    router.events.on("routeChangeComplete", authCheck);

    // unsubscribe from events in useEffect return function
    return () => {
      router.events.off("routeChangeStart", hideContent);
      router.events.off("routeChangeComplete", authCheck);
    };

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function authCheck(url) {
    const token = localStorage.getItem("token");

    const publicPaths = [
      // /\/custom\/payment/,
      // /\/custom\/result/,
      // /^\/custom\/[a-f\d]{24}$/,
      /(token=)/g,
    ];

    const path = url.split("?").slice(-1)[0];
    const found = publicPaths.find((publicPath) => publicPath.test(path));

    if (found) {
      // 1. 토큰 검증 필요
      // 2. 폴더 ID는 어떻게 생성하는가?
      localStorage.setItem(
        "token",
        url.split("?").slice(-1)[0].replace("token=", "")
      );
      localStorage.setItem("folderId", "638e95de6d94b7916ed00496");
      setAuthorized(true);
      return;
    }
    if (!token) {
      setAuthorized(false);
      window.location.replace(
        `https://${checkEnv(window.location.href)}imageit.io/login`
      );
    } else {
      setAuthorized(true);
      const folderId = localStorage.getItem("folderId") || folderID;
      if (!folderId) {
        window.location.replace(
          `https://${checkEnv(window.location.href)}imageit.io/dashboard`
        );
      } else {
        return children;
      }
    }
  }
  return authorized && children;
}

export default RouteGuard;
