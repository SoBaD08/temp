import { useHistory } from "@/src/common/History";
import React, { useState, useEffect } from "react";
import styles from "./asset.module.scss";
import { Button, message, Upload } from "antd";
import { useTextData } from "@/src/common/TextData";
import ImageITProvider from "@/pages/api/ImageITProvider";
import ForderProvider from "@/pages/api/ForderProvider";
import { publicRuntimeConfig } from "@/next.config";
import { useImageData } from "@/src/common/ImageData";
import useTrans from "@/src/common/useTrans";
function Asset() {
  const { folder, setFolder } = useHistory();
  const { stageRef, dragUrl } = useImageData();
  const [assetImages, setAssetImages] = useState([]);
  useEffect(() => {
    const tempArr = [];
    if (folder.assets?.length) {
      folder.assets.forEach((asset) =>
        tempArr.push({ url: asset.signedUrl, id: asset._id })
      );
      setAssetImages([...tempArr]);
    }
  }, [folder.assets]);
  const index = folder.assets?.length;
  const SaveAssetError = useTrans("SaveAssetError");
  const handleSaveAsset = async (url) => {
    try {
      const folderId = folder._id;
      const response = await fetch(url);
      // here image is url/location of image
      const blob = await response.blob();
      const file = new File([blob], "image.jpg", { type: blob.type });
      const res = await ImageITProvider.postFileImage({
        file: file,
        application: "image",
        model: folderId,
      });
      const imageId = res._id;

      let body = {
        asset: {
          media: imageId,
          index: index,
        },
      };
      ForderProvider.saveAsset(folderId, body).then((res) => {
        setFolder(res.data);
      });
    } catch (error) {
      console.log(error);
      message.error(SaveAssetError);
    }
  };
  const DeleteAssetFailed = useTrans(`DeleteAssetFailed`);

  const handleDeleteAsset = async (mediaId) => {
    try {
      const folderId = folder._id;
      let body = {
        media: mediaId,
      };
      ForderProvider.deleteAsset(folderId, body)
        .then((res) => {
          setFolder(res.data);
        })
        .catch((err) => console.log(err));
    } catch (error) {
      message.error(DeleteAssetFailed);
    }
  };

  const props = {
    name: "file",
    headers: {
      authorization: "authorization-text",
    },
    onChange(info) {
      const URL = window.webkitURL || window.URL;
      const url = URL.createObjectURL(info.file.originFileObj);
      let tempArr = assetImages;
      tempArr.push({ url });
      setAssetImages([...tempArr]);
      handleSaveAsset(url);
    },
    fileList: [],
  };

  return (
    <div className={styles.assetContainer}>
      <div className={styles.header}> {useTrans(`Asset`)}</div>
      <div className={styles.addImageButton}>
        <Upload {...props}>
          <Button>
            <span style={{ marginRight: "12px" }}>+</span>
            {useTrans(`NewImages`)}
          </Button>
        </Upload>
      </div>
      <div className={styles.imageContainer}>
        {assetImages.length ? (
          assetImages.map((item, index) => (
            <div className={styles.imageWrapper} key={index}>
              <img
                className={styles.asset}
                src={item.url}
                alt=""
                draggable="true"
                onDragStart={(e) => {
                  dragUrl.current = e.target.src;
                }}
              />
              <img
                className={styles.assetDelete}
                src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/Close.svg`}
                alt=""
                onClick={() => {
                  const arr = assetImages.filter((elm) => {
                    return elm.id !== item.id;
                  });
                  setAssetImages([...arr]);
                  handleDeleteAsset(item.id);
                }}
              />
            </div>
          ))
        ) : (
          <div></div>
        )}
      </div>
    </div>
  );
}

export default Asset;
