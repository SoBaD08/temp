import React, { useMemo } from "react";

import styles from "./menu.module.scss";
import { useEditorMode } from "../../../common/EditorMode/index";
import { Tooltip, message } from "antd";

import { MODES_LIST, MODES_CONFIG } from "../../../common/EditorMode/constant";
import MenuShortcutRegister from "./MenuShortcutRegister";
import { useButtonMode } from "../../../common/Buttons";
import { useTextData } from "@/src/common/TextData";
import { publicRuntimeConfig } from "@/next.config";
import useTrans from "@/src/common/useTrans";
const Menu = () => {
  const { setMode, currentMode, setCallBackOnChangeMode } = useEditorMode();
  const { setButtonMode } = useButtonMode();
  const { editText } = useTextData();
  const configs = Object.values(MODES_CONFIG);
  const shortcuts = useMemo(
    () =>
      configs
        .filter((each) => each.shortcut)
        .map((each) => ({
          shortcut: each.shortcut,
          modeId: each.id,
        })),
    [configs]
  );
  const EditProcessAutoSaved = useTrans("EditProcessAutoSaved");
  const changeMode = (mode) => {
    setButtonMode(null);
    // editText != null => user is editting mode => call back submitText() before change mode
    if (editText) {
      message.success(EditProcessAutoSaved);
      setCallBackOnChangeMode({ type: "mode", mode: mode });
      return;
    }
    setMode(mode);
  };
  return (
    <div>
      <MenuShortcutRegister shortcuts={shortcuts} />

      <div className={styles.Menu}>
        {MODES_LIST.map((mode) => {
          const config = MODES_CONFIG[mode];
          const { icon, label, tooltip } = config;
          return (
            <div className={styles.menuItemWrapper} key={mode.id}>
              <Tooltip
                placement="right"
                title={
                  <div className="tooltipText">
                    <div>{tooltip ? useTrans(tooltip.title) : null}</div>
                    <div>{tooltip ? useTrans(tooltip.text) : null}</div>
                  </div>
                }
              >
                <div
                  onClick={() => {
                    changeMode(mode);
                  }}
                  className={`${styles.MenuItem} ${
                    currentMode === mode ? styles.MenuItemActive : ""
                  }`}
                >
                  <img
                    alt="icon"
                    src={`${publicRuntimeConfig.basePath}/icons/menu/${
                      currentMode === mode ? `${icon}-Active` : icon
                    }.svg`}
                  />
                  <label className={styles.MenuItemText}>
                    {useTrans(label)}
                  </label>
                </div>
              </Tooltip>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Menu;
