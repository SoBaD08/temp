import React from "react";
import ReactShortcut from "react-shortcut";
import { useButtonMode } from "../../../common/Buttons/index";
import { useEditorMode } from "@/src/common/EditorMode";
export default function ButtonShortcutRegister({ shortcuts }) {
  const { setButtonMode } = useButtonMode();
  const {setMode} = useEditorMode();
  return shortcuts.map((s) => (
    <ReactShortcut
      key={s.modeId}
      keys={s.shortcut}
      onKeysPressed={() => {
        setButtonMode(s.modeId);
        setMode(null);
      }}
    />
  ));
}
