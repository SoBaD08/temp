export const MODES = {
  SELECT: 1,
  TEXT_SELECT: 2,
  SHAPE: 3,
  TEXT: 4,
  PEN: 5,
  STAMP: 6,
  ERASE: 7,
  LAYER: 8,
  ASSET: 9,
  COMMENT: 10,
};

export const MODES_CONFIG = {
  [MODES.SELECT]: {
    id: MODES.SELECT,
    icon: "Select",
    label: "Select",
    shortcut: ["v"],
    tooltip: {
      title: "SelectTitle",
      text: "SelectDescription",
    },
  },
  // [MODES.TEXT_SELECT]: {
  //   id: MODES.TEXT_SELECT,
  //   icon: "TextSelect",
  //   label: "Text select",
  //   shortcut: ["shift+s"],
  //   tooltip: {
  //     title: "Text Select (Shift+S)",
  //     text: "Creates a layer for adding text layer",
  //   },
  // },
  // [MODES.SHAPE]: {
  //   id: MODES.SHAPE,
  //   icon: "Shape",
  //   label: "Shape",
  //   shortcut: ["a"],
  //   tooltip: {
  //     title: "Shape (A)",
  //     text: `Adding "Rectangle", "Polygon","Ellips"`,
  //   },
  // },
  [MODES.TEXT]: {
    id: MODES.TEXT,
    icon: "Text",
    label: "Text",
    shortcut: ["t"],
    tooltip: {
      title: "TextTitle",
      text: "TextDescriptions",
    },
  },
  // [MODES.PEN]: {
  //   id: MODES.PEN,
  //   icon: "Pen",
  //   label: "Pen",
  //   tooltip: {
  //     title: "Pen",
  //     text: "Free drawing pen",
  //   },
  // },
  // [MODES.STAMP]: {
  //   id: MODES.STAMP,
  //   icon: "Stamp",
  //   label: "Stamp",
  //   shortcut: ["shift+c"],
  //   tooltip: {
  //     title: "Stamp (Shift+C)",
  //     text: "Clone the selected point or area to target",
  //   },
  // },
  // [MODES.ERASE]: {
  //   id: MODES.ERASE,
  //   icon: "Eraser",
  //   label: "Eraser",
  //   shortcut: ["e"],
  //   tooltip: {
  //     title: "Eraser (Shift+E)",
  //     text: "Erase the selected object from the image by using Eraser tool",
  //   },
  // },
  [MODES.LAYER]: {
    id: MODES.LAYER,
    icon: "Layer",
    label: "Layer",
    tooltip: {
      title: "Layer",
      text: `LayerDescription`,
    },
  },
  [MODES.ASSET]: {
    id: MODES.ASSET,
    icon: "Asset",
    label: "Asset",
    shortcut: ["a"],
    tooltip: {
      title: "Asset",
      text: `AssetDescription`,
    },
  },
};

export const MODES_LIST = [
  MODES.SELECT,
  // MODES.TEXT_SELECT,
  // MODES.SHAPE,
  MODES.TEXT,
  // MODES.PEN,
  // MODES.STAMP,
  // MODES.ERASE,
  MODES.LAYER,
  MODES.ASSET,
];
