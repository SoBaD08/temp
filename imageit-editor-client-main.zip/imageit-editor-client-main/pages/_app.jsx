import React from "react";
import "../styles/globals/_all.scss";
import Head from "next/head";
import "antd/dist/antd.css";
import { publicRuntimeConfig } from "@/next.config";
import RouteGuard from "./authen/RouteGuard";
RouteGuard;

function MyApp({ Component, pageProps }) {
  return (
    <>
      <Head>
        <title>ImageIT</title>
        <link
          rel="shortcut icon"
          href={`${publicRuntimeConfig.basePath}/icons/favicon.ico`}
        />
        <link rel="preconnect" href="https://fonts.gstatic.com" />
        <meta
          name="viewport"
          content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"
        />
      </Head>
      <RouteGuard>
        <Component {...pageProps} />
      </RouteGuard>
    </>
  );
}

export default MyApp;
