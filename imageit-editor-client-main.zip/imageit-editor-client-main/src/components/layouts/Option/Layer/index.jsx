import React, { useEffect } from "react";
import { publicRuntimeConfig } from "@/next.config";
import { useImageData } from "../../../../common/ImageData";
import { useTextData } from "../../../../common/TextData";
import styles from "./layer.module.scss";
import useTrans from "@/src/common/useTrans";
export default function Layer() {
  const {
    textData,
    setSelectText,
    selectedText,
    selectedBlock,
    setBlock,
    setTextData,
    multipleSelect,
  } = useTextData();
  const {
    newEditImage,
    setNewEditImage,
    setSelectImage,
    selectImage,
    removeBGImage,
    setRemoveBGImage,
    assetStageImages,
    setAssetStageImages,
  } = useImageData();

  const setLock = (id) => {
    const current = textData[id];
    if (current) {
      textData[id] = { ...current, isLock: !current.isLock };
    }
    setTextData([...textData]);
  };
  const setView = (id) => {
    const current = textData[id];
    if (current) {
      textData[id] = { ...current, isView: !current.isView };
    }
    setTextData([...textData]);
  };

  const handleLockAsset = (id) => {
    const current = assetStageImages[id];
    if (current) {
      assetStageImages[id] = { ...current, isLock: !current.isLock };
    }
    setAssetStageImages([...assetStageImages]);
  };

  const handleViewAsset = (id) => {
    const current = assetStageImages[id];
    if (current) {
      assetStageImages[id] = { ...current, isView: !current.isView };
    }
    setAssetStageImages([...assetStageImages]);
  };

  useEffect(() => {
    if (selectedBlock) {
      const elm = document.getElementById(selectedBlock);
      elm?.scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "nearest",
      });
      // elm.focus();
    }
  }, [selectedBlock]);

  return (
    <div className={styles.container}>
      <div className={styles.header}>{useTrans(`Layers`)}</div>
      <div className={styles.textContainer}>
        {newEditImage?.url && (
          <div
            onClick={() => {
              setSelectImage(newEditImage);
              setSelectText(null);
            }}
            className={styles.imageLayer}
            style={{
              border:
                selectImage === newEditImage
                  ? "1px solid #6F64FA"
                  : "1px solid #f1f1f6",
            }}
          >
            <img
              draggable={false}
              src={newEditImage.url}
              alt=""
              style={{ width: "100%", height: "100%", objectFit: "contain" }}
            />
            <div className={styles.iconLayer}>
              <img
                onClick={() =>
                  setNewEditImage({
                    ...newEditImage,
                    isLock: !newEditImage.isLock,
                  })
                }
                style={{ marginRight: "4px" }}
                src={
                  newEditImage.isLock
                    ? `${publicRuntimeConfig.basePath}/icons/miscellaneous/lock.svg`
                    : `${publicRuntimeConfig.basePath}/icons/miscellaneous/unlock.svg`
                }
                alt=""
              />
              <img
                onClick={() =>
                  setNewEditImage({
                    ...newEditImage,
                    isView: !newEditImage.isView,
                  })
                }
                src={
                  newEditImage.isView
                    ? `${publicRuntimeConfig.basePath}/icons/miscellaneous/eyeClose.svg`
                    : `${publicRuntimeConfig.basePath}/icons/miscellaneous/eye.svg`
                }
                alt=""
              />
            </div>
          </div>
        )}
        {removeBGImage.url && (
          <div
            onClick={() => {
              setSelectImage(removeBGImage);
              setSelectText(null);
            }}
            className={styles.imageLayer}
            style={{
              border:
                selectImage === removeBGImage
                  ? "1px solid #6F64FA"
                  : "1px solid #f1f1f6",
            }}
          >
            <img
              draggable={false}
              src={removeBGImage.url}
              alt=""
              style={{ width: "100%", height: "100%", objectFit: "contain" }}
            />
            <div className={styles.iconLayer}>
              <img
                onClick={() =>
                  setRemoveBGImage({
                    ...removeBGImage,
                    isLock: !newEditImage.isLock,
                  })
                }
                style={{ marginRight: "4px" }}
                src={
                  removeBGImage.isLock
                    ? `${publicRuntimeConfig.basePath}/icons/miscellaneous/lock.svg`
                    : `${publicRuntimeConfig.basePath}/icons/miscellaneous/unlock.svg`
                }
                alt=""
              />
              <img
                onClick={() =>
                  setRemoveBGImage({
                    ...removeBGImage,
                    isView: !removeBGImage.isView,
                  })
                }
                src={
                  removeBGImage.isView
                    ? `${publicRuntimeConfig.basePath}/icons/miscellaneous/eyeClose.svg`
                    : `${publicRuntimeConfig.basePath}/icons/miscellaneous/eye.svg`
                }
                alt=""
              />
            </div>
          </div>
        )}
        {assetStageImages?.length ? (
          assetStageImages.map((item, i) => (
            <div
              onClick={() => {
                setSelectImage(item);
                setSelectText(null);
              }}
              className={styles.imageLayer}
              style={{
                border:
                  selectImage === item
                    ? "1px solid #6F64FA"
                    : "1px solid #f1f1f6",
              }}
            >
              <img
                draggable={false}
                src={item.src}
                alt=""
                style={{ width: "100%", height: "100%", objectFit: "contain" }}
              />
              <div className={styles.iconLayer}>
                <img
                  onClick={() => handleLockAsset(i)}
                  style={{ marginRight: "4px" }}
                  src={
                    item.isLock
                      ? `${publicRuntimeConfig.basePath}/icons/miscellaneous/lock.svg`
                      : `${publicRuntimeConfig.basePath}/icons/miscellaneous/unlock.svg`
                  }
                  alt=""
                />
                <img
                  onClick={() => handleViewAsset(i)}
                  src={
                    item.isView
                      ? `${publicRuntimeConfig.basePath}/icons/miscellaneous/eyeClose.svg`
                      : `${publicRuntimeConfig.basePath}/icons/miscellaneous/eye.svg`
                  }
                  alt=""
                />
              </div>
            </div>
          ))
        ) : (
          <div></div>
        )}
        {textData?.length ? (
          [...textData]
            .filter((text) => text.selected)
            .map((item, index) => (
              <div
                id={item.id}
                className={styles.textLayer}
                key={index}
                onClick={() => {
                  setSelectText(item);
                  setBlock(null);
                  setSelectImage(null);
                }}
                style={{
                  border:
                    item.id === selectedText?.id ||
                    item.id === selectedBlock ||
                    multipleSelect?.some((select) => select?.id == item?.id)
                      ? "1px solid #6F64FA"
                      : "1px solid #f1f1f6",
                }}
              >
                {item.isShowTranslate ? item.translatedText : item.original_text}
                <div className={styles.iconLayer}>
                  <img
                    onClick={() => setLock(index)}
                    style={{ marginRight: "4px" }}
                    src={
                      item.isLock
                        ? `${publicRuntimeConfig.basePath}/icons/miscellaneous/lock.svg`
                        : `${publicRuntimeConfig.basePath}/icons/miscellaneous/unlock.svg`
                    }
                    alt=""
                  />
                  <img
                    onClick={() => setView(index)}
                    src={
                      item.isView
                        ? `${publicRuntimeConfig.basePath}/icons/miscellaneous/eyeClose.svg`
                        : `${publicRuntimeConfig.basePath}/icons/miscellaneous/eye.svg`
                    }
                    alt=""
                  />
                </div>
              </div>
            ))
        ) : (
          <div></div>
        )}
      </div>
    </div>
  );
}
