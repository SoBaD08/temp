import React, { useMemo } from "react";
import { publicRuntimeConfig } from "@/next.config";
import styles from "../SourceStage/sourceStage.module.scss";
import { Col, Row, Select, Spin, Tooltip } from "antd";
import { useZoom, ZOOM_MODE } from "@src/common/ZoomMode";
import { ZoomInOutlined, ZoomOutOutlined } from "@ant-design/icons";
import { useHistory } from "@/src/common/History";
import { useTextData } from "@/src/common/TextData";
import { useImageData } from "@/src/common/ImageData";
import { useEditorMode } from "@/src/common/EditorMode";
import useTrans from "@/src/common/useTrans";

export const Navbar = (props) => {
  const {
    isDisplaySourceStage,
    zoomOut,
    zoomIn,
    defaultValueScale,
    zoomByPercent,
  } = props;
  const { isSync, setSync, stageEditScale } = useZoom();

  const { historySteps, history } = useHistory();
  const { setTextData } = useTextData();
  const {
    setNewEditImage,
    setAssetStageImages,
    setSelect,
    DEFAULT_SELECT,
    DEFAULT_IMAGE,
    setRemoveBGImage,
  } = useImageData();
  const { setListComment } = useEditorMode();
  const handleChange = (option) => {
    zoomByPercent(option?.value);
  };
  const renderZoomOption = useMemo(() => {
    let options = [];
    for (let i = 40; i <= 250; i += 5) {
      options.push(
        <Option value={i / 100} className={styles.option} key={i}>
          {i}%
        </Option>
      );
    }
    return options;
  }, []);
  const handleUndo = () => {
    if (historySteps.current <= 1) {
      return;
    }
    historySteps.current -= 1;
    const previous = history[historySteps.current - 1];
    handleSetupData(previous);
  };
  const handleRedo = () => {
    if (historySteps.current >= history.length) {
      return;
    }
    historySteps.current += 1;
    const next = history[historySteps.current - 1];
    handleSetupData(next);
  };

  const handleSetupData = (data) => {
    if (!data) {
      return;
    }
    const {
      textData: textData = [],
      newEditImage: newEditImage = DEFAULT_IMAGE,
      select: select = DEFAULT_SELECT,
      assetStageImages: assetStageImages = [],
      comments: comments = [],
      removeBGImage: removeBGImage = DEFAULT_IMAGE,
    } = data;
    setTextData(textData);
    setNewEditImage(newEditImage);
    setSelect(select);
    setAssetStageImages([...assetStageImages]);
    setListComment(comments);
    setRemoveBGImage(removeBGImage);
  };

  return (
    <div className={styles.navbar}>
      <Row style={{ height: "54px" }} align="middle">
        <Col span={6}>
          <Row align="middle">
            <Col span={12} style={{ textAlign: "left" }}>
              <Tooltip
                placement="left"
                title={
                  <div
                    style={{
                      fontSize: "10px",
                      fontWeight: "400",
                    }}
                  >
                    <div>{useTrans(`ScrollSync`)}</div>
                    <div>{useTrans(`ScrollSyncDescription`)}</div>
                  </div>
                }
              >
                <img
                  src={
                    !isDisplaySourceStage || !isSync
                      ? `${publicRuntimeConfig.basePath}/icons/miscellaneous/unsync.svg`
                      : `${publicRuntimeConfig.basePath}/icons/miscellaneous/Sync_Icon.svg`
                  }
                  alt=""
                  onClick={() => {
                    setSync(!isSync);
                  }}
                />
              </Tooltip>
            </Col>
            <Col span={12} style={{ textAlign: "right" }}>
              <div>
                <Tooltip
                  placement="left"
                  title={
                    <span className="tooltipText">
                      {useTrans(`Undo`)}(Ctrt+Z)
                    </span>
                  }
                >
                  <img
                    src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/Undo_Icon.svg`}
                    alt=""
                    style={{ marginRight: "18px" }}
                    onClick={handleUndo}
                  />
                </Tooltip>
                <Tooltip
                  placement="right"
                  title={
                    <span className="tooltipText">
                      {useTrans(`Redo`)}(Ctrt+Y)
                    </span>
                  }
                >
                  <img
                    src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/Redo_Icon.svg`}
                    alt=""
                    onClick={handleRedo}
                  />
                </Tooltip>
              </div>
            </Col>
          </Row>
        </Col>
        <Col span={12} style={{ textAlign: "center" }}>
          <div>
            <Tooltip
              placement="left"
              title={
                <span className="tooltipText">
                  {useTrans(`ZoomOut`)} (Shift + "-")
                </span>
              }
            >
              <ZoomOutOutlined
                style={{
                  fontSize: "20px",
                  marginRight: "28px",
                  cursor: "pointer",
                }}
                onClick={zoomOut}
              />
            </Tooltip>
            <Tooltip
              placement="right"
              title={
                <span className="tooltipText">
                  {useTrans(`ZoomIn`)} (Shift + "+")
                </span>
              }
            >
              <ZoomInOutlined
                style={{
                  fontSize: "20px",
                  cursor: "pointer",
                }}
                onClick={zoomIn}
              />
            </Tooltip>
          </div>
        </Col>
        <Col span={6} style={{ textAlign: "right" }}>
          <div>
            <span className={styles.select}>
              <Select
                labelInValue
                dropdownStyle={{
                  fontSize: "10px",
                  width: "200px",
                }}
                defaultValue={defaultValueScale}
                style={{
                  width: "44px",
                  height: "22px",
                  fontSize: "12px",
                }}
                onChange={handleChange}
                value={
                  isSync
                    ? defaultValueScale
                    : {
                        value: `${Math.round(stageEditScale * 100)}`,
                        label: `${Math.round(stageEditScale * 100)}%`,
                      }
                }
              >
                {renderZoomOption}
              </Select>
            </span>
            <img
              src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/Eye2_Icon.svg`}
              alt=""
              style={{
                background: "#EDECFC",
                borderRadius: "5px",
                marginLeft: "24px",
              }}
            />
          </div>
        </Col>
      </Row>
    </div>
  );
};

export default Navbar;
