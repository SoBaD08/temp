import { publicRuntimeConfig } from "@/next.config";
import { Button, Dropdown, Menu, message, Space, Tooltip } from "antd";
import { useEffect, useMemo, useRef, useState } from "react";
import styles from "./header.module.scss";

import ForderProvider from "@/pages/api/ForderProvider";
import AlertModal from "@/src/common/AlertModal";
import { useEditorMode } from "@/src/common/EditorMode";
import { MODES } from "@/src/common/EditorMode/constant";
import { useHistory } from "@/src/common/History";
import { DownloadOutlined } from "@ant-design/icons";
import { downloadURI } from "@common/helper";
import { useTextData } from "@src/common/TextData";
import InvitePopup from "@src/components/layouts/Header/InvitePopup";
import { convertToRaw } from "draft-js";
import ReactShortcut from "react-shortcut";
import { v4 as uuidv4 } from "uuid";
import ImageITProvider from "../../../../pages/api/ImageITProvider";
import { useImageData } from "../../../common/ImageData";
import ConfirmMaskPopup from "./ConfirmMaskPopup";
import useTrans from "@/src/common/useTrans";
import { checkEnv } from "@/pages/authen/RouteGuard";
import { KEY_CODE } from "@/src/common/const";
function Header() {
  const {
    DEFAULT_IMAGE,
    setDefaultImage,
    setNameDefaultImage,
    defaultImage,
    newEditImage,
    setNewEditImage,
    setSelect,
    DEFAULT_SELECT,
    defaultImageUid,
    setRemoveBGImage,
    setSelectImage,
    setDefaultImageUid,
    setAssetStageImages,
    stageRef,
    ratio,
    handleSaveNewImage,
    select,
    nameDefaultImage,
    callBackDownload,
    setCallBackDownload,
    removeBGImage,
    saveState,
    setSaveState,
    selectImage,
    assetStageImages,
  } = useImageData();
  const {
    folder,
    history,
    setHistory,
    historySteps,
    setupHistory,
    layerCopy,
    setLayerCopy,
    folderId,
    setFolder,
  } = useHistory();
  const {
    setTextData,
    selectedText,
    textData,
    setSelectText,
    editText,
    styleMap,
    setEditText,
    setBlock,
    multipleSelect,
    setMultipleSelect,
  } = useTextData();
  const index = folder.assets?.length;
  const { currentMode, setMode, listComment, setListComment } = useEditorMode();
  const [showNotification, setShowNotification] = useState(false);

  const [showSaveNotification, setShowSaveNotification] = useState(false);
  const [loading, setLoading] = useState(false);
  const [listMedia, setListMedia] = useState([]);
  const invitePopupRef = useRef();
  const confirmMaskRef = useRef();
  const inputOpenRef = useRef();
  const handleChange = (e) => {
    const URL = window.webkitURL || window.URL;
    if (e.target.files && e.target.files.length) {
      const url = URL.createObjectURL(e.target.files[0]);
      let nameFile = e?.target?.files[0].name || "";
      let name = nameFile.slice(0, nameFile.lastIndexOf("."));
      setNameDefaultImage(name);
      const img = new Image();
      img.src = url;
      handleSaveNewImage(url, nameFile);
      setAssetStageImages([]);
      img.onload = function () {
        setDefaultImage({ ...defaultImage, url: url });
        setDefaultImageUid(null);
        setNewEditImage({ ...newEditImage, url: url, isView: true });
        setRemoveBGImage({
          url: null,
          isLock: false,
          isView: true,
        });
        setSelectImage(null);
        setShowNotification(false);

        handleSetupData({ newEditImage: { ...newEditImage, url: url } });
        setEditText(null);
        setBlock(null);
        setupHistory({ newEditImage: { ...newEditImage, url: url } });
      };
    }
  };
  const UploadImage = useTrans(`UploadImage`);
  const handleSave =
    (openFile = false) =>
    async () => {
      try {
        setLoading(true);
        if (showNotification) {
          setShowNotification(false);
        }
        if (showSaveNotification) {
          setShowSaveNotification(false);
        }
        if (!newEditImage.url) {
          message.error(UploadImage);
        } else {
          autoSave();
        }

        if (openFile) {
          inputOpenRef.current.click();
        }
        setLoading(false);
      } catch (error) {
        console.log(error);
        message.error(UploadImage);
      }
    };
  const displayWindow = (e) => {
    if (!defaultImage?.url && !newEditImage?.url) {
      return;
    } else {
      if (showNotification || showSaveNotification) {
        setShowNotification(false);
        setShowSaveNotification(false);
        return;
      } else {
        setShowNotification(true);
        e.preventDefault();
      }
    }
  };

  const handleUndo = () => {
    if (historySteps.current <= 1) {
      return;
    }
    historySteps.current -= 1;
    const previous = history[historySteps.current - 1];
    handleSetupData(previous);
  };
  const handleRedo = () => {
    if (historySteps.current >= history.length) {
      return;
    }
    historySteps.current += 1;
    const next = history[historySteps.current - 1];
    handleSetupData(next);
  };

  const handleSetupData = (data) => {
    if (!data) {
      return;
    }
    const {
      textData: textData = [],
      newEditImage: newEditImage = DEFAULT_IMAGE,
      select: select = DEFAULT_SELECT,
      assetStageImages: assetStageImages = [],
      comments: comments = [],
      removeBGImage: removeBGImage = DEFAULT_IMAGE,
    } = data;
    setTextData(textData);
    setNewEditImage(newEditImage);
    setSelect(select);
    setAssetStageImages([...assetStageImages]);
    setListComment(comments);
    setRemoveBGImage(removeBGImage);
  };
  const ChooseLayer = useTrans(`ChooseLayer`);
  const handleCopy = () => {
    if (!selectedText && !multipleSelect.length) {
      message.error(ChooseLayer);
      return;
    }
    if (selectedText) {
      setLayerCopy([selectedText]);
    }
    if (multipleSelect.length) {
      setLayerCopy(multipleSelect);
    }
  };
  const NoLayer = useTrans(`NoLayer`);
  const handlePaste = () => {
    if (!selectedText && !multipleSelect.length) {
      message.error(NoLayer);
      return;
    }
    let layerPaste = [...layerCopy].map((item) => {
      return {
        ...item,
        id: uuidv4(),
        rectangle_coordinates: item?.rectangle_coordinates
          ? item?.rectangle_coordinates.map((item) => ({
              x: (item.x || 0) + 10,
              y: (item.y || 0) + 10,
            }))
          : [],
      };
    });
    let newTextData = [...textData, ...layerPaste];
    setTextData(newTextData);
    setLayerCopy(layerPaste);
    setHistory({ textData: newTextData });
  };
  const SelectLayer = useTrans(`SelectLayer`);
  const handleDelete = () => {
    if (!selectedText) {
      message.error(SelectLayer);
      return;
    }
    const temp = [...textData].filter((item) => item !== selectedText);
    const temp2 = assetStageImages.filter((item) => item !== selectImage);
    setAssetStageImages([...temp2]);
    setTextData(temp);
    setHistory({ textData: temp });
    setHistory({ assetsStageImages: [...temp2] });
  };
  const handleSelectAll = () => {
    setMultipleSelect(textData);
  };
  const SaveAssetSuccess = useTrans(`SaveAssetSuccess`);
  const SaveAssetError = useTrans(`SaveAssetError`);
  const handleSaveAsset = async () => {
    if (!newEditImage?.url && !defaultImage.url) {
      message.warn(UploadImage);
      return;
    }
    try {
      let folderId = folder._id;
      const image = stageRef.current.toDataURL();
      const response = await fetch(image);
      // here image is url/location of image
      const blob = await response.blob();
      const editor = new File([blob], "image_asset.png", { type: "image/png" });
      const res = await ImageITProvider.postFileImage({
        file: editor,
        application: "image",
        model: folderId,
      });
      const imageId = res._id;
      let body = {
        asset: {
          media: imageId,
          index: index,
        },
      };
      ForderProvider.saveAsset(folderId, body).then((res) => {
        setFolder(res.data);
        message.success(SaveAssetSuccess);
      });
    } catch (error) {
      console.log(error);
      message.error(SaveAssetError);
    }
  };

  const checkRemoveObjectMask = (select) => {
    if (!select) {
      return false;
    }
    let checkLine =
      select?.lines?.length &&
      (select?.lines || []).some((item) => item?.points);
    let checkRetange =
      select?.rectanges?.length &&
      (select?.rectanges || []).some((item) => item?.width && item?.height);
    return checkLine || checkRetange;
  };

  const handleExport = (type = "png") => {
    if (!stageRef || !stageRef.current) {
      return;
    }
    if (checkRemoveObjectMask(select)) {
      confirmMaskRef.current.onOpen(type);
      return;
    }
    const uri = stageRef.current.toDataURL();
    downloadURI(uri, nameDefaultImage, type);
  };
  const downloadExtension = [
    {
      key: "4-1",
      label: (
        <div
          onClick={() => {
            handleExport("png");
          }}
        >
          <span>PNG</span>
        </div>
      ),
    },
    {
      key: "4-2",
      label: (
        <div
          onClick={() => {
            handleExport("jpg");
          }}
        >
          <span>JPG</span>
        </div>
      ),
    },
    {
      key: "4-3",
      label: (
        <div
          onClick={() => {
            handleExport("jpeg");
          }}
        >
          <span>JPEG</span>
        </div>
      ),
    },
    {
      key: "4-4",
      label: (
        <div
          onClick={() => {
            handleExport("tiff");
          }}
        >
          <span>TIFF</span>
        </div>
      ),
    },
  ];
  const selectMedia = (id) => async () => {
    let res = await ImageITProvider.getSignedUrlMedia(id);
    let { signedUrl = "" } = res;
    if (signedUrl) {
      setDefaultImage({ ...defaultImage, url: signedUrl });
      setNewEditImage({ ...newEditImage, url: signedUrl, isView: true });
      setDefaultImageUid({ _id: id });
      setRemoveBGImage({
        url: null,
        isLock: false,
        isView: true,
      });
      setSelectImage(null);
      setShowNotification(false);
      handleSetupData({ newEditImage: { ...newEditImage, url: signedUrl } });
      setEditText(null);
      setBlock(null);
      setupHistory({ newEditImage: { ...newEditImage, url: signedUrl } });
    }
  };
  const openLocal = {
    key: "1-1",
    label: (
      <div>
        <span style={{ marginRight: "15px" }}>{useTrans(`OpenFromLocal`)}</span>
        <input
          id="selectImage"
          accept="image/*"
          onClick={displayWindow}
          onChange={(e) => {
            handleChange(e);
          }}
          type="file"
          className={styles.inputFile}
          ref={inputOpenRef}
        />
        <span>Ctrl + O</span>
      </div>
    ),
  };

  const openFile = useMemo(() => {
    // let listFile = listMedia.map((item) => {
    //   return {
    //     key: `1-${item._id}`,
    //     label: (
    //       <div onClick={selectMedia(item._id)}>
    //         <span>{item?.filename}</span>
    //       </div>
    //     ),
    //   };
    // });
    let listFile = [];
    listFile.unshift(openLocal);
    return listFile;
  }, [
    listMedia,
    defaultImage,
    newEditImage,
    showNotification,
    showSaveNotification,
  ]);

  const menuFile = (
    <Menu
      className={styles.menuDropdown}
      forceSubMenuRender
      items={[
        {
          label: (
            <div
              className={styles.itemMenu}
              onClick={() => setShowSaveNotification(true)}
            >
              <span>{useTrans(`New`)}</span>
              <span>Ctrl + N</span>
            </div>
          ),
          key: "0",
        },
        {
          label: (
            <div className={styles.itemMenu}>
              <span>{useTrans(`OpenFile`)}</span>
            </div>
          ),
          popupClassName: "itemSubMenu",
          children: openFile,
          key: "1",
        },
        {
          type: "divider",
        },
        {
          label: (
            <div className={styles.itemMenu} onClick={handleSave()}>
              <span>{useTrans(`Save`)}</span>
              <span>Ctrl + S</span>
            </div>
          ),
          key: "2",
        },
        {
          label: (
            <div className={styles.itemMenu}>
              <span>{useTrans(`SaveAs`)}</span>
              <span>Ctrl + Alt + S</span>
            </div>
          ),
          key: "3",
        },
        {
          label: (
            <div className={styles.itemMenu} onClick={handleSaveAsset}>
              <span>{useTrans(`SaveAsAsset`)}</span>
              <span>Ctrl + Alt + A</span>
            </div>
          ),
          key: "saveAsset",
        },
        {
          type: "divider",
        },
        {
          key: "4",
          label: (
            <div className={styles.itemMenu}>
              <span>{useTrans(`Download`)}</span>
            </div>
          ),
          popupClassName: "itemSubMenu",
          children: downloadExtension,
        },
      ]}
    />
  );

  const menuEdit = (
    <Menu
      className={styles.menuDropdown}
      forceSubMenuRender
      items={[
        {
          label: (
            <div className={styles.itemMenu} onClick={handleUndo}>
              <span>{useTrans(`Undo`)}</span>
              <span>Ctrl + Z</span>
            </div>
          ),
          key: "0",
        },
        {
          label: (
            <div className={styles.itemMenu} onClick={handleRedo}>
              <span>{useTrans(`Redo`)}</span>
              <span>Ctrl + Y</span>
            </div>
          ),
          key: "1",
        },
        {
          type: "divider",
        },
        {
          label: (
            <div className={styles.itemMenu} onClick={handleCopy}>
              <span>{useTrans(`Copy`)}</span>
              <span>Ctrl + C</span>
            </div>
          ),
          key: "2",
        },
        {
          label: (
            <div className={styles.itemMenu} onClick={handlePaste}>
              <span>{useTrans(`Paste`)}</span>
              <span>Ctrl + V</span>
            </div>
          ),
          key: "3",
        },
        {
          type: "divider",
        },
        {
          key: "4",
          label: (
            <div className={styles.itemMenu} onClick={handleDelete}>
              <span>{useTrans(`Delete`)}</span>
              <span>{useTrans(`Delete`)}</span>
            </div>
          ),
        },
        {
          key: "5",
          label: (
            <div className={styles.itemMenu} onClick={handleSelectAll}>
              <span>{useTrans(`SelectAll`)}</span>
              <span>Ctrl + A</span>
            </div>
          ),
        },
      ]}
    />
  );

  const menuDownload = (
    <Menu
      className={styles.menuDropdown}
      style={{ marginTop: "10px" }}
      forceSubMenuRender
      items={downloadExtension}
    />
  );
  const openInvitePopup = () => {
    invitePopupRef.current.onOpen();
  };
  const handleComment = () => {
    if (currentMode == MODES.COMMENT) {
      setMode(null);
    } else {
      setMode(MODES.COMMENT);
    }
  };
  const SHORTCUTDATA = [
    {
      key: "ctrl+s",
      function: handleSave(),
    },
    {
      key: "ctrl+z",
      function: handleUndo,
    },
    {
      key: "ctrl+y",
      function: handleRedo,
    },
    {
      key: "ctrl+c",
      function: handleCopy,
    },
    {
      key: "ctrl+v",
      function: handlePaste,
    },
    {
      key: "del",
      function: handleDelete,
    },
    {
      key: "alt+a",
      function: handleSelectAll,
    },
    {
      key: "ctrl+shift+a",
      function: handleSaveAsset,
    },
    {
      key: "ctrl+shift+d",
      function: handleExport,
    },
    {
      key: "ctrl+a",
      function: handleSelectAll,
    },
  ];
  useEffect(() => {
    document.addEventListener(
      "keydown",
      function (e) {
        if (
          Object.values(KEY_CODE).includes(e.keyCode) &&
          (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)
        ) {
          e.preventDefault();
        }
        if (
          (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey) &&
          e.keyCode === 189
        ) {
          e.preventDefault();
        }
        if (
          (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey) &&
          e.keyCode === 187
        ) {
          e.preventDefault();
        }
      },
      false
    );
  }, []);
  useEffect(() => {
    getListMedia();
  }, []);
  useEffect(() => {
    if (callBackDownload) {
      setTimeout(() => {
        handleExport(callBackDownload);
      }, 1000);
      setCallBackDownload(null);
    }
  }, [callBackDownload, select]);
  const delayRef = useRef();
  const DELAY_TIME = 30 * 1000; // 30s
  useEffect(() => {
    if (history && history.length > 1) {
      if (delayRef.current) {
        clearTimeout(delayRef.current);
        delayRef.current = 0;
      }
      delayRef.current = setTimeout(() => {
        autoSave();
      }, DELAY_TIME);
    }
  }, [history]);
  useEffect(() => {
    if (!newEditImage.url) {
      setSaveState("");
    }
  }, [newEditImage]);
  const SaveImageSuccess = useTrans(`SaveImageSuccess`);
  const SaveImageFail = useTrans(`SaveImageFail`);
  const autoSave = async () => {
    setSaveState("Saving");
    try {
      if (!stageRef || !stageRef.current) {
        return;
      }
      const image = removeBGImage?.url ? removeBGImage.url : newEditImage.url;
      const response = await fetch(image);
      // here image is url/location of image
      const blob = await response.blob();
      const editor = new File([blob], "image.png", { type: "image/png" });
      // convert State leatest to JSON
      let payloadHistory = { ...history[history.length - 1] };
      if (payloadHistory.textData) {
        let TextDataJson = payloadHistory.textData.map((item) => {
          if (item.image) {
            const contentState = item.editorText.getCurrentContent();
            return {
              ...item,
              image: item?.image?.toDataURL(),
              editorText: convertToRaw(contentState),
            };
          } else return item;
        });
        payloadHistory.textData = TextDataJson;
      }
      payloadHistory.styleMap = styleMap;
      payloadHistory.ratio = ratio;
      const editorImage = await ImageITProvider.postFileImage({
        file: editor,
        application: "image",
        model: folderId,
        data: JSON.stringify(payloadHistory),
      });
      if (editorImage?._id) {
        const saveImageFolder = await ForderProvider.saveEdited({
          _id: folderId,
          images: [
            {
              _id: folder.filesets[folder.filesets.length - 1]._id,
              edited: editorImage._id,
            },
          ],
        });
        message.success(SaveImageSuccess);
      }
      setSaveState("Saved");
    } catch (error) {
      message.error(SaveImageFail);
      console.log(error);
      setSaveState("SaveFailed");
    }
  };
  const getListMedia = async () => {
    try {
      let res = await ImageITProvider.getMedia();
      if (res && res.length) {
        setListMedia(res);
      } else {
        setListMedia([]);
      }
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <>
      {SHORTCUTDATA.map((item, index) => (
        <ReactShortcut
          key={index}
          keys={item.key}
          onKeysPressed={(e) => {
            if (editText) {
              return;
            }
            item.function();
          }}
        />
      ))}

      <div className={styles.headerContainer}>
        <div className={styles.leftPart}>
          <Tooltip
            placement="bottomRight"
            title={<span className="tooltipText">{useTrans(`Dashboard`)}</span>}
          >
            <div
              className={styles.headerIcon}
              onClick={() =>
                window.location.replace(
                  `https://${checkEnv(
                    window.location.href
                  )}imageit.io/dashboard`
                )
              }
            />
          </Tooltip>
          <div className={styles.headerText}>
            <Dropdown
              overlay={menuFile}
              trigger="click"
              overlayStyle={{
                width: 240,
                borderRadius: "5px",
                height: 34,
              }}
            >
              <Space>{useTrans(`File`)}</Space>
            </Dropdown>
          </div>
          <AlertModal
            visible={showNotification || showSaveNotification}
            loading={loading}
            text={useTrans(`SaveOption`)}
            handleAccept={handleSave(openFile)}
            handleCancel={() => {
              if (showNotification) {
                setShowNotification(false);
              }
              if (showSaveNotification) {
                setShowSaveNotification(false);
              }
              inputOpenRef.current.click();
            }}
          />
          <div className={styles.headerText}>
            <Dropdown
              overlay={menuEdit}
              trigger="click"
              overlayStyle={{
                width: 240,
                borderRadius: "5px",
                height: 34,
              }}
            >
              <Space>{useTrans(`Edit`)}</Space>
            </Dropdown>
          </div>
        </div>
        <div className={styles.fileName}>
          <div> {`${folder?.name || "fileName"}_edit`}</div>
          <div style={{ cursor: "pointer" }}>
            <img
              style={{ marginLeft: "16px", marginRight: "8px" }}
              src={`${publicRuntimeConfig.basePath}/icons/header/Cloud_Icon.svg`}
              alt=""
            />
            <span>
              {/* {useTrans(`Saved`)} */}
              {useTrans(saveState)}
            </span>
          </div>
        </div>

        <div className={styles.rightPart}>
          <Tooltip
            placement="bottom"
            title={
              <div className="tooltipText">
                <div>{useTrans(`Comment`)}</div>
              </div>
            }
          >
            <img
              src={`${publicRuntimeConfig.basePath}/icons/header/Comment-icon.svg`}
              style={{
                marginRight: "12px",
                marginLeft: "17px",
              }}
              onClick={handleComment}
            />
          </Tooltip>

          <div>
            <Dropdown
              overlay={menuDownload}
              trigger="click"
              overlayStyle={{
                width: 120,
                borderRadius: "5px",
                height: 44,
              }}
            >
              <Button
                ghost
                size="small"
                icon={<DownloadOutlined />}
                style={{
                  borderRadius: "4px",
                  borderColor: "#878CFF",
                  fontSize: "10px",
                  marginLeft: "12px",
                }}
              >
                {useTrans(`Download`)}
              </Button>
            </Dropdown>
          </div>
        </div>
      </div>

      <InvitePopup ref={invitePopupRef} />
      <ConfirmMaskPopup ref={confirmMaskRef} />
    </>
  );
}

export default Header;
