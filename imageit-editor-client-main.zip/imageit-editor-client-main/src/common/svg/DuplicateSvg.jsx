import React from "react";
const Index = (props) => (
  <svg
    {...props}
    width="18"
    height="18"
    viewBox="0 0 18 18"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M13 5V2.33333C13 1.59695 12.403 1 11.6667 1H2.33333C1.59695 1 1 1.59695 1 2.33333V11.6667C1 12.403 1.59695 13 2.33333 13H5"
      stroke={props?.active ? "#6F64FA" : "#45454B"}
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M15.6667 5H6.33333C5.59695 5 5 5.59695 5 6.33333V15.6667C5 16.403 5.59695 17 6.33333 17H15.6667C16.403 17 17 16.403 17 15.6667V6.33333C17 5.59695 16.403 5 15.6667 5Z"
      stroke={props?.active ? "#6F64FA" : "#45454B"}
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M11 8.33325V13.6666"
      stroke={props?.active ? "#6F64FA" : "#45454B"}
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M8.3335 11H13.6668"
      stroke={props?.active ? "#6F64FA" : "#45454B"}
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);
export default Index;
