import React from "react";

import TextCenter from "./svg/TextCenter";
import TextLeft from "./svg/TextLeft";
import TextRight from "./svg/TextRight";
import Uppercase from "./svg/Uppercase";
import Lowercase from "./svg/Lowercase";
import UppercaseFirst from "./svg/UppercaseFirst";
import UnderLine from "./svg/UnderLine";
import LineThrough from "./svg/LineThrough";

export const MAX_LINE = 60;

export const DRAFT_STYLE_MAP = {
    // font-family
    FONT_FAMILY_ARIAL: { fontFamily: "Arial" },
    FONT_FAMILY_VERDANA: { fontFamily: "Verdana" },
    FONT_FAMILY_HELVETICA: { fontFamily: "Helvetica" },
    FONT_FAMILY_TAHOMA: { fontFamily: "Tahoma" },
    FONT_FAMILY_Trebuchet_MS: { fontFamily: "Trebuchet MS" },
    FONT_FAMILY_TIMES_NEW_ROMAN: { fontFamily: "Times New Roman" },
    FONT_FAMILY_GARAMOND: { fontFamily: "Garamond" },
    FONT_FAMILY_CALIBRI: { fontFamily: "Calibri" },
    FONT_FAMILY_PAPYRUS: { fontFamily: "papyrus" },
    FONT_FAMILY_BRUSH_SCRIPT_MT: { fontFamily: "Brush Script MT" },
    FONT_FAMILY_COMIC_SANS_MS: { fontFamily: "Comic Sans MS" },

    // font-weight
    FONT_WEIGHT_THIN: { fontWeight: 100 },
    FONT_WEIGHT_REGULAR: { fontWeight: 400 },
    FONT_WEIGHT_BOLD: { fontWeight: 700 },
    FONT_WEIGHT_HEAVY: { fontWeight: 900 },

    // font-size
    FONT_SIZE_9: { fontSize: 9 },
    FONT_SIZE_10: { fontSize: 10 },
    FONT_SIZE_11: { fontSize: 11 },
    FONT_SIZE_12: { fontSize: 12 },
    FONT_SIZE_14: { fontSize: 14 },
    FONT_SIZE_16: { fontSize: 16 },
    FONT_SIZE_18: { fontSize: 18 },
    FONT_SIZE_20: { fontSize: 20 },
    FONT_SIZE_22: { fontSize: 22 },
    FONT_SIZE_24: { fontSize: 24 },
    FONT_SIZE_26: { fontSize: 26 },
    FONT_SIZE_28: { fontSize: 28 },
    FONT_SIZE_30: { fontSize: 30 },
    FONT_SIZE_36: { fontSize: 36 },
    FONT_SIZE_48: { fontSize: 48 },

    // text-transform
    UPPERCASE: { textTransform: "uppercase" },
    LOWERCASE: { textTransform: "lowercase" },
    UPPERCASEFIRST: { textTransform: "capitalize" },
    UNDERLINE: { textDecoration: "underline" },
    LINETHROUGH: { textDecoration: "line-through" },

}

export const EDIT_TEXT = [
    {
        image: <Uppercase />,
        value: "uppercase",
        attribute: "textTransform",
    },
    {
        image: <Lowercase />,
        value: "lowercase",
        attribute: "textTransform",
    },
    {
        image: <UppercaseFirst />,
        value: "capitalize",
        attribute: "textTransform",
    },
    {
        image: <UnderLine />,
        name: "underLine",
        attribute: "textDecoration",
    },
    {
        image: <LineThrough />,
        name: "line-through",
        attribute: "textDecoration",
    },
]

export const ALIGN_TEXT = [
    {
        image: <TextLeft />,
        name: "left"
    },
    {
        image: <TextCenter />,
        name: "center"
    },
    {
        image: <TextRight />,
        name: "right"
    },
]

export const LIST_FONT_FAMILY = [
    "Arial",
    "Verdana",
    "Helvetica",
    "Tahoma",
    "Trebuchet MS",
    "Times New Roman",
    "Garamond",
    "Calibri",
    "papyrus",
    "Brush Script MT",
    "Comic Sans MS",
]

export const LIST_FONT_SIZE = [
    9,
    10,
    11,
    12,
    14,
    16,
    18,
    20,
    22,
    24,
    26,
    28,
    30,
    36,
    48,
    52,
    60,
    72,
]

export const KEY_CODE = {
    s: 83,
    a: 65,
    e: 69,
    r: 82,
    o: 79,
    t: 84,
    d: 68,
}
