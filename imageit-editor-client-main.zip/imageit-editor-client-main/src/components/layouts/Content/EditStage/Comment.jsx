import React, { useEffect, useRef, useState } from "react";
import { Image, Layer, Rect, Text } from "react-konva";
import { Html } from "react-konva-utils";
import useImage from "use-image";
import CommentSvg from "public/image/comment-icon.png";
import { MODES } from "@/src/common/EditorMode/constant";
import { Tooltip } from "antd";

const Comment = (props) => {
  const [iconComment] = useImage(CommentSvg.src, "anonymous");
  const {
    ratio,
    currentMode,
    newComment,
    commentingRef,
    setNewComment,
    listComment,
  } = props;

  const commentRef = useRef();
  const customCursor = () => {
    return `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='28' height='25' viewBox='0 0 28 25' fill='none'><path  d='M0 14C0 6.26801 6.26801 0 14 0H16.3333C22.7767 0 28 5.22334 28 11.6667V11.6667C28 19.0305 22.0305 25 14.6667 25H0V14Z' fill='gray'></path><path d='M14 0.5H16.3333C22.5005 0.5 27.5 5.49949 27.5 11.6667C27.5 18.7543 21.7543 24.5 14.6667 24.5H0.5V14C0.5 6.54416 6.54416 0.5 14 0.5Z' stroke='white' stroke-opacity='0.1'></path></svg>") 16 0,auto`;
  };

  useEffect(() => {
    if (commentRef.current) {
      if (currentMode == MODES.COMMENT) {
        commentRef.current.canvas._canvas.style.cursor = customCursor();
      } else {
        commentRef.current.canvas._canvas.style.cursor = "default";
      }
    }
  }, [commentRef.current, currentMode]);
  const handleClick = (e) => {
    if (commentingRef.current) {
      cancelComment();
    } else {
      createComment(e);
    }
  };
  const createComment = (e) => {
    let x = e.evt.layerX;
    let y = e.evt.layerY;
    setNewComment({
      coordinate: {
        x: x,
        y: y,
      },
      index: listComment.length + 1,
      content: "",
    });
    commentingRef.current = true;
  };
  const cancelComment = () => {
    commentingRef.current = false;
    setNewComment(null);
  };
  return (
    <>
      {!!(
        listComment &&
        listComment.length &&
        currentMode == MODES.COMMENT
      ) && (
        <>
          <Layer scaleX={ratio} scaleY={ratio}>
            <Html
              divProps={{
                style: {
                  position: "absolute",
                  background: "transparent",
                },
              }}
            >
              {listComment.map((item, index) => {
                return (
                  <div
                    style={{
                      position: "absolute",
                      left: item.coordinate.x - 8,
                      top: item.coordinate.y + 2,
                      cursor: "pointer",
                    }}
                  >
                    <Tooltip
                      placement="topLeft"
                      title={item.content}
                      color="#6F64FA"
                    >
                      <img src={CommentSvg.src} />
                      <div
                        style={{
                          position: "absolute",
                          top: "3px",
                          left: "6px",
                          userSelect: "none",
                        }}
                      >
                        {listComment.length - index}
                      </div>
                    </Tooltip>
                  </div>
                );
              })}
            </Html>
          </Layer>
          <Layer
            scaleX={ratio}
            scaleY={ratio}
            onClick={handleClick}
            ref={commentRef}
          >
            <Rect x={0} y={0} width={5000} height={5000} visible={true}></Rect>
            {commentingRef.current && (
              <>
                <Image
                  image={iconComment}
                  x={newComment.coordinate.x - 8}
                  y={newComment.coordinate.y + 2}
                />
                <Text
                  x={newComment.coordinate.x - 1}
                  y={newComment.coordinate.y + 10}
                  text={newComment.index}
                  fontSize={12}
                ></Text>
              </>
            )}
          </Layer>
        </>
      )}
    </>
  );
};
export default Comment;
