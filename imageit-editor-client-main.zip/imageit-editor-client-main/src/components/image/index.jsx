import React from "react";
import NextImage from "next/image";
import config from "../../../next.config";

const Image = (props) => {
  const url = props.src?.startsWith("/")
    ? `${config.basePath || ""}${props.src}`
    : props.src;

  return <NextImage {...props} src={url} />;
};

export default Image;
