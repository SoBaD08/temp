import React, { useState, useContext } from "react";
import { BUTTONS } from "./constant";

export const ButtonModeContext = React.createContext();

function ButtonModeProvider({ children }) {
  const [buttonMode, setButtonMode] = useState();
  return (
    <ButtonModeContext.Provider
      value={{
        buttonMode,
        setButtonMode,
      }}
    >
      {children}
    </ButtonModeContext.Provider>
  );
}

const withButtonMode = (Component) => (props) => {
  return (
    <ButtonModeProvider>
      <Component {...props} />
    </ButtonModeProvider>
  );
};

export const useButtonMode = () => {
  const data = useContext(ButtonModeContext);
  return data;
};

export default withButtonMode;
