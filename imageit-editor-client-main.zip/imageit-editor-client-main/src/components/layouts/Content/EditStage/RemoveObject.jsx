import { MAX_LINE } from "@common/const";
import { useEffect, useRef, useState } from "react";
import { Layer, Line, Rect } from "react-konva";
const ObjectEraser = (props) => {
  const {
    defaultImage,
    select,
    setSelect,
    ratio,
    selectRef,
    history,
    setHistory,
    stageEditScale,
  } = props;
  const isDrawing = useRef(false);
  const { lines, rectanges } = select;

  const [lineDrawing, setLineDrawing] = useState([]);
  const [retangeDrawing, setRetangeDrawing] = useState();
  const [sizeDrawing, setSizeDrawing] = useState();

  const handleMouseDown = (e) => {
    isDrawing.current = true;
    switch (select.type) {
      case "elipse": {
        const pos = e.target.getStage().getPointerPosition();
        const x = pos.x;
        const y = pos.y;
        setLineDrawing([x, y]);
        setSizeDrawing(select?.size || 50);
        break;
      }
      case "retange": {
        const pos = e.target.getStage().getPointerPosition();
        const x = pos.x;
        const y = pos.y;
        setRetangeDrawing({
          visible: true,
          x: x,
          y: y,
          width: 0,
          height: 0,
        });
      }
      default:
        break;
    }
  };

  const handleMouseMove = (e) => {
    e.target.preventDefault();
    e.evt.preventDefault();
    e.cancelBubble = true;
    // no drawing - skipping
    if (!isDrawing.current) {
      return;
    }
    switch (select.type) {
      case "elipse": {
        const stage = e.target.getStage();
        const point = stage.getPointerPosition();
        // add point
        let newLineDrawing = [...lineDrawing]?.concat([point?.x, point?.y]);
        // replace linedrawing
        setLineDrawing(newLineDrawing);
        break;
      }
      case "retange": {
        let stage = e.target.getStage();
        let x1 = retangeDrawing.x;
        let y1 = retangeDrawing.y;
        let x2 = stage.getPointerPosition().x;
        let y2 = stage.getPointerPosition().y;
        setRetangeDrawing({
          visible: true,
          x: x1,
          y: y1,
          width: x2 - x1,
          height: y2 - y1,
        });
        break;
      }
      default:
        break;
    }
  };

  const handleMouseUp = (e) => {
    if (select.type === "retange") {
      const x1 = retangeDrawing.x;
      const y1 = retangeDrawing.y;
      let { x, y } = e.target.getStage().getPointerPosition();
      const annotationToAdd = {
        visible: true,
        x: x1,
        y: y1,
        width: x - x1,
        height: y - y1,
        scale: stageEditScale || 1,
      };
      const tempRectange = [...rectanges];
      tempRectange.push(annotationToAdd);
      const newSelect = {
        ...select,
        rectanges: [...tempRectange],
      };
      setSelect(newSelect);
      setHistory({ select: newSelect });
    } else {
      let lastLine = {
        points: lineDrawing,
        size: sizeDrawing,
        scale: stageEditScale || 1,
      };
      let newSelect = {
        ...select,
        lines: [...lines, lastLine],
      };
      setSelect(newSelect);
      setHistory({ select: newSelect });
    }
    setLineDrawing(null);
    setRetangeDrawing(null);
    isDrawing.current = false;
  };

  useEffect(() => {
    setSelect({
      type: "elipse",
      size: "50",
      lines: [],
      rectanges: [
        {
          visible: false,
          x: 0,
          y: 0,
          width: 0,
          height: 0,
        },
      ],
      imageSelect: "",
    });
  }, [defaultImage]);

  const customCursor = (type, size) => {
    if (type == "retange") {
      return `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20'><path d='M9 0H11V7H9V0ZM9 13H11V20H9V13ZM13 9H20V11H13V9ZM0 9H7V11H0V9Z' fill='black'></path></svg>") 16 0,auto`;
    }
    return `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='${
      (size / 100) * MAX_LINE
    }' height='${
      (size / 100) * MAX_LINE
    }' viewBox='0 0 20 20'><path d='M10 0C8.68678 0 7.38642 0.258658 6.17317 0.761205C4.95991 1.26375 3.85752 2.00035 2.92893 2.92893C1.05357 4.8043 0 7.34784 0 10C0 12.6522 1.05357 15.1957 2.92893 17.0711C3.85752 17.9997 4.95991 18.7362 6.17317 19.2388C7.38642 19.7413 8.68678 20 10 20C12.6522 20 15.1957 18.9464 17.0711 17.0711C18.9464 15.1957 20 12.6522 20 10C20 8.68678 19.7413 7.38642 19.2388 6.17317C18.7362 4.95991 17.9997 3.85752 17.0711 2.92893C16.1425 2.00035 15.0401 1.26375 13.8268 0.761205C12.6136 0.258658 11.3132 0 10 0Z' fill='deepskyblue' opacity='0.8'></path></svg>") ${
      (size / 200) * MAX_LINE
    } ${(size / 200) * MAX_LINE},auto`;
  };

  useEffect(() => {
    if (selectRef.current) {
      selectRef.current.canvas._canvas.style.opacity = 0.8;
      selectRef.current.canvas._canvas.style.cursor = customCursor(
        select.type,
        select.size
      );
    }
  }, [selectRef.current, select.type, select.size]);

  return (
    <Layer
      scaleX={ratio}
      scaleY={ratio}
      onMouseDown={handleMouseDown}
      onMousemove={handleMouseMove}
      onMouseup={handleMouseUp}
      ref={selectRef}
    >
      <Rect x={0} y={0} width={5000} height={5000} visible={true}></Rect>
      {lines && lines.length
        ? lines.map((line, i) => (
            <Line
              key={i}
              scaleX={1 / line?.scale}
              scaleY={1 / line?.scale}
              points={line.points}
              stroke="#F1F1F6"
              strokeWidth={((line.size * line?.scale) / 100) * MAX_LINE}
              tension={0.5}
              lineCap="round"
              lineJoin="round"
            />
          ))
        : null}
      {rectanges && rectanges.length
        ? rectanges.map((rect, i) => (
            <Rect
              key={i}
              x={rect.x / rect?.scale}
              y={rect.y / rect?.scale}
              width={rect.width / rect?.scale}
              height={rect.height / rect?.scale}
              visible={rect.visible}
              fill="#F1F1F6"
              stroke="#E8E2E2"
            ></Rect>
          ))
        : null}
      {isDrawing.current ? (
        <>
          {lineDrawing?.length ? (
            <Line
              scaleX={1 / stageEditScale}
              scaleY={1 / stageEditScale}
              points={lineDrawing}
              stroke="#F1F1F6"
              strokeWidth={((sizeDrawing * stageEditScale) / 100) * MAX_LINE}
              tension={0.5}
              lineCap="round"
              lineJoin="round"
            />
          ) : null}
          {retangeDrawing?.visible ? (
            <Rect
              scaleX={1 / stageEditScale}
              scaleY={1 / stageEditScale}
              x={retangeDrawing?.x / stageEditScale}
              y={retangeDrawing?.y / stageEditScale}
              width={retangeDrawing?.width}
              height={retangeDrawing?.height}
              visible={retangeDrawing?.visible}
              fill="#F1F1F6"
              stroke="#E8E2E2"
            ></Rect>
          ) : null}
        </>
      ) : null}
    </Layer>
  );
};
export default ObjectEraser;
