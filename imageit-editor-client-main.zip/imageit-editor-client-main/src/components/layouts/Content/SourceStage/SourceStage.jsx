import React, { useState, useEffect, useMemo, useCallback } from "react";
import { publicRuntimeConfig } from "@/next.config";
import styles from "./sourceStage.module.scss";
import { ZoomInOutlined, ZoomOutOutlined } from "@ant-design/icons";

import { Select, Tooltip, Row, Col } from "antd";

import { Stage, Layer, Image } from "react-konva";
import useImage from "use-image";

import { useZoom, ZOOM_MODE } from "../../../../common/ZoomMode/index";
import { useImageData } from "../../../../common/ImageData";
import { useHistory } from "@/src/common/History";
import useTrans from "@/src/common/useTrans";

export default function Index(props) {
  const { Option } = Select;
  const { zoomMode, isSync, setSync, stageSourceScale } = useZoom();
  const {
    setDefaultImage,
    setDefaultImageUid,
    setNameDefaultImage,
    width,
    height,
    ratio,
    setWidth,
    setHeight,
    setRatio,
    newEditImage,
    defaultImage,
    setNewEditImage,
    setRemoveBGImage,
    setSelectImage,
    handleSaveNewImage,
  } = useImageData();
  const { setupHistory } = useHistory();

  const {
    setDisplaySourceStage,
    handleScrollSource,
    firstDivRef,
    zoomOut,
    zoomIn,
    zoomByPercent,
    defaultValueScale,
  } = props;

  const handleChange = (option) => {
    zoomByPercent(option?.value);
  };
  const renderZoomOption = useMemo(() => {
    let options = [];
    for (let i = 40; i <= 250; i += 5) {
      options.push(
        <Option value={i / 100} className={styles.option} key={i}>
          {i}%
        </Option>
      );
    }
    return options;
  }, []);
  const [image] = useImage(defaultImage.url);
  const sourceStageElm = document.getElementById("sourceStage");
  const sourceStageElmWidth = sourceStageElm?.offsetWidth;
  const sourceStageElmHeight = sourceStageElm?.offsetHeight;
  useEffect(() => {
    if (image && sourceStageElm) {
      setRatio(image.width / sourceStageElmWidth);
      setWidth(sourceStageElmWidth);
      setHeight(image.height / ratio);
    }
  }, [image, ratio]);

  function preventScroll(e) {
    e.preventDefault();
    e.stopPropagation();
    return false;
  }
  useEffect(() => {
    if (sourceStageElm) {
      if (zoomMode === ZOOM_MODE.EDIT) {
        sourceStageElm.addEventListener("wheel", preventScroll);
      }
      if (zoomMode === ZOOM_MODE.SOURCE || isSync) {
        sourceStageElm.removeEventListener("wheel", preventScroll);
      }
      return () => {
        sourceStageElm.removeEventListener("wheel", preventScroll);
      };
    }
  }, [zoomMode, isSync]);

  const handleClassForStage = useCallback(() => {
    if (
      width * stageSourceScale < sourceStageElmWidth &&
      height * stageSourceScale > sourceStageElmHeight
    ) {
      return styles.imageWrapperHorizontal;
    }
    if (height * stageSourceScale < sourceStageElmHeight) {
      return styles.imageWrapperVertical;
    }

    return styles.imageWrapper;
  }, [stageSourceScale, width, height]);

  const handleChangeImage = (e) => {
    const URL = window.webkitURL || window.URL;
    const url = URL.createObjectURL(e.target.files[0]);
    let nameFile = e?.target?.files[0].name || "";
    let name = nameFile.slice(0, nameFile.lastIndexOf("."));
    setNameDefaultImage(name);
    handleSaveNewImage(url, nameFile);
    setDefaultImage({ ...defaultImage, url: url });
    setDefaultImageUid(null);
    setNewEditImage({ ...newEditImage, url: url, isView: true });
    setRemoveBGImage({
      url: null,
      isLock: false,
      isView: true,
    });
    setSelectImage(null);
    setupHistory({ newEditImage: { ...newEditImage, url: url } });
  };

  useEffect(() => {});
  return (
    <div className={styles.container}>
      <div
        className={
          zoomMode === ZOOM_MODE.SOURCE || isSync
            ? styles.tilteSelect
            : styles.title
        }
      >
        {useTrans("Source")}
      </div>
      <div className={styles.navbar}>
        <Row style={{ height: "54px" }} align="middle">
          <Col span={6}>
            <div style={{ cursor: "pointer" }}>
              <Tooltip
                placement="left"
                title={
                  <div className="tooltipText">
                    <div>{useTrans("Minimize")}</div>
                    <div>{useTrans("MinimizeDes")}</div>
                  </div>
                }
              >
                <img
                  src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/Minimize_Icon.svg`}
                  alt=""
                  style={{ marginRight: "20px" }}
                  onClick={() => setDisplaySourceStage(false)}
                />
              </Tooltip>
              <span className={styles.select}>
                <Select
                  labelInValue
                  defaultValue={defaultValueScale}
                  style={{
                    width: "44px",
                    height: "22px",
                    fontSize: "12px",
                  }}
                  onChange={handleChange}
                  dropdownStyle={{ fontSize: "12px" }}
                  value={
                    isSync
                      ? defaultValueScale
                      : {
                          value: Math.round(stageSourceScale * 100),
                          label: `${Math.round(stageSourceScale * 100)}%`,
                        }
                  }
                >
                  {renderZoomOption}
                </Select>
              </span>
            </div>
          </Col>
          <Col span={12} style={{ textAlign: "center" }}>
            <div>
              <Tooltip
                placement="left"
                title={
                  <span className="tooltipText">
                    {useTrans(`ZoomOut`)} (Shift + "-")
                  </span>
                }
              >
                <ZoomOutOutlined
                  style={{
                    fontSize: "20px",
                    marginRight: "28px",
                    cursor: "pointer",
                  }}
                  onClick={zoomOut}
                />
              </Tooltip>
              <Tooltip
                placement="right"
                title={
                  <span className="tooltipText">
                    {useTrans(`ZoomIn`)} (Shift + "+")
                  </span>
                }
              >
                <ZoomInOutlined
                  style={{
                    fontSize: "20px",
                    cursor: "pointer",
                  }}
                  onClick={zoomIn}
                />
              </Tooltip>
            </div>
          </Col>
          <Col span={6} style={{ textAlign: "right" }}>
            <Tooltip
              placement="left"
              title={
                <div className="tooltipText">
                  <div>{useTrans(`ScrollSync`)}</div>
                  <div>{useTrans(`ScrollSyncDescription`)}</div>
                </div>
              }
            >
              <img
                src={
                  isSync
                    ? `${publicRuntimeConfig.basePath}/icons/miscellaneous/Sync_Icon.svg`
                    : `${publicRuntimeConfig.basePath}/icons/miscellaneous/unsync.svg`
                }
                alt=""
                onClick={() => {
                  setSync(!isSync);
                }}
              />
            </Tooltip>
          </Col>
        </Row>
      </div>
      <div
        className={handleClassForStage()}
        id="sourceStage"
        ref={firstDivRef}
        onScroll={handleScrollSource}
      >
        <div className={styles.imageContainer}>
          {defaultImage.url ? (
            <Stage
              width={width * stageSourceScale}
              height={height * stageSourceScale}
              id="stage"
              scaleX={stageSourceScale / ratio}
              scaleY={stageSourceScale / ratio}
            >
              <Layer id="source">{image && <Image image={image} />}</Layer>
            </Stage>
          ) : (
            <div className={styles.imageBackground}>
              <div
                style={{ position: "absolute" }}
                className={styles.inputWrapper}
              >
                <img
                  src={`${publicRuntimeConfig.basePath}/icons/miscellaneous/ImageIt.svg`}
                  alt=""
                  width="204px"
                  height="55px"
                />
                <div className={styles.inputContent}>
                  <span>Drag and drop or Click here to upload</span>
                </div>
              </div>
              <input
                accept="image/*"
                type="file"
                multiple
                style={{
                  width: "100%",
                  height: "100%",
                  opacity: "0",
                  cursor: "pointer",
                }}
                onChange={(e) => handleChangeImage(e)}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
