import React from "react";
const Index = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M7 5V7.57527H8.73507V6.71685H11.3377V14.7704H9.60259V16.4873H14.8078V14.7704H13.0727V6.71685H15.6753V7.57527H17.4103V5H7Z" fill="#2E2E32" />
        <rect x="7" y="17.2051" width="10.4103" height="1.79489" fill="#2E2E32" />
    </svg>
)
export default Index;