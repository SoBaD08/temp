import { Button, Modal } from "antd";
import React, { forwardRef, useState, useImperativeHandle } from "react";
import { publicRuntimeConfig } from "@/next.config";
import styles from "./ConfirmMaskPopup.module.scss";
import { useImageData } from "../../../common/ImageData";
import useTrans from "@/src/common/useTrans";

const ConfirmMaskPopup = (props, ref) => {
  const { DEFAULT_SELECT, setSelect, setCallBackDownload } = useImageData();
  const [visible, setVisible] = useState(false);
  const [type, setType] = useState();
  const onOpen = () => {
    setVisible(true);
  };
  const onCancel = () => {
    setVisible(false);
  };
  useImperativeHandle(ref, () => ({
    onOpen: (type) => {
      setType(type);
      onOpen();
    },
  }));
  const handleDownload = () => {
    setSelect(DEFAULT_SELECT);
    onCancel();
    setCallBackDownload(type);
  };

  return (
    <Modal
      visible={visible}
      onCancel={onCancel}
      width={500}
      title={null}
      footer={null}
      wrapClassName={styles.mask}
    >
      <div className={styles.container}>
        <div>
          <img
            src={`${publicRuntimeConfig.basePath}/image/veluga_logo.png`}
            alt="veluga_logo"
            width="44"
            height="44"
          />
        </div>
        <div className="body">
          <div className="text">
            <div className="title">
              <b>{useTrans(`OperationFaile`)}</b>
            </div>
            <div className="description">
              {useTrans(`ConfirmDownload`)}
              <b> {useTrans(`Aborted`)}</b>
            </div>
          </div>
          <div className="wrap-button">
            <Button className="btn-cancel" onClick={onCancel}>
              {useTrans(`ContinueEditing`)}
            </Button>
            <Button className="btn-confirm" onClick={handleDownload}>
              {useTrans(`Download`)}
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default forwardRef(ConfirmMaskPopup);
