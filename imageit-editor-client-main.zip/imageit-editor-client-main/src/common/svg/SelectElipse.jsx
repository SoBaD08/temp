import React from "react";
const Index = (props) => (
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <circle
      cx="12"
      cy="12"
      r="11.4"
      stroke={props?.active ? "#6F64FA" : "#2E2E32"}
      stroke-width="1.2"
      stroke-dasharray="2 1"
    />
  </svg>
);
export default Index;
